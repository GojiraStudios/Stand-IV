
import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:standivnew/homepage.dart';
import 'package:standivnew/phoneverification.dart';

class UploadPicturePage extends StatefulWidget {
  final String uid;

  UploadPicturePage({super.key, required,required this.uid });

  // This widget is the  page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".



  @override
  State<UploadPicturePage> createState() => _UploadPicturePageState();
}

class _UploadPicturePageState extends State<UploadPicturePage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }



  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);



bool isLoading=false;
  @override
  void initState() {

    super.initState();

  }
  final GlobalKey _menuKey = GlobalKey();
  XFile? imageFile;
  _uploadImage() async{

    final String rand1 = "${new Random().nextInt(10000)}";
    final String rand2 = "${new Random().nextInt(10000)}";
    final String rand3 = "${new Random().nextInt(10000)}";

    // selectedImage= await testCompressFile(selectedImage);
    Reference ref = FirebaseStorage.instance
        .ref()
        .child('${rand1}_${rand2}_${rand3}.jpg');
    UploadTask uploadTask = ref.putFile(File(imageFile!.path));
    String imageUrl = await (await uploadTask).ref.getDownloadURL();
    print(imageUrl);
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.uid)
        .update({'profileImageUrl': imageUrl,}).catchError((e) {
      print(e);
    }).whenComplete(() => {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Profile Picture Added"),

        ),

      ),
    // Navigator.push(
    // context,
    // MaterialPageRoute(
    // builder: (context) => PhoneVerificationPage()))
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => HomePage(isNew: false,)))


    });
  }
  _pickImage(String type) async {


      await ImagePicker()
          .pickImage(source: ImageSource.gallery,)
          .then((selectedImage) async {
        if (selectedImage != null) {
          setState(() {
            this.imageFile = selectedImage;
          });
        }
      });



    // : await ImagePicker.pickImage(source: ImageSource.camera);
    //  return selectedImage;
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
backgroundColor: Colors.white,
      body:

          SingleChildScrollView(
            child: Column(children: [
  SizedBox(height: 50,),


            isLoading?
                Container(
                  height: Get.height,
                  child: Center(child:
                  CircularProgressIndicator(color: Colors.red,strokeWidth: 5,)),
                )

                :
            Container(
                child: Container(
                  margin: EdgeInsets.only(bottom:100 ),
                      height:Get.height*0.80,
                      width: Get.width,
                    color: Colors.white,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Center(child: Column(children: [
                              SizedBox(height: 10,),
                              Container(
                                margin: EdgeInsets.symmetric(horizontal: 5),
                                child: Container(

                                    color: Colors.white,
                                    height: 40,
                                    width: Get.width,

                                    child:
                                    Row(children: [
                                      SizedBox(width: 10,),
                                      InkWell(
                                        onTap: (){
                                          Navigator.pop(context);

                                        },
                                        child:ImageIcon(
                                          AssetImage("assets/backicon.png"),color: Colors.black,
                                          size: 25,
                                        ),
                                      ),
                                      Spacer(),
                                      Text( "Upload Picture",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                                      Spacer(),
                                      Spacer(),

                                    ],)
                                ),
                              ),
                              SizedBox(height: 10,),
                              SizedBox(height: 30,),
                              Text("Upload Your Profile Picture",style:
                              TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
                              SizedBox(height: 15,),
                              InkWell(

                                onTap: (){
                                  _pickImage("image");

                                },
                                child: Center(

                                  child: SizedBox(

                                    height: 150,

                                    child: Stack(

                                      children: [

                                         CircleAvatar(
backgroundColor: Colors.white,
                                          radius: 70,

                                          backgroundImage:

                                          imageFile!=null ?
                                          FileImage(
                                              File( imageFile!.path)
                                          ):
                                          AssetImage('assets/user.png') as ImageProvider,

                                        ),

                                        Positioned(

                                            top: 0,

                                            right: 0,

                                            child: IconButton(

                                              onPressed: () {},

                                              icon: const Icon(

                                                Icons.camera_alt,

                                                size: 35,
                                                color: Colors.red,

                                              ),

                                            ))

                                      ],

                                    ),

                                  ),),
                              ),




                              SizedBox(height: 15,),


                              InkWell(
                                onTap: (){
                                  if(imageFile==null){
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        backgroundColor: Colors.red,
                                        content: Text("Please choose a picture",style: TextStyle(color: Colors.white),),
                                      ),
                                    );
                                  }
                                 else{
                                    setState(() {
                                      isLoading=true;
                                    });
                                    _uploadImage();
                                  }

                                },
                                child: new Container(
                                  margin: EdgeInsets.only(top: 10),
                                  width: 50,
                                  height: 50,
                                  decoration: new BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                      colors: [
                                        Color.fromRGBO(146, 31, 23, 1),
                                        Color.fromRGBO(188, 40, 28, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                      ],),
                                 //   color: Colors.red,
                                    shape: BoxShape.circle,
                                  ),
                                  child: new Icon(
                                    Icons.arrow_forward,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),),
                              SizedBox(height: 10,),


                            ],),)

                          ],)
                  ),
              ),


            ],),
          )



     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }



}
