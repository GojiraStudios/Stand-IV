
import 'dart:async';

//import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:dropdown_search/dropdown_search.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
//import 'package:just_audio/just_audio.dart';
import 'package:standivnew/editProfile.dart';
import 'package:standivnew/feedBack.dart';
import 'package:standivnew/phoneverification.dart';
import 'package:standivnew/root.dart';
import 'package:standivnew/viewPostPage.dart';
import 'package:standivnew/votePage.dart';
import 'package:standivnew/welcome.dart';

import 'controller/audioController.dart';
import 'createPost.dart';

class HomePage extends StatefulWidget {

 bool isNew;
  HomePage({super.key, required, required this.isNew });



  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with WidgetsBindingObserver

{
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
bool isLoading=true;
var userDoscument;
int totalBronzePosts=0;
int totalBronzeVotes=0;
int totalSilverPosts=0;
int totalSilverVotes=0;
int totalGoldPosts=0;
int totalGoldVotes=0;
int totalBroadPosts=0;
int totalBroadVotes=0;
int totalCoins=0;
  String userkName="";
String numberOfPosts="0";
// checks time and sets gretting accordingly
  String getGreeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Good Morning';
    }
    if (hour < 17) {
      return 'Good Afternoon';
    }
    return ' Good Evening';
  }
  String greeting="Good Morning";
  String greetingImage="assets/dawn.png";
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }



  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);
// this method is called when app us send to backgroud or called infront
  // it stops music if it wasnt muted and plays when is taken back to front
void didChangeAppLifecycleState(AppLifecycleState state) {
  print(_AudioController.isMute.value);
  if(_AudioController.isMute.value==false){
    print("dfasdf");
    if (state == AppLifecycleState.paused) {
      //stop your audio player
      print("yes");
      _AudioController.player.value.pause();
      // _assetsAudioPlayer.pause();
      print("after");
    }
   else if (state == AppLifecycleState.resumed && _AudioController.isMute.value==false) {
     print("done");
      _AudioController.player.value.loopMode;
      _AudioController.player.value.play();
      _AudioController.player.value.setLoopMode(LoopMode.one);

    }

    else {

      _AudioController.player.value.pause();
    }



  }
  else if(_AudioController.isMute.value){
    if (state == AppLifecycleState.paused) {
      //stop your audio player
      print("muted");
      _AudioController.player.value.pause();
      // _assetsAudioPlayer.pause();
      print("muted");
    }
    else if (state == AppLifecycleState.resumed ) {
      print("muted");
      _AudioController.player.value.pause();
    }

    else {

      _AudioController.player.value.pause();
    }

  }

}
// for controller class
final AudioController _AudioController = Get.put(AudioController());

 late AudioPlayer player = AudioPlayer();

  @override
  void initState()   {


    print(FirebaseAuth.instance.currentUser!.uid+"add");

    FirebaseFirestore.instance
        .collection('posts').where("voter",arrayContains: FirebaseAuth.instance.currentUser!.uid )
        .where("stack",isEqualTo: "Bronze Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalBronzeVotes=qs.docs.length;
      });



    });
    FirebaseFirestore.instance
        .collection('posts').where("stack",isEqualTo: "Bronze Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalBronzePosts=qs.docs.length;
      });



    });

    //silver posts



    FirebaseFirestore.instance
        .collection('posts').where("voter",arrayContains:FirebaseAuth.instance.currentUser!.uid )
        .where("stack",isEqualTo: "Silver Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalSilverVotes=qs.docs.length;
      });



    });
    FirebaseFirestore.instance
        .collection('posts').where("stack",isEqualTo: "Silver Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalSilverPosts=qs.docs.length;
      });



    });
    //gold posts

    FirebaseFirestore.instance
        .collection('posts').where("voter",arrayContains: FirebaseAuth.instance.currentUser!.uid )
        .where("stack",isEqualTo: "Gold Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalGoldVotes=qs.docs.length;
      });



    });
    FirebaseFirestore.instance
        .collection('posts').where("stack",isEqualTo: "Gold Stack" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalGoldPosts=qs.docs.length;
      });



    });

    //broad posts
    FirebaseFirestore.instance
        .collection('posts').where("voter",arrayContains: FirebaseAuth.instance.currentUser!.uid)
        .where("stack",isEqualTo: "BroadCasts" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalBroadVotes=qs.docs.length;
      });



    });
    FirebaseFirestore.instance
        .collection('posts').where("stack",isEqualTo: "BroadCasts" )
        .get().then((QuerySnapshot qs) {
      setState(() {
        totalBroadPosts=qs.docs.length;
      });



    });


    //total users post
    FirebaseFirestore.instance
        .collection('posts').where("userid",isEqualTo:FirebaseAuth.instance.currentUser!.uid )
        .get().then((QuerySnapshot qs) {
      setState(() {
        numberOfPosts=qs.docs.length.toString();
      });



    });


setState(() {
  isLoading=false;

  greeting=getGreeting();
  if(greeting=="Good Afternoon"){
    greetingImage="assets/sunrise.png";

  }
  else if(greeting=="Good Evening"){
    greetingImage="assets/moon.png";

  }
});
    super.initState();
    WidgetsBinding.instance.addObserver(this);

  }

  @override
  Widget build(BuildContext context) {
    // this stream gets user details like name coins etc
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('users').where("userid",isEqualTo: FirebaseAuth.instance.currentUser!.uid ).limit(1)
            .snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<QuerySnapshot> snapshot) {
          // String data = snapshot.data.toString();
          if (!snapshot.hasData)
            return SizedBox();
        return Scaffold(


backgroundColor: Colors.white,
             drawer: isLoading==true || !snapshot.hasData?SizedBox(): Drawer(
               backgroundColor: Color.fromRGBO(188, 40, 28, 1),
               child: ListView(
                 padding: EdgeInsets.zero,
                 children: <Widget>[
                   DrawerHeader(

                     decoration: const BoxDecoration(
                       // image: DecorationImage(
                       //   image: AssetImage(
                       //     "assets/splashdrawer.png",
                       //   ),
                       //   fit: BoxFit.fill,
                       // ),
                       color: Color.fromRGBO(188, 40, 28, 1),
                     ),
                     child:
                       Column(

                         mainAxisAlignment: MainAxisAlignment.center,
                         crossAxisAlignment: CrossAxisAlignment.center,
                         children: [
                            Center(
                               child:

                               CircleAvatar(
                                 backgroundColor: Colors.white,
                                 radius: 40,

                                 backgroundImage:
                                 snapshot.data?.docs[0]["profileImageUrl"] !=""?
                                 NetworkImage( snapshot.data?.docs[0]["profileImageUrl"]):
                                 AssetImage('assets/user.png') as ImageProvider,

                               ),),
                          // SizedBox(height: 5,),
                           Text(snapshot.data?.docs[0]['firstName']+" "+snapshot.data?.docs[0]['lastName'],style: TextStyle(fontSize: 17,fontWeight: FontWeight.bold,color: Colors.white),),
                        //   SizedBox(height: 5,),

Center(
  child:   InkWell(
        onTap: () {
          print(snapshot.data?.docs[0]['profileImageUrl']);

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      EditProfilePage(document:snapshot.data?.docs[0],)));
        },
        child:   Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,

          children: [
          const Icon(
            Icons.mode_edit_outline,
            color: Colors.white,
            size: 20,
          ),
          SizedBox(width: 5,),
          Text('Edit Profile',
              style: TextStyle(
                  color: Colors.white),

          ),


        ],),
  ),
),

                         ],)
                   ),
                   ListTile(
                       leading: const ImageIcon(
                         AssetImage("assets/coin.png",) ,


                         size: 25,
                         color: Colors.white,

                       ),
                       title: Text('Your Coins : '+ snapshot.data!.docs[0]['coins'].toString(),
                           style: TextStyle(
                               fontWeight: FontWeight.bold, color: Colors.white)),
                       onTap: () {
                         print(snapshot.data?.docs[0]['profileImageUrl']);

                         Navigator.push(
                             context,
                             MaterialPageRoute(
                                 builder: (context) =>
                                     EditProfilePage(document: snapshot.data?.docs[0],)));
                       }

                   ),
                   ListTile(
                       leading: Icon(
                         Icons.person_outline,
                         color: Colors.white,
                         size: 25,
                       ),
                       title: Text('View Profile',
                           style: TextStyle(
                               fontWeight: FontWeight.bold, color: Colors.white)),
                       onTap: () {
                         print(snapshot.data?.docs[0]['profileImageUrl']);

                         Navigator.push(
                             context,
                             MaterialPageRoute(
                                 builder: (context) =>
                                     EditProfilePage(document:snapshot.data?.docs[0],)));
                       }

                   ),
                   ListTile(
                       leading: Icon(
                         Icons.photo_album_outlined,
                         color: Colors.white,
                         size: 25,
                       ),
                       title: Text('View Posts',
                           style: TextStyle(
                               fontWeight: FontWeight.bold, color: Colors.white)),
                       onTap: () {
                        // print(snapshot.data?.docs[0]['profileImageUrl']);

                         Navigator.push(
                             context,
                             MaterialPageRoute(
                                 builder: (context) =>
                                     ViewPosts(uId: FirebaseAuth.instance.currentUser!.uid,)));
                       }

                   ),
                   ListTile(
                       leading: Icon(
                         Icons.feedback_outlined,
                         color: Colors.white,
                         size: 25,
                       ),
                       title: Text('Feedback',
                           style: TextStyle(
                               fontWeight: FontWeight.bold, color: Colors.white)),
                       onTap: () {


                         Navigator.push(
                             context,
                             MaterialPageRoute(
                                 builder: (context) =>
                                     FeedBackPage()));
                       }

                   ),

                   ListTile(
                     leading: Icon(
                       Icons.logout,
                       color: Colors.white,
                       size: 25,
                     ),
                     title:
                     Text('Logout', style:TextStyle(color: Colors.white)),
                     onTap: () async {

                      // player.pause();
                       _AudioController.player.value.stop();
                       await FirebaseAuth.instance.signOut();
                       Navigator.pushReplacement(
                           context,
                           MaterialPageRoute(
                               builder: (context) => WelcomePage()));


                       ScaffoldMessenger.of(context).showSnackBar(
                         SnackBar(
                           content: Text("Logged Out"),
                         ),
                       );
                     },
                   )

                 ],
               ),
             ),
          body:
          isLoading?
          SingleChildScrollView(
            child: Container(
              height: Get.height,
              child: Center(child:
              CircularProgressIndicator(color: Colors.red,strokeWidth: 5,)),
            ),
          )

              :
          SingleChildScrollView(
                child: Column(children: [

                          Container(
                            decoration:  BoxDecoration(
                              borderRadius:  BorderRadius.circular(15.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromRGBO(188, 40, 28, 1).withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 7,
                                  offset: Offset(0, 3), // changes position of shadow
                                ),
                              ],
                              gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: <Color>[
                                    Color.fromRGBO(146, 31, 23, 1),
                                    Color.fromRGBO(188, 40, 28, 1),
                                    Color.fromRGBO(232, 50, 35, 1),

                                    Color.fromRGBO(232, 50, 35, 1),
                                    Color.fromRGBO(232, 50, 35, 1),
                                    Color.fromRGBO(232, 50, 35, 1),





                                  ]),
                            ),
                            height: 180,
                            width: Get.width,
                            padding: EdgeInsets.only(left: 30,top:  MediaQuery.of(context).viewPadding.top+17),

                            //child: Text("Good Morning"),
                            child: Row(
                              children: [
                                new Column(
                            children: [
                            Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Row(
                                  children: [
                                    Container(child: Image.asset(greetingImage,),height: 25,),
                                    Text("  "+greeting,style:GoogleFonts.merienda(textStyle: TextStyle(color: Colors.white.withOpacity(0.6,),fontSize: 15),)),


                                  ],
                                ),
                                SizedBox(height: 5,),
                                Text(snapshot.data!.docs[0]['firstName']+" "+snapshot.data!.docs[0]['lastName'],

                                    style:
                                    GoogleFonts.roboto(


                                      textStyle:
                                      TextStyle(

                                        color: Colors.white.withOpacity(1,),fontSize: 18,fontWeight: FontWeight.w600,),)),
                                Container(
                                  margin: EdgeInsets.only(top: 5 ),
                                  height:23,
                                  width: 170,
                                  decoration: BoxDecoration(
                                    // color: Colors.white,
                                    border: Border.all(
                                      width: 0.5,
                                      color: Colors.white,

                                    ),

                                    borderRadius: BorderRadius.all(

                                      Radius.circular(5),
                                      //topRight: Radius.circular(90),
                                    ),

                                  ),

                                  child: Row(children: [
                                    RichText(
                                      text: TextSpan(
                                          children: <TextSpan>[
                                            TextSpan(text: " " +numberOfPosts,
                                              style:  GoogleFonts.roboto(


                                                  textStyle:TextStyle(
                                                      color: Colors.white, fontSize: 12,fontWeight: FontWeight.bold)),

                                            ),
                                            TextSpan(text: ' Posts',
                                              style:  GoogleFonts.roboto(


                                                  textStyle:TextStyle(
                                                      color: Colors.white.withOpacity(0.6,), fontSize: 12)),

                                            )
                                          ]
                                      ),
                                    ),
                                    VerticalDivider(color: Colors.white,),

                                    RichText(
                                      text: TextSpan(
                                          children: <TextSpan>[
                                            TextSpan(text: snapshot.data!.docs[0]['coins'].toString(),
                                              style: GoogleFonts.roboto(


                                                  textStyle: TextStyle(
                                                      color: Colors.white, fontSize: 12,fontWeight: FontWeight.bold)),

                                            ),
                                            TextSpan(text: ' Coins',
                                              style:  GoogleFonts.roboto(


                                                  textStyle:TextStyle(
                                                      color: Colors.white.withOpacity(0.6,), fontSize: 12)),

                                            )
                                          ]
                                      ),
                                    ),

                                  ],),
                                ),
                              ],),
                          ],
                        ),

                                Spacer(),
                                Column(
                                  children: [
                                    Builder(
                                        builder: (context) =>
                                            InkWell(
                                              onTap: (){
                                                Scaffold.of(context).openDrawer();


                                              },
                                              child: Container(
                                                  margin: EdgeInsets.only(right: 12,bottom: 10),
                                                  child: Center(child: Icon(Icons.menu,color:Colors.white,size: 30,))),
                                            )),
                                    InkWell(
                                      onTap: (){

if(snapshot.data?.docs[0]['coins']>=25){
  print(snapshot.data?.docs[0]['coins']);
  Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => CreatePostPage(uId: FirebaseAuth.instance.currentUser!.uid,coins: snapshot.data?.docs[0]['coins'],winningPosts: snapshot.data?.docs[0]['winningPost'],)));

}
else{
  ScaffoldMessenger.of(context).showSnackBar(
        SnackBar( backgroundColor: Colors.red,
          content: Text("You need atleast 25 coins to add new post"),
        ),
  );
}
                                      }
                                      ,
                                      child: Center(child:
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                              margin: EdgeInsets.only(right: 12),
                                              height: 30,
                                              width: 35,


                                              child:
                                              Center(child: Image.asset("assets/add.png"))

                                          ),

                                          Container(
                                            margin: EdgeInsets.only(right: 12,top: 5),
                                            child: Text( 'New Post',
                                                style:  GoogleFonts.roboto(


                                                    textStyle:TextStyle(
                                                      color:  Colors.white.withOpacity(0.9,), fontSize: 12,fontWeight: FontWeight.bold))),
                                          )

                                        ],)
                                        ,),
                                    ),
                                    InkWell(
                                      onTap: (){
if(_AudioController.isMute.value){
  setState(() {
    _AudioController.isMute.value=false;

  });
  _AudioController.player.value.play();
}
else{
  setState(() {
    _AudioController.isMute.value=true;
    //_AudioController.player.value.play();
  });
  _AudioController.player.value.pause();
}
                                      }
                                      ,
                                      child: Center(child:
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                              margin: EdgeInsets.only(right: 12,bottom: 5,top: 5),
                                              height: 25,
                                              width: 35,


                                              child:
                                              Center(child:


                                              Image.asset(

                                                _AudioController.isMute.value?"assets/muteaudio.png":
                                                "assets/unmute.png",color: Colors.white,height: 25,))

                                          ),



                                        ],)
                                        ,),
                                    ),
                                  ],
                                )
                              ],
                            )),


                  SizedBox(height: 20,),

                  Container(
                      margin: EdgeInsets.symmetric(horizontal:15, ),
                       height:440,
                    //  width: Get.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          width: 0,
                          color: Colors.white,

                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 6,
                            blurRadius: 7,
                            offset: Offset(0, 3), // changes position of shadow
                          ),
                        ],
                        borderRadius: BorderRadius.all(

                          Radius.circular(10),
                          //topRight: Radius.circular(90),
                        ),

                      ),
                      child:


                      Stack(
                        children: [
                          Center(child: VerticalDivider(thickness: 1,),),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Row(
                                children: [
                                  InkWell(onTap: (){

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => VotePage(stackType: "Bronze Stack",uId: FirebaseAuth.instance.currentUser!.uid,totalPosts: totalBronzePosts,totalVoted: totalBronzeVotes,)));

                                  },
                                    child: Container(
                                    margin: EdgeInsets.only(top: 10,left: 10),
                                    height:200,
                                    width: Get.width*0.40,
                                      child: Column(
                                        children: [
                                          Stack(children: [
                                            Positioned(

                                                child:
                            Container(
                            //margin: EdgeInsets.symmetric(horizontal:15, ),
                            height:180,
                                                width: Get.width*0.45,
                                                child:
                                                Image.asset('assets/bronzebadge.png',fit: BoxFit.fitWidth,))

                                            ),
        //                                     Positioned(child:
        //                                     Align(
        //                                       alignment: Alignment.topCenter,
        //                                       child:
        //                                       Container(
        //                                         //  margin: EdgeInsets.symmetric(horizontal:15, ),
        //                                           height:25,
        //                                           width: 50,
        //                                           decoration: BoxDecoration(
        //                                             color: Colors.red,
        //                                             border: Border.all(
        //                                               width: 0,
        //                                               color: Colors.red,
        //
        //                                             ),
        //                                             gradient: LinearGradient(
        //                                                 begin: Alignment.topLeft,
        //                                                 end: Alignment.bottomRight,
        //                                                 colors: <Color>[
        //                                                   Color.fromRGBO(146, 31, 23, 1),
        //                                                   Color.fromRGBO(188, 40, 28, 1),
        //                                                   Color.fromRGBO(232, 50, 35, 1),
        //
        //                                                   Color.fromRGBO(232, 50, 35, 1),
        //                                                   Color.fromRGBO(232, 50, 35, 1),
        //                                                   Color.fromRGBO(232, 50, 35, 1),
        //
        //
        //
        //
        //
        //                                                 ]),
        //                                             boxShadow: [
        //                                               BoxShadow(
        //                                                 color: Colors.grey.withOpacity(0.5),
        //                                                 spreadRadius: 6,
        //                                                 blurRadius: 7,
        //                                                 offset: Offset(0, 3), // changes position of shadow
        //                                               ),
        //                                             ],
        //                                             borderRadius: BorderRadius.all(
        //
        //                                               Radius.circular(8),
        //                                               //topRight: Radius.circular(90),
        //                                             ),
        //
        //                                           ),
        //                                           child:
        //
        //                                           Center(child:
        //
        //                                           RichText(
        //                                             text: TextSpan(
        //                                                 children: <TextSpan>[
        //                                                   TextSpan(text: totalBronzeVotes.toString()+'/',
        //                                                     style:   GoogleFonts.lato(textStyle:TextStyle(
        //                                                         color: Colors.white, fontSize: 15,
        //                                                         fontWeight: FontWeight.bold)),
        //
        //                                                   ),
        //                                                   TextSpan(text: totalBronzePosts.toString(),
        //                                                     style:
        //                                                     GoogleFonts.lato(textStyle:
        // TextStyle(
        //                                                         color: Colors.white.withOpacity(0.6,),
        //                                                         fontSize: 12)),
        //
        //                                                   )
        //                                                 ]
        //                                             ),
        //                                           ),
        //                                           ),
        //
        //                                     )
        //
        //                                     ))


                                          ],),

                                          Text("Bronze Level",
                                            style:   GoogleFonts.roboto(


                                                textStyle:
                                            TextStyle(color:Colors.black54,)),)
                                        ],
                                      ),
                                    ),
                                  ),


                               Spacer(),

                                  InkWell(
                                    onTap: (){
if(snapshot.data?.docs[0]['winningPost']>=3) {

  Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => VotePage(stackType: "Silver Stack",uId:FirebaseAuth.instance.currentUser!.uid,totalPosts: totalSilverPosts,totalVoted: totalSilverVotes,)));

}
else {
  AwesomeDialog(
    context: context,
    dialogType: DialogType.error,
    animType: AnimType.leftSlide,
    headerAnimationLoop: false,
    title: 'Access Denied',
    desc:
    'You need to win three post votes in order to vote in Silver Level',
    btnOkOnPress: () {},
    btnOkIcon: Icons.cancel,
    btnOkColor: Colors.red,
  ).show();
}

                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(top: 10,right: 10),
                                      height:200,
                                      width: Get.width*0.40,
                                      child: Column(
                                        children: [
                                          Stack(children: [
                                            Positioned(

                                                child:
                                                Container(
                                                  //margin: EdgeInsets.symmetric(horizontal:15, ),
                                                    height:180,
                                                    width: Get.width*0.45,
                                                    child:
                                                    Image.asset('assets/silberbadge.png',fit: BoxFit.fitWidth,))

                                            ),
                                            Positioned(child:
                                            Align(
                                                alignment: Alignment.topCenter,
                                                child:
          snapshot.data?.docs[0]['winningPost']>=3?SizedBox():       Container(
                                                  //  margin: EdgeInsets.symmetric(horizontal:15, ),
                                                  height:25,
                                                  width: 25,
                                                  decoration: BoxDecoration(
                                                    color: Colors.red,
                                                    border: Border.all(
                                                      width: 0,
                                                      color: Colors.red,

                                                    ),
                                                    gradient: LinearGradient(
                                                        begin: Alignment.topLeft,
                                                        end: Alignment.bottomRight,
                                                        colors: <Color>[
                                                          Color.fromRGBO(146, 31, 23, 1),
                                                          Color.fromRGBO(188, 40, 28, 1),
                                                          Color.fromRGBO(232, 50, 35, 1),

                                                          Color.fromRGBO(232, 50, 35, 1),
                                                          Color.fromRGBO(232, 50, 35, 1),
                                                          Color.fromRGBO(232, 50, 35, 1),





                                                        ]),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.grey.withOpacity(0.5),
                                                        spreadRadius: 6,
                                                        blurRadius: 7,
                                                        offset: Offset(0, 3), // changes position of shadow
                                                      ),
                                                    ],
                                                    borderRadius: BorderRadius.all(

                                                      Radius.circular(360),
                                                      //topRight: Radius.circular(90),
                                                    ),

                                                  ),
                                                  child:

                                                  Center(child:
                                                  Icon(Icons.lock_rounded,color: Colors.white,size: 18,)


                                                )

                                            )))


                                          ],),

                                          Text("Silver Level" ,style:  GoogleFonts.lato(textStyle:
                                          TextStyle(color:Colors.black54,)),)
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),

Center(child: Divider(thickness: 1,)),
                              Row(
                                children: [
                                  InkWell(
                                    onTap: (){
                                      if(snapshot.data?.docs[0]['winningPost']>=5) {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) => VotePage(stackType: "Gold Stack",uId: FirebaseAuth.instance.currentUser!.uid,totalPosts: totalGoldPosts,totalVoted: totalGoldVotes,)));

                                      }
                                      else {
                                        AwesomeDialog(
                                          context: context,
                                          dialogType: DialogType.error,
                                          animType: AnimType.rightSlide,
                                          headerAnimationLoop: false,
                                          title: 'Access Denied',
                                          desc:
                                          'You need to win 5 post votes in order to vote in Gold Level',
                                          btnOkOnPress: () {},
                                          btnOkIcon: Icons.cancel,
                                          btnOkColor: Colors.red,
                                        ).show();
                                      }


                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(top: 10,left: 10),
                                      height:200,
                                      width: Get.width*0.40,
                                      child: Column(
                                        children: [
                                          Stack(children: [
                                            Positioned(

                                                child:
                                                Container(
                                                  //margin: EdgeInsets.symmetric(horizontal:15, ),
                                                    height:180,
                                                    width: Get.width*0.45,
                                                    child:
                                                    Image.asset('assets/goldbadge.png',fit: BoxFit.fitWidth,))

                                            ),
                                            Positioned(child:
                                            Align(
                                                alignment: Alignment.topCenter,
                                                child:
                                                snapshot.data?.docs[0]['winningPost']>=5?SizedBox():                        Container(
                                                  //  margin: EdgeInsets.symmetric(horizontal:15, ),
                                                    height:25,
                                                    width: 25,
                                                    decoration: BoxDecoration(
                                                      color: Colors.red,
                                                      border: Border.all(
                                                        width: 0,
                                                        color: Colors.red,

                                                      ),
                                                      gradient: LinearGradient(
                                                          begin: Alignment.topLeft,
                                                          end: Alignment.bottomRight,
                                                          colors: <Color>[
                                                            Color.fromRGBO(146, 31, 23, 1),
                                                            Color.fromRGBO(188, 40, 28, 1),
                                                            Color.fromRGBO(232, 50, 35, 1),

                                                            Color.fromRGBO(232, 50, 35, 1),
                                                            Color.fromRGBO(232, 50, 35, 1),
                                                            Color.fromRGBO(232, 50, 35, 1),





                                                          ]),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors.grey.withOpacity(0.5),
                                                          spreadRadius: 6,
                                                          blurRadius: 7,
                                                          offset: Offset(0, 3), // changes position of shadow
                                                        ),
                                                      ],
                                                      borderRadius: BorderRadius.all(

                                                        Radius.circular(360),
                                                        //topRight: Radius.circular(90),
                                                      ),

                                                    ),
                                                    child:

                                                    Center(child:
                                                    Icon(Icons.lock_rounded,color: Colors.white,size: 18,)


                                                    )

                                                )

                                            ))


                                          ],),

                                          Text("Gold Level", style:
        GoogleFonts.lato(textStyle:
                                          TextStyle(color:Colors.black54,)),)
                                        ],
                                      ),
                                    ),
                                  ),


                                  Spacer(),

                                  InkWell(
                                    onTap: (){


                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => VotePage(stackType: "BroadCasts",uId: FirebaseAuth.instance.currentUser!.uid,totalPosts: totalBroadPosts,totalVoted: totalBroadVotes,)));

                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(top: 10,right: 10),
                                      height:200,
                                      width: Get.width*0.40,
                                      child: Column(
                                        children: [
                                          Stack(children: [
                                            Positioned(

                                                child:
                                                Container(
                                                  //margin: EdgeInsets.symmetric(horizontal:15, ),
                                                    height:180,
                                                    width: Get.width*0.45,
                                                    child:
                                                    Image.asset('assets/brosadcasts.png',fit: BoxFit.fitWidth,))

                                            ),
                                            // Positioned(child:
                                            // Align(
                                            //     alignment: Alignment.topCenter,
                                            //     child:
                                            //     Container(
                                            //       //  margin: EdgeInsets.symmetric(horizontal:15, ),
                                            //       height:25,
                                            //       width: 50,
                                            //       decoration: BoxDecoration(
                                            //         color: Colors.red,
                                            //         border: Border.all(
                                            //           width: 0,
                                            //           color: Colors.red,
                                            //
                                            //         ),
                                            //         gradient: LinearGradient(
                                            //             begin: Alignment.topLeft,
                                            //             end: Alignment.bottomRight,
                                            //             colors: <Color>[
                                            //               Color.fromRGBO(146, 31, 23, 1),
                                            //               Color.fromRGBO(188, 40, 28, 1),
                                            //               Color.fromRGBO(232, 50, 35, 1),
                                            //
                                            //               Color.fromRGBO(232, 50, 35, 1),
                                            //               Color.fromRGBO(232, 50, 35, 1),
                                            //               Color.fromRGBO(232, 50, 35, 1),
                                            //
                                            //
                                            //
                                            //
                                            //
                                            //             ]),
                                            //         boxShadow: [
                                            //           BoxShadow(
                                            //             color: Colors.grey.withOpacity(0.5),
                                            //             spreadRadius: 6,
                                            //             blurRadius: 7,
                                            //             offset: Offset(0, 3), // changes position of shadow
                                            //           ),
                                            //         ],
                                            //         borderRadius: BorderRadius.all(
                                            //
                                            //           Radius.circular(8),
                                            //           //topRight: Radius.circular(90),
                                            //         ),
                                            //
                                            //       ),
                                            //       child:
                                            //
                                            //       Center(child:
                                            //
                                            //       RichText(
                                            //         text: TextSpan(
                                            //             children: <TextSpan>[
                                            //               TextSpan(text: totalBroadVotes.toString()+'/',
                                            //                 style:   GoogleFonts.lato(textStyle:TextStyle(
                                            //                     color: Colors.white, fontSize: 15,
                                            //                     fontWeight: FontWeight.bold)),
                                            //
                                            //               ),
                                            //               TextSpan(text: totalBroadPosts.toString(),
                                            //                 style:
                                            //                 GoogleFonts.lato(textStyle:
                                            //                 TextStyle(
                                            //                     color: Colors.white.withOpacity(0.6,),
                                            //                     fontSize: 12)),
                                            //
                                            //               )
                                            //             ]
                                            //         ),
                                            //       ),
                                            //
                                            //       ),
                                            //
                                            //     )
                                            //
                                            // ))


                                          ],),

                                          Text("Broadcasts", style:  GoogleFonts.lato(textStyle: TextStyle(color:Colors.black54,)),)
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                            ],),
                        ],
                      ),
                    ),

                  SizedBox(height: 15,),
                  Center(child: Text("Today's Gayaan",
                  style:
        GoogleFonts.lato(textStyle:TextStyle(
          color: Colors.black45,fontSize: 15
        )),
                  ),),
                  SizedBox(height: 5,),
                  Container(

        margin: EdgeInsets.symmetric(horizontal: 25),

        child: Center(child: Text("Our Lives begin to end the moment we become silent about things that matter",
          textAlign: TextAlign.center,

                      style:
                      GoogleFonts.lato(textStyle:TextStyle(
                        wordSpacing: 2,

                          color: Color.fromRGBO(70, 70, 70, 1),fontSize: 25
                      )),
                    ),),
                  ),
                  SizedBox(height: 15,),
                  Center(child: Text("-Martin Luther King Jr.",
                    style:
                    GoogleFonts.lato(textStyle:TextStyle(
                        color: Colors.black45,fontSize: 15
                    )),
                  ),),








                ],),
              )



         // This trailing comma makes auto-formatting nicer for build methods.
        );
      }
    );

  }


}
