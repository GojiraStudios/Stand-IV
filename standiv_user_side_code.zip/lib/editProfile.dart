
import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:standivnew/phoneverification.dart';
import 'package:standivnew/signin.dart';
import 'package:standivnew/uploadPicture.dart';

import 'homepage.dart';

class EditProfilePage extends StatefulWidget {
  var document;

  EditProfilePage({super.key, required,required this.document });



  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
bool showVerification=false;
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }

  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();
XFile? imageFile;
String? gender;
List<String>  genderList=['Male','Female', 'Others',];
// updates profile picture
_uploadImage() async{

  final String rand1 = "${new Random().nextInt(10000)}";
  final String rand2 = "${new Random().nextInt(10000)}";
  final String rand3 = "${new Random().nextInt(10000)}";

  // selectedImage= await testCompressFile(selectedImage);
  Reference ref = FirebaseStorage.instance
      .ref()
      .child('${rand1}_${rand2}_${rand3}.jpg');
  UploadTask uploadTask = ref.putFile(File(imageFile!.path));
  String imageUrl = await (await uploadTask).ref.getDownloadURL();
  print(imageUrl);
  FirebaseFirestore.instance
      .collection('users')
      .doc(widget.document['userid'])
      .update({'profileImageUrl': imageUrl,}).catchError((e) {
    print(e);
  });
}
_pickImage(String type) async {


  await ImagePicker()
      .pickImage(source: ImageSource.gallery,)
      .then((selectedImage) async {
    if (selectedImage != null) {
      setState(() {
        this.imageFile = selectedImage;
      });
    }
  });



  // : await ImagePicker.pickImage(source: ImageSource.camera);
  //  return selectedImage;
}
  @override




 // all of the text controllers
TextEditingController firstNameController = TextEditingController();
TextEditingController lastNameController = TextEditingController();
TextEditingController phoneController = TextEditingController();
TextEditingController pinController = TextEditingController();

  bool loading = false;



@override
void initState() {
  super.initState();
  // we set values of all controllers
  if(widget.document['gender']!=""){
    gender=widget.document['gender'];
  }
  firstNameController = new TextEditingController(text: widget.document['firstName']);
  lastNameController = new TextEditingController(text: widget.document['lastName']);
  phoneController = new TextEditingController(text: widget.document['phone']);
  pinController = new TextEditingController(text: widget.document['pin']);
}


  @override
  Widget build(BuildContext context) {

    return Scaffold(
backgroundColor: Colors.white,
      body:

     SingleChildScrollView(
            child: Container(

              child: Form(
                key: _formKey,
                child: Column(children: [
  SizedBox(height: 50,),


                  Container(
                    child: Container(
                      margin: EdgeInsets.only(bottom:100 ),
                          height:Get.height*0.90,
                          width: Get.width,
                        color: Colors.white,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Center(child:

                                Column(children: [
                                  SizedBox(height: 10,),
                                  Container(
                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                    child: Container(

                                        color: Colors.white,
                                        height: 40,
                                        width: Get.width,

                                        child:
                                        Row(children: [
                                          SizedBox(width: 10,),
                                          InkWell(
                                            onTap: (){
                                              Navigator.pop(context);

                                            },
                                            child:ImageIcon(
                                              AssetImage("assets/backicon.png"),color: Colors.black,
                                              size: 25,
                                            ),
                                          ),
                                          Spacer(),
                                          Text( "Edit Profile",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                                          Spacer(),
                                          Spacer(),

                                        ],)
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  SizedBox(height: 30,),
                                  InkWell(

                                    onTap: (){
                                      _pickImage("image");

                                    },
                                    child: Center(

                                      child: SizedBox(

                                        height: 150,

                                        child: Stack(

                                          children: [

                                            CircleAvatar(
                                              backgroundColor: Colors.white,
                                              radius: 70,

                                              backgroundImage:

                                              imageFile!=null ?
                                              FileImage(
                                                  File( imageFile!.path)
                                              ):
                                                  widget.document["profileImageUrl"]!=""?
                                                  NetworkImage( widget.document["profileImageUrl"]):
                                              AssetImage('assets/user.png') as ImageProvider,

                                            ),

                                            Positioned(

                                                top: 0,

                                                right: 0,

                                                child: IconButton(

                                                  onPressed: () {},

                                                  icon: const Icon(

                                                    Icons.camera_alt,

                                                    size: 35,
                                                    color: Colors.red,

                                                  ),

                                                ))

                                          ],

                                        ),

                                      ),),
                                  ),

                                  SizedBox(height: 15,),
                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your first name";
                                        }

                                      },
                                      controller: firstNameController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.grey[600],fontSize: 18),
                                          hintText: "First Name",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),
                                  SizedBox(height: 15,),
                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your last name";
                                        }

                                      },
                                      controller: lastNameController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.grey[600],fontSize: 18),
                                          hintText: "Last Name",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),

                                  SizedBox(height: 10,),
                                  Container(
                                    decoration:   BoxDecoration(
                                        color: Color.fromRGBO(243, 243, 245, 1),
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    height: 60,
                                    child: DropdownButton2(
                                      underline: SizedBox(),
                                      isExpanded: true,
                                      hint: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: const [

                                          SizedBox(
                                            width: 5,
                                          ),
                                          Center(
                                            child: Text(
                                              'Select Gender',
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  color: Colors.black45

                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                      items: genderList
                                          .map((item) => DropdownMenuItem<String>(
                                        value: item,
                                        child: Center(
                                          child: Text(
                                            item,
                                            style: const TextStyle(
                                              fontSize: 18,

                                              color: Colors.black,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ))
                                          .toList(),
                                      value: gender,
                                      onChanged: (value) {
                                        setState(() {


                                          if(gender!=value){
                                            gender= gender = value as String;
                                          }




                                        });
                                      },
                                      icon: const Icon(
                                        Icons.arrow_drop_down_outlined,
                                      ),
                                      iconSize: 20,
                                      iconEnabledColor: Colors.black45,
                                      iconDisabledColor: Colors.grey,

                                      buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                                      buttonElevation: 2,
                                      itemHeight: 40,
                                      itemPadding: const EdgeInsets.only(left: 15, right: 15),
                                      dropdownMaxHeight: 200,
                                      dropdownWidth: 200,
                                      dropdownPadding: null,
                                      dropdownDecoration:  BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: new BorderRadius.circular(15.0),
                                          boxShadow: [
                                            BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                                spreadRadius: 0.4)
                                          ]),
                                      dropdownElevation: 8,
                                      scrollbarRadius: const Radius.circular(40),
                                      scrollbarThickness: 6,
                                      scrollbarAlwaysShow: true,
                                      offset: const Offset(-20, 0),
                                    ),
                                    padding: EdgeInsets.only(top: 10),
                                  ),
                                  SizedBox(height: 10,),
                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your phone number";
                                        }

                                      },
                                      keyboardType: TextInputType.phone,
                                      controller: phoneController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(

                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
errorBorder: OutlineInputBorder(
                                          borderSide: BorderSide(width: 2, color: Colors.red),
                                      borderRadius: BorderRadius.circular(360.0),
                                    ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.grey[600],fontSize: 18),
                                          hintText: "Enter your Phone Number",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),
                                  SizedBox(height: 5,),
                                  InkWell(
                                    onTap: () async {

    if (_formKey.currentState!.validate()) {
if( imageFile!=null ){

 await _uploadImage();
}
// we update user detai;s
      await FirebaseFirestore.instance
          .collection("users").doc(widget.document['userid']).update({


        "firstName": firstNameController.text,
        "lastName" :lastNameController.text,
        "gender" : gender,
        "phone": phoneController.text,
        "pin": pinController.text,
      }).then((value) {

        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => HomePage(isNew: false,)));

      });

    }

                                    },
                                    child: new Container(
                                      margin: EdgeInsets.only(top: 10),
                                      width: 50,
                                      height: 50,
                                      decoration: new BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            Color.fromRGBO(146, 31, 23, 1),
                                            Color.fromRGBO(188, 40, 28, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                          ],),
                                     //   color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: new Icon(
                                        Icons.edit,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  Text("Update Profile Details",style: TextStyle(color:Colors.black54,fontSize: 16),),



                                ],),)

                              ],)
                      ),
                  ),


                ],),
              ),
            ),
          )




     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? verificationId;
  String? otp, authStatus = "";



}
