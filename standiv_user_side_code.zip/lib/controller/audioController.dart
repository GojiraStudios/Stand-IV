import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:just_audio/just_audio.dart';
// this controller is for audio player
// also check if user muted audio or not
class AudioController extends GetxController {
  late Rx<AudioPlayer> player = AudioPlayer().obs;
  Rx<bool> isMute=false.obs;

  @override
  void onInit() {
_play();
super.onInit();
  }

  void _play() {
     player.value.setAsset('assets/appgamemusic.mp3');
    player.value.loopMode;
    player.value.play();
    player.value.setLoopMode(LoopMode.one);
  }

  void _stop() {
    player.value.stop();
  }

}
