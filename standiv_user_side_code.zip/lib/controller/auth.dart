// import 'package:firebase_auth/firebase_auth.dart';
//
// import '../models/user.dart';
//
// class AuthController {
//   final FirebaseAuth _auth = FirebaseAuth.instance;
//
//   String getCurrentUser() {
//     final User user = _auth.currentUser!;
//     final uid = user.uid;
//
//     return uid;
//   }
//
//   // create user obj based on firebase user
//   TheUser? _userFromFirebaseUser(User? user) {
//     return user != null ? TheUser(uid: user.uid) : null;
//   }
//
//   // auth change user stream
//   Stream<TheUser?> get user {
//     return _auth
//         .authStateChanges()
//         .map(_userFromFirebaseUser);
//   }
//
// // sign in with email and password
//   Future signInWithEmailAndPassword(String email, String password) async {
//     try {
//       await _auth.signInWithEmailAndPassword(email: email, password: password);
//     } on FirebaseAuthException catch (error) {
//       switch (error.code) {
//         case "ERROR_EMAIL_ALREADY_IN_USE":
//         case "account-exists-with-different-credential":
//         case "email-already-in-use":
//           return "Email already used. Go to login page.";
//
//         case "ERROR_WRONG_PASSWORD":
//         case "wrong-password":
//           return "Wrong email/password combination.";
//
//         case "ERROR_USER_NOT_FOUND":
//         case "user-not-found":
//           return "No user found with this email.";
//
//         case "ERROR_USER_DISABLED":
//         case "user-disabled":
//           return "User disabled.";
//
//         case "ERROR_TOO_MANY_REQUESTS":
//         case "operation-not-allowed":
//           return "Too many requests to log into this account.";
//
//         case "ERROR_INVALID_EMAIL":
//         case "invalid-email":
//           return "Email address is invalid.";
//
//         default:
//           return "Login failed. Please try again.";
//       }
//     }
//     return null;
//   }
//
// // register User with email and password
//   Future registerUserWithEmailAndPassword(
//     String email,
//     String password,
//   ) async {
//     try {
//       await _auth.createUserWithEmailAndPassword(
//           email: email, password: password);
//     } on FirebaseAuthException catch (error) {
//       switch (error.code) {
//         case "ERROR_EMAIL_ALREADY_IN_USE":
//         case "account-exists-with-different-credential":
//         case "email-already-in-use":
//           return "Email already used. Go to login page.";
//
//         case "ERROR_WRONG_PASSWORD":
//         case "wrong-password":
//           return "Wrong email/password combination.";
//
//         case "ERROR_USER_NOT_FOUND":
//         case "user-not-found":
//           return "No user found with this email.";
//
//         case "ERROR_USER_DISABLED":
//         case "user-disabled":
//           return "User disabled.";
//
//         case "ERROR_TOO_MANY_REQUESTS":
//         case "operation-not-allowed":
//           return "Too many requests to log into this account.";
//
//         case "ERROR_OPERATION_NOT_ALLOWED":
//           return "Server error, please try again later.";
//
//         case "ERROR_INVALID_EMAIL":
//         case "invalid-email":
//           return "Email address is invalid.";
//
//         default:
//           return "Registration failed. Please try again.";
//       }
//     }
//     return null;
//   }
//
//   Future<void> sendPasswordResetEmail(String email) async {
//     return _auth.sendPasswordResetEmail(email: email);
//   }
//
// // sign out
//   Future signOut() async {
//     try {
//       return await _auth.signOut();
//     } on FirebaseAuthException catch (e) {
//       print(e);
//       return null;
//     }
//   }
// }
