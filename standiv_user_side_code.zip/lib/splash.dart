
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get.dart';
import 'package:page_transition/page_transition.dart';
import 'package:standivnew/root.dart';
import 'package:standivnew/signin.dart';
import 'package:standivnew/welcome.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key, required });

  // This widget is the sigin page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".



  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }

  List<String> yesVotes=[];
  List<String> noVotes=[];
  List<String> nuetralVotes=[];
  int totalVotes=0;
  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);
  startTime() async {
    var _duration = new Duration(seconds: 3);
    return new Timer(_duration, navigationPage);
  }

  void navigationPage() {
    Navigator.push(context, PageTransition(
        curve: Curves.bounceOut,
        type: PageTransitionType.rotate,
        alignment: Alignment.topCenter,
        duration: Duration(milliseconds: 1000),
         child: WelcomePage()));


    }

  @override
  void initState() {

    final Timestamp oldPosts = Timestamp.fromDate(
      DateTime.now().subtract(const Duration(hours: 24)),);
    final Timestamp broadCastoldPosts = Timestamp.fromDate(
      DateTime.now().subtract(const Duration(minutes: 10)),);

    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("stack",isNotEqualTo: "BroadCasts").where("stack",isNotEqualTo: "Gold Stack")
        .where("timestamp",isLessThan: oldPosts)
        .get().then((QuerySnapshot qs) {
         // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        setState(() {

          //now getting all votes for that post
          FirebaseFirestore.instance
              .collection('votes').where("postId",isEqualTo: doc.id )

              .get().then((QuerySnapshot qsvote) async {
           // print(qs.docs.length.toString());
            nuetralVotes.clear();
            yesVotes.clear();
            nuetralVotes.clear();
            totalVotes= qsvote.docs.length;
            qsvote.docs.forEach((votes) {
              setState(() {
                //now adding all votes to lists e.g yes,no or neutral
                if(votes['voteType']=='neutral'){
                  nuetralVotes.add(votes['voterId']);
                }
                if(votes['voteType']=='yes'){
                  yesVotes.add(votes['voterId']);
                }
                else {
                  noVotes.add(votes['voterId']);
                }

              });

            } );
            print("nasd");
            print(nuetralVotes.length.toString()+"neutral votes");
            print(yesVotes.length.toString()+"yes votes");
            print(noVotes.length.toString()+"no votes");
            // now we calculate function to see winner
            List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
            int winner=votesCheck.indexOf(votesCheck.reduce(max));
            //now we check which vote type has most votes and then we add coins to each user
            print(winner.toString()+"winner");
            double percentage=0;


            //now we add coins for winner
            //we get each users coin value and then add 20 coins for winner
            if(winner==0){
             percentage= (nuetralVotes.length/totalVotes)*100;
              for(int i=0;i<nuetralVotes.length;i++){

                await    FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }

print(qs.docs[0].id);

                });
              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else if(winner==1){
              percentage= (yesVotes.length/totalVotes)*100;
              for(int i=0;i<yesVotes.length;i++){
print(yesVotes[i]);
await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
  if(percentage<60){
    int coins=qs.docs[0]["coins"]+15;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
  else if(percentage<70){
    int coins=qs.docs[0]["coins"]+16;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
  else if(percentage<80){
    int coins=qs.docs[0]["coins"]+17;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
  else if(percentage<90){
    int coins=qs.docs[0]["coins"]+18;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
  else if(percentage<100){
    int coins=qs.docs[0]["coins"]+19;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
  else if(percentage==100){
    int coins=qs.docs[0]["coins"]+20;
    FirebaseFirestore.instance
        .collection("users").doc(nuetralVotes[i]).update({


      "coins": coins,

    });
  }
                  print(qs.docs[0].id);

                });

              }
              if(percentage<60){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+50;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<70){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+55;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<80){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+60;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<90){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+65;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<100){
            await      FirebaseFirestore.instance
                .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                .get().then((QuerySnapshot qs) {
            int coins=qs.docs[0]["coins"]+70;
            FirebaseFirestore.instance
                .collection("users").doc(doc['userid']).update({


            "coins": coins,

            });
            print(qs.docs[0].id);

            });
              }
              else if(percentage==100){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+75;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              };
           
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
                  }
            else{
              percentage= (noVotes.length/totalVotes)*100;
              for(int i=0;i<noVotes.length;i++){
print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

             await   FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
               if(percentage<60){
                 int coins=qs.docs[0]["coins"]+15;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
               else if(percentage<70){
                 int coins=qs.docs[0]["coins"]+16;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
               else if(percentage<80){
                 int coins=qs.docs[0]["coins"]+17;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
               else if(percentage<90){
                 int coins=qs.docs[0]["coins"]+18;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
               else if(percentage<100){
                 int coins=qs.docs[0]["coins"]+19;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
               else if(percentage==100){
                 int coins=qs.docs[0]["coins"]+20;
                 FirebaseFirestore.instance
                     .collection("users").doc(nuetralVotes[i]).update({


                   "coins": coins,

                 });
               }
                });

              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });

            }

          });
        //  print(doc.id);
        //  userDocument=qs.docs[0];
        //  userName=qs.docs[0]['userName'].toString();
        //  totalCoins=qs.docs[0]['coins'].toString();
        });

      } );


    });
    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("stack",isEqualTo: "Gold Stack")
        .where("timestamp",isLessThan: oldPosts)
        .get().then((QuerySnapshot qs) {
      // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        setState(() {

          //now getting all votes for that post
          FirebaseFirestore.instance
              .collection('votes').where("postId",isEqualTo: doc.id )

              .get().then((QuerySnapshot qsvote) async {
            // print(qs.docs.length.toString());
            nuetralVotes.clear();
            yesVotes.clear();
            nuetralVotes.clear();
            totalVotes= qsvote.docs.length;
            qsvote.docs.forEach((votes) {
              setState(() {
                //now adding all votes to lists e.g yes,no or neutral
                if(votes['voteType']=='neutral'){
                  nuetralVotes.add(votes['voterId']);
                }
                if(votes['voteType']=='yes'){
                  yesVotes.add(votes['voterId']);
                }
                else {
                  noVotes.add(votes['voterId']);
                }

              });

            } );
            print("nasd");
            print(nuetralVotes.length.toString()+"neutral votes");
            print(yesVotes.length.toString()+"yes votes");
            print(noVotes.length.toString()+"no votes");
            // now we calculate function to see winner
            List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
            int winner=votesCheck.indexOf(votesCheck.reduce(max));
            //now we check which vote type has most votes and then we add coins to each user
            print(winner.toString()+"winner");
            double percentage=0;


            //now we add coins for winner
            //we get each users coin value and then add 20 coins for winner
            if(winner==0){
              percentage= (nuetralVotes.length/totalVotes)*100;
              for(int i=0;i<nuetralVotes.length;i++){

                await    FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }

                  print(qs.docs[0].id);

                });
              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else if(winner==1){
              percentage= (yesVotes.length/totalVotes)*100;
              for(int i=0;i<yesVotes.length;i++){
                print(yesVotes[i]);
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  print(qs.docs[0].id);

                });

              }
              if(percentage<60){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+100;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<70){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+110;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<80){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+120;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<90){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+130;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<100){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+140;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage==100){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+150;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });
              };

              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else{
              percentage= (noVotes.length/totalVotes)*100;
              for(int i=0;i<noVotes.length;i++){
                print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

                await   FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                });

              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });

            }

          });
          //  print(doc.id);
          //  userDocument=qs.docs[0];
          //  userName=qs.docs[0]['userName'].toString();
          //  totalCoins=qs.docs[0]['coins'].toString();
        });

      } );


    });
    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("stack",isEqualTo: "BroadCasts")
        .where("timestamp",isLessThan: broadCastoldPosts)
        .get().then((QuerySnapshot qs) {
      // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        setState(() {

          //now getting all votes for that post
          FirebaseFirestore.instance
              .collection('votes').where("postId",isEqualTo: doc.id )

              .get().then((QuerySnapshot qsvote) async {
            // print(qs.docs.length.toString());
            nuetralVotes.clear();
            yesVotes.clear();
            nuetralVotes.clear();
            totalVotes= qsvote.docs.length;
            qsvote.docs.forEach((votes) {
              setState(() {
                //now adding all votes to lists e.g yes,no or neutral
                if(votes['voteType']=='neutral'){
                  nuetralVotes.add(votes['voterId']);
                }
                if(votes['voteType']=='yes'){
                  yesVotes.add(votes['voterId']);
                }
                else {
                  noVotes.add(votes['voterId']);
                }

              });

            } );
            print("nasd");
            print(nuetralVotes.length.toString()+"neutral votes");
            print(yesVotes.length.toString()+"yes votes");
            print(noVotes.length.toString()+"no votes");
            // now we calculate function to see winner
            List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
            int winner=votesCheck.indexOf(votesCheck.reduce(max));
            //now we check which vote type has most votes and then we add coins to each user
            print(winner.toString()+"winner");
            double percentage=0;


            //now we add coins for winner
            //we get each users coin value and then add 20 coins for winner
            if(winner==0){
              percentage= (nuetralVotes.length/totalVotes)*100;
              for(int i=0;i<nuetralVotes.length;i++){

                await    FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }

                  print(qs.docs[0].id);

                });
              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else if(winner==1){
              percentage= (yesVotes.length/totalVotes)*100;
              for(int i=0;i<yesVotes.length;i++){
                print(yesVotes[i]);
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {

                    int coins=qs.docs[0]["coins"]+10;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });


                  print(qs.docs[0].id);

                });

              }

                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+2000+(yesVotes.length*2);
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,

                  });
                  print(qs.docs[0].id);

                });



              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else{
              percentage= (noVotes.length/totalVotes)*100;
              for(int i=0;i<noVotes.length;i++){
                print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

                await   FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                });

              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });

            }

          });
          //  print(doc.id);
          //  userDocument=qs.docs[0];
          //  userName=qs.docs[0]['userName'].toString();
          //  totalCoins=qs.docs[0]['coins'].toString();
        });

      } );


    });
    super.initState();
    startTime();
    //get >24 hours where isDone=false
    //get all votes
    //count nuetral, yes and no votes
    //function to get winner
    //now again use the list of winner users
    //add bonus points
    //add losing points to losers
    //add winning points to post poster
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(

      body:
      new Image.asset(
        'assets/splash.jpg',
        fit: BoxFit.cover,
        height: double.infinity,
        width: double.infinity,
        alignment: Alignment.center,
      ),


     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
