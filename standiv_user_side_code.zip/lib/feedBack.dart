
import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:standivnew/phoneverification.dart';
import 'package:standivnew/signin.dart';
import 'package:standivnew/uploadPicture.dart';

import 'homepage.dart';

class FeedBackPage extends StatefulWidget {


  FeedBackPage({super.key, required, });



  @override
  State<FeedBackPage> createState() => _FeedBackPageState();
}

class _FeedBackPageState extends State<FeedBackPage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
bool showVerification=false;
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }

  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override



  // snackBar Widget
  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message!),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);

TextEditingController feedbacklController = TextEditingController();


@override
void initState() {
  super.initState();

}


  @override
  Widget build(BuildContext context) {

    return Scaffold(
backgroundColor: Colors.white,
      body:

     SingleChildScrollView(
            child: Container(

              child: Form(
                key: _formKey,
                child: Column(children: [
  SizedBox(height: 50,),


                  Container(
                    child: Container(
                      margin: EdgeInsets.only(bottom:100 ),
                          height:Get.height*0.90,
                          width: Get.width,
                        color: Colors.white,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Center(child:

                                Column(children: [
                                  SizedBox(height: 10,),
                                  Container(
                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                    child: Container(

                                        color: Colors.white,
                                        height: 40,
                                        width: Get.width,

                                        child:
                                        Row(children: [
                                          SizedBox(width: 10,),
                                          InkWell(
                                            onTap: (){
                                              Navigator.pop(context);

                                            },
                                            child:ImageIcon(
                                              AssetImage("assets/backicon.png"),color: Colors.black,
                                              size: 25,
                                            ),
                                          ),
                                          Spacer(),
                                          Text( "Feedback",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                                          Spacer(),
                                          Spacer(),

                                        ],)
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  SizedBox(height: 30,),

                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.80,
                                    child: TextFormField(
                                      minLines: 9,

                                      maxLines: 15,
                                      validator: (value){
                                        if(value==""){

                                          return "Please give us your valuable feedback";
                                        }

                                      },
                                      controller: feedbacklController,
                                      textAlign: TextAlign.start,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(10.0),
                                          ),

                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.grey[600],fontSize: 18,),

                                          hintText: "Please give us your valuable feedback, inorder for us to \nimprove app experience",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),



                                  InkWell(
                                    onTap: () async {

    if (_formKey.currentState!.validate()) {
snackBar("Thank you ! Your feedback is valueable to us and helps us  improve user experience");
Navigator.pop(context);
    }

                                    },
                                    child: new Container(
                                      margin: EdgeInsets.only(top: 10),
                                      width: 50,
                                      height: 50,
                                      decoration: new BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            Color.fromRGBO(146, 31, 23, 1),
                                            Color.fromRGBO(188, 40, 28, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                          ],),
                                     //   color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: new Icon(
                                        Icons.feedback_outlined,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  Text("Submit Feedback",style: TextStyle(color:Colors.black54,fontSize: 16),),



                                ],),)

                              ],)
                      ),
                  ),


                ],),
              ),
            ),
          )




     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? verificationId;
  String? otp, authStatus = "";



}
