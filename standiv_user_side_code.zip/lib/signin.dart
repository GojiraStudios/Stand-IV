
import 'dart:async';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:shared_preferences/shared_preferences.dart';
//import 'package:shared_preferences/shared_preferences.dart';
import 'package:standivnew/homepage.dart';
import 'package:standivnew/instrcutionsScreen.dart';
import 'package:standivnew/phoneverification.dart';
import 'package:standivnew/root.dart';
import 'package:standivnew/signup.dart';

class siginPage extends StatefulWidget {
  const siginPage({super.key, required });




  @override
  State<siginPage> createState() => _siginPageState();
}

class _siginPageState extends State<siginPage> {
 // late prefs =  SharedPreferences.getInstance();
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }

  startTime(String userId) async {
    var _duration = new Duration(seconds: 4);
    return new Timer(_duration, navigationPage( userId));
  }
   navigationPage(String userId) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => InstructionsScreen(uid:userId ,)));


  }

  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);


// for phone number
  TextEditingController phoneController = TextEditingController();
  // for pin
  final pinController = TextEditingController();
  bool loading = false;
  bool showVerification=false;
  // for otp
  TextEditingController textEditingController = TextEditingController();
  // for notifications
  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();
bool isLoading=false;
  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();

    super.initState();
  }
 // bool isPin=false;
  @override

/*
     Text("Login to your account below or signup",
                                style: TextStyle(color:Colors.black54,fontSize: 19,fontWeight: FontWeight.w400,),),

                              SizedBox(height: 5,),
                              Text(" for an amazing experience",
                                style: TextStyle(color:Colors.black54,fontSize: 19,fontWeight: FontWeight.w400,),),
                              SizedBox(height: 15,),

 */
  @override
  Widget build(BuildContext context) {
   return WillPopScope(
      onWillPop: (){
        setState(() {
          showVerification=false;
        });
return Future.value(false);
      },

      child: Scaffold(
backgroundColor: Colors.black,
        body:

        showVerification==false?
        isLoading?
        SingleChildScrollView(
          child: Container(
            height: Get.height,
            child: Center(child:
            CircularProgressIndicator(color: Colors.red,strokeWidth: 5,)),
          ),
        )

            :Form(
          key: _formKey,
              child: SingleChildScrollView(
                child: Column(children: [
  SizedBox(height: 50,),
 Container(
                      color: Colors.white,
                      child: Container(
                          height:Get.height*0.40,
                          width: Get.width,
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(75),
                            ),
                            border: Border.all(
                              width: 0,

                             // style: BorderStyle.solid,
                            ),
                          ),
                          child: Center(
                           child: new Image.asset(
                              'assets/logo.png',

                              height: 180,

                              alignment: Alignment.center,
                            ),
                          )
                      ),
                    ),

                  Container(
                    child: Container(
                      margin: EdgeInsets.only(bottom:100 ),
                          height:Get.height,
                          width: Get.width,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              width: 0,
                              color: Colors.white,

                            ),
                            borderRadius: BorderRadius.only(

                              topLeft: Radius.circular(75),
                              //topRight: Radius.circular(90),
                            ),

                          ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Center(child: Column(children: [
                                  SizedBox(height: 30,),
                                  Text("Let's get started",style:
                                  TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
                                  SizedBox(height: 15,),
                                  Text("Login to your account below or signup",
                                    style: TextStyle(color:Colors.black54,fontSize: 19,fontWeight: FontWeight.w400,),),

                                  SizedBox(height: 5,),
                                  Text(" for an amazing experience",
                                    style: TextStyle(color:Colors.black54,fontSize: 19,fontWeight: FontWeight.w400,),),
                                  SizedBox(height: 15,),

                          Container(
                                    margin: EdgeInsets.only(top: 15),

                                    width: Get.width*0.75,
                                    child: IntlPhoneField(
                                      decoration: InputDecoration(
                                        //labelText: 'Phone Number',
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.black45,fontSize: 18),
                                          hintText: "Enter your Phone Number",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                      initialCountryCode: 'IN',
                                      onChanged: (phone) {
                                        setState(() {
                                          // this.phoneNumber=phone.completeNumber.toString();
                                          phoneController = new TextEditingController(text: phone.completeNumber);

                                        });

                                        print(phone.completeNumber);
                                      },
                                    ),
                                  ),

                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your pin";
                                        }

                                      },
                                      keyboardType: TextInputType.number,
                                      inputFormatters: <TextInputFormatter>[
                                        // for below version 2 use this
                                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
// for version 2 and greater youcan also use this
                                        FilteringTextInputFormatter.digitsOnly,
                                        LengthLimitingTextInputFormatter(6),

                                      ],

                                      controller: pinController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.grey[600],fontSize: 18),
                                          hintText: "Enter your Pincode",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),
                                  SizedBox(height: 10,),

                                  InkWell(
                                    onTap: () async {
                                      if (_formKey.currentState!.validate()) {
    setState(() {
    isLoading=true;
    });


      verifyPhoneNumber(context);



                                      }


                                    },
                                    child: new Container(
                                      margin: EdgeInsets.only(top: 10),
                                      width: 50,
                                      height: 50,
                                      decoration: new BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            Color.fromRGBO(146, 31, 23, 1),
                                            Color.fromRGBO(188, 40, 28, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                          ],),
                                     //   color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: new Icon(
                                        Icons.arrow_forward,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),),
                                  SizedBox(height: 10,),
                                  // InkWell(
                                  //   onTap: (){
                                  //     Navigator.push(
                                  //         context,
                                  //         MaterialPageRoute(
                                  //             builder: (context) => SignUpPage(loggedIn: true,)));
                                  //
                                  //
                                  //   },
                                  //   child: Row(
                                  //     mainAxisAlignment: MainAxisAlignment.center,
                                  //     children: [
                                  //       RichText(
                                  //         text: TextSpan(
                                  //             text: 'Don’t have an account? ',
                                  //             style: TextStyle(
                                  //               color: Colors.black54,
                                  //               fontSize: 16,
                                  //             ),
                                  //             children: <TextSpan>[
                                  //               TextSpan(
                                  //                 text: 'Register',
                                  //                 style: TextStyle(
                                  //                   color: Colors.red,
                                  //                   fontSize: 16,
                                  //                 ),
                                  //
                                  //               ),
                                  //             ]),
                                  //       ),
                                  //     ],
                                  //   ),
                                  // ),


                                ],),)

                              ],)
                      ),
                  ),


                ],),
              ),
            ):
        Material(

      child: SingleChildScrollView(
      child: Column(children: [
        SizedBox(height: 50,),

      Container(
      color: Colors.white,
      child: Container(
      height:Get.height*0.40,
      width: Get.width,
      decoration: BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.only(
      bottomRight: Radius.circular(75),
      ),
      border: Border.all(
      width: 0,

      // style: BorderStyle.solid,
      ),
      ),
      child: Center(
      child: new Image.asset(
      'assets/otp.png',

      height: 180,

      alignment: Alignment.center,
      ),
      )
      ),
      ),

      Container(
      child: Container(
      margin: EdgeInsets.only(bottom:100 ),
      height:Get.height*0.80,
      width: Get.width,
      decoration: BoxDecoration(
      color: Colors.white,
      border: Border.all(
      width: 0,
      color: Colors.white,

      ),
      borderRadius: BorderRadius.only(

      topLeft: Radius.circular(75),
      //topRight: Radius.circular(90),
      ),

      ),
      child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
      Center(child: Column(children: [
      SizedBox(height: 30,),
      Text("Verify Your Number",style:
      TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
      SizedBox(height: 15,),
      Text("Please enter your verification code recieved",
      style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),

      SizedBox(height: 5,),
      Text(" on your phone number",
      style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),
      SizedBox(height: 15,),
      Form(
      key: formKey,
      child: Padding(
      padding: const EdgeInsets.symmetric(
      vertical: 8.0, horizontal: 30),
      child: PinCodeTextField(

      appContext: context,
      pastedTextStyle: TextStyle(
      color: Colors.green.shade600,
      fontWeight: FontWeight.bold,
      ),
      length: 6,
      // obscureText: true,
      // obscuringCharacter: '*',
      // obscuringWidget: const FlutterLogo(
      //   size: 24,
      // ),
      // blinkWhenObscuring: true,
      animationType: AnimationType.fade,
      validator: (v) {
      if (v!.length < 6) {
      return "Please Enter Valid verification Code";
      } else {
      return null;
      }
      },
      pinTheme: PinTheme(
      inactiveColor: Colors.black,
      inactiveFillColor: Color.fromRGBO(243, 243, 245, 1).withOpacity(1),
      shape: PinCodeFieldShape.box,

      borderRadius: BorderRadius.circular(10),
      borderWidth: 1,
      fieldHeight: 50,
      fieldWidth: 50,
      activeFillColor: Colors.white,
      ),
      cursorColor: Colors.black,
      animationDuration: const Duration(milliseconds: 300),
      enableActiveFill: true,
      errorAnimationController: errorController,
      controller: textEditingController,
      keyboardType: TextInputType.number,
      boxShadows: const [
      BoxShadow(
      offset: Offset(0, 1),
      color: Colors.grey,
      blurRadius: 10,
      )
      ],
      onCompleted: (v) {
      debugPrint("Completed");
      },
      // onTap: () {
      //   print("Pressed");
      // },
      onChanged: (value) {
      debugPrint(value);
      setState(() {
      currentText = value;
      });
      },
      beforeTextPaste: (text) {
      debugPrint("Allowing to paste $text");
      //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
      //but you can show anything you want here, like your pop up saying wrong paste format or etc
      return true;
      },
      )),
      ),

      const SizedBox(height: 15,),


      InkWell(
      onTap: () async {


          signIn(textEditingController.text);


      },
      child:
      new Container(
      margin: EdgeInsets.only(top: 10),
      width: 50,
      height: 50,
      decoration: new BoxDecoration(
      gradient: LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: [
      Color.fromRGBO(146, 31, 23, 1),
      Color.fromRGBO(188, 40, 28, 1),
      Color.fromRGBO(232, 50, 35, 1),
      Color.fromRGBO(232, 50, 35, 1),
      Color.fromRGBO(232, 50, 35, 1),
      ],),
      //   color: Colors.red,
      shape: BoxShape.circle,
      ),
      child: new Icon(
      Icons.arrow_forward,
      color: Colors.white,
      ),
      ),
      ),
      SizedBox(height: 10,),
      Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),)
      ],),)

      ],)
      ),
      ),


      ],),
      ),
      )



       // This trailing comma makes auto-formatting nicer for build methods.
      ),
    );
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? verificationId;
  String? otp, authStatus = "";

  // this function sends otp to the phone number for authentication
  Future<void> verifyPhoneNumber(BuildContext context) async {
    //await FirebaseAuth.instance.signOut();
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phoneController.text,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (AuthCredential authCredential) {
        setState(() {
          print("Your account is successfully verified");
          authStatus = "Your account is successfully verified";
        });
      },
      verificationFailed: (FirebaseAuthException authException) {
        setState(() {
          authStatus = "Authentication failed";
          print(authException.toString());
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: Colors.red,
              content: Text(authException.toString()),
            ),
          );
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => RootScreen(newUser: false,)));



        });
      },
      codeSent: (String verId,int?   forceCodeResent) async {
        verificationId = verId;
        setState(() {

          authStatus = "OTP has been successfully send";
          showVerification=true;
        });

        print(verificationId.toString()+"yesss");


      },
      codeAutoRetrievalTimeout: (String verId) {
        verificationId = verId;
     if(nextScreen==false)  { setState(() {
          print("TIMEOUT");
          showVerification=false;
          isLoading=false;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: Colors.red,
              content: Text("OTP timeout, please try again"),
            ),
          );
          authStatus = "TIMEOUT";
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => RootScreen(newUser: false,)));


     });}
      },
    );
  }

  // this functions verifies otp and then logs in user
  Future<void> signIn(String otp) async {
   final prefs = await SharedPreferences.getInstance();
    String? userId;
    await FirebaseAuth.instance
        .signInWithCredential(PhoneAuthProvider.credential(

      verificationId: verificationId!,
      smsCode: otp,
    )).catchError((e){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text(e.toString()),
        ),
      );
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => RootScreen(newUser: false,)));



    }).then((value) async =>
    {


// Save an integer value to 'counter' key.

    await prefs.setBool('isFirst', true),
      this.showVerification=false,
      userId=value.user!.uid.toString(),

     // Change here

        _firebaseMessaging.getToken().then((token){
          // this is a check if user already exsists or not
          FirebaseFirestore.instance
              .collection('users').where("userid",isEqualTo:userId ).limit(1)
              .get().then((QuerySnapshot qs) async {
                //if user exsists then we just update device token for notifications
            if(qs.docs.length>0){
              await FirebaseFirestore.instance
                  .collection("deviceTokens").doc(userId).set({


                "userToken": token,

              }).whenComplete(() => {

                // await FirebaseAuth.instance.signOut();
              // setState(() {
              //
              // }),
              this.nextScreen=true,
                  // Navigator.push(
                  // context,
                  // MaterialPageRoute(
                  //     builder: (context) => HomePage(isNew: true,)))




            });
           }
            // else we create new user and also new device token for notifications
            else{
        await     FirebaseFirestore.instance
                  .collection("users").doc(userId).set({

                "userid": userId,
                "firstName": "StandIV",
                "lastName" :"",
                "phone": phoneController.text,
                "level": "bronze",
                "pin": pinController.text,
                "gender":"",
                "deviceToken": token,
                "winningPost":0,
                "coins" : 10000,
                "profileImageUrl":"",
          "isFirstLoggedIn":true,
              }).whenComplete(
                   () async {
           //     final prefs = await SharedPreferences.getInstance();
              //  await prefs.setString('userId', userId!);
             //   print( prefs.getString('userId'));
           await  FirebaseFirestore.instance
                    .collection("deviceTokens").doc(userId).set({


                  "userToken": token,

                }).whenComplete(
                  () => {

                // await FirebaseAuth.instance.signOut();

                this.nextScreen=true,

                  // Navigator.pushReplacement(
                  // context,
                  // MaterialPageRoute(
                  // builder: (context) => RootScreen(newUser: true,))),








           });

              });
            }


          });

       //   print("token is $token");
    }),

   //   print(  value.user!.uid.toString())

    });
  }
bool nextScreen=false;

}
