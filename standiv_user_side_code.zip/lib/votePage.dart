
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:standivnew/homepage.dart';
import 'package:standivnew/phoneverification.dart';

class VotePage extends StatefulWidget {
  String stackType;
  final String uId;
  final int totalPosts;
  final int totalVoted;
   VotePage({super.key, required,required this.stackType,required this.uId,required this.totalPosts,required this.totalVoted });


  @override
  State<VotePage> createState() => _VotePageState();
}

class _VotePageState extends State<VotePage> {

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }
  Timer? _timer;
  int _start = 20;
bool isLoading=true;
bool cardStatus=false;
  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
          votersList[currentImage].add(widget.uId);
       //  currentPostVoterList.add(FirebaseAuth.instance.currentUser!.uid);
            FirebaseFirestore.instance
                .collection('posts')
                .doc(postId[currentImage])
                .update({'voter': votersList[currentImage]}).catchError((e) {
              print(e);
            }).whenComplete(() => {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  backgroundColor: Colors.red,
                  content: Text("Your vote will be counted as Neutral"),

                ),

              ),
              FirebaseFirestore.instance
                  .collection('votes')
                  .add({'voterId':widget.uId,
               'postId':postId[currentImage],
              'voteType':'neutral'
              }).catchError((e) {
                print(e);
              }).whenComplete(() => {
            currentImage=currentImage+1,
            _start=20,
              timer.cancel(),
            }),
              // Navigator.push(
              // context,
              // MaterialPageRoute(
              // builder: (context) => PhoneVerificationPage()))


            });
          // currentImage=currentImage+1;
          // _start=20;

          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  @override
  // void dispose() {
  //  // _timer!.dis;
  //   super.dispose();
  // }
  bool flipOnTouch=true;
  _renderContent(context) {
    return Card(
      elevation: 0.0,
    //  margin: EdgeInsets.only(left: 32.0, right: 32.0, top: 20.0, bottom: 0.0),
      color: Color(0x00000000),
      child: FlipCard(
flipOnTouch: flipOnTouch,
        direction: FlipDirection.VERTICAL,
        speed: 1000,

        onFlipDone: (status) {
          if(status){
            setState(() {
              this.flipOnTouch=false;
              this.cardStatus=status;
            });

           // _timer!.cancel();
            startTimer();

          }
          else{
            setState(() {
              this.cardStatus=status;
              _timer!.cancel();
              _start=20;
            });

          }
          print(status);
        },
        front: Container(
          margin: EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(

            borderRadius: BorderRadius.all(Radius.circular(8.0)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                // padding: EdgeInsets.symmetric(horizontal: 10),
                width: Get.width,
                height:Get.height*0.60,


                child:
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child:
                      widget.stackType=="Gold Stack"?
                      Container(
                        width: Get.width*0.90,
                        height:Get.height*0.58,
                        child: Image(
                          fit: BoxFit.fitHeight,
                          image: AssetImage(
                            'assets/card.png',),
                        ),
                      ):
                      Stack(children: [
                        Container(
                          width: Get.width*0.90,
                          height:Get.height*0.58,
                          child: Image(
                            fit: BoxFit.fitHeight,
                            image: AssetImage(
                              'assets/card.png',),
                          ),
                        ),
                       Center(
                          child:Container(
                            margin: EdgeInsets.only(top: 10),
                          width: Get.width*0.70,
                            height:Get.height*0.58,
                          child: Image(
                           // fit: BoxFit.fitWidth,
                            image: AssetImage(
                              widget.stackType=="Bronze Stack"?
                              'assets/bronzebadge.png':
                              widget.stackType=="Silver Stack"?
                              'assets/silberbadge.png':
                              'assets/brosadcasts.png',),
                          ),
                        ) ,)

                      ],)

                    ),
                     Align(
                       alignment: Alignment.bottomCenter,
                       child: Container(

                          margin: EdgeInsets.only(top: 70),
                          width:Get.width*0.70,
                          height: 50,
                          decoration: new BoxDecoration(
                            borderRadius: new BorderRadius.circular(360.0),
                            gradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                Color.fromRGBO(146, 31, 23, 1),
                                Color.fromRGBO(188, 40, 28, 1),
                                Color.fromRGBO(232, 50, 35, 1),
                                Color.fromRGBO(232, 50, 35, 1),
                                Color.fromRGBO(232, 50, 35, 1),
                              ],),
                            //   color: Colors.red,

                          ),
                          child:

                          Center(child: Text("Flip the Card",style: TextStyle(color: Colors.white,
                              fontWeight: FontWeight.w500),))
                    ),
                     ),
                    Positioned(child:
                    Align(
                        alignment: Alignment.topCenter,
                        child:
                        Container(
                            margin: EdgeInsets.only(top:15, ),
                          height:25,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.red,
                            border: Border.all(
                              width: 0,
                              color: Colors.red,

                            ),
                            gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: <Color>[
                                  Color.fromRGBO(146, 31, 23, 1),
                                  Color.fromRGBO(188, 40, 28, 1),
                                  Color.fromRGBO(232, 50, 35, 1),

                                  Color.fromRGBO(232, 50, 35, 1),
                                  Color.fromRGBO(232, 50, 35, 1),
                                  Color.fromRGBO(232, 50, 35, 1),





                                ]),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 6,
                                blurRadius: 7,
                                offset: Offset(0, 3), // changes position of shadow
                              ),
                            ],
                            borderRadius: BorderRadius.all(

                              Radius.circular(8),
                              //topRight: Radius.circular(90),
                            ),

                          ),
                          child:

                          Center(child:

                          RichText(
                            text: TextSpan(
                                children: <TextSpan>[
                                  TextSpan(text: widget.totalVoted.toString()+'/',
                                    style:   GoogleFonts.lato(textStyle:TextStyle(
                                        color: Colors.white, fontSize: 15,
                                        fontWeight: FontWeight.bold)),

                                  ),
                                  TextSpan(text: widget.totalPosts.toString(),
                                    style:
                                    GoogleFonts.lato(textStyle:
                                    TextStyle(
                                        color: Colors.white.withOpacity(0.6,),
                                        fontSize: 12)),

                                  )
                                ]
                            ),
                          ),

                          ),

                        )

                    ))
                  ],
                ),
                //  child: Image.asset("assets/stacktwo.jpeg",fit: BoxFit.fill,)
              ),    ],
          ),
        ),
        back:           Container(
          //   margin: EdgeInsets.symmetric(horizontal:20 ),


            child: Column(children: [


              Container(

                height:Get.height*0.65,
                margin: EdgeInsets.symmetric(horizontal: 20),
                child: Stack(
                  alignment: AlignmentDirectional.topCenter,
                  children: <Widget>[

                    Positioned(

                      left: 15,

                      width: Get.width*0.80,
                      height:Get.height*0.60,
                      child:
                       imageUrl.length>currentImage+1?
                       Container(
                        // padding: EdgeInsets.symmetric(horizontal: 10),
                        width: Get.width*0.30,
                        height:Get.height*0.60,
                        decoration: BoxDecoration(
                          color: Colors.green[300],
                          border: Border.all(
                            width: 0,
                            color: Colors.white,

                          ),

                          borderRadius: BorderRadius.all(

                            Radius.circular(20),
                            //topRight: Radius.circular(90),
                          ),

                        ),

                        child:
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child:
                          imageUrl.length>1?Image(
                            fit: BoxFit.fill,
                            image:

                           NetworkImage(
                              imageUrl[currentImage+1],),
                          ):
                          Image(
                            fit: BoxFit.fill,
                            image:

                            AssetImage(
                              'assets/stacktwo.jpeg',),
                          ),
                        ),
                        //  child: Image.asset("assets/stacktwo.jpeg",fit: BoxFit.fill,)
                      ):SizedBox(),
                    ),
                    Positioned(
                      top: 20,
                      //left: 30,
                      //right: 10,
                      height:Get.height*0.60,
                      width: Get.width*0.85,
                      child:
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),


                          borderRadius: BorderRadius.all(

                            Radius.circular(20),
                            //topRight: Radius.circular(90),
                          ),

                        ),
                        // width: Get.width,
                        height:Get.height*0.60,
                        child:
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child:
                          imageUrl.length>0?Image(
                            fit: BoxFit.fill,
                            image:

                            NetworkImage(
                              imageUrl[currentImage],),
                          ):
                          Image(
                            fit: BoxFit.fill,
                            image:

                            AssetImage(
                              'assets/stacktwo.jpeg',),
                          ),
                        ),
                        //  child: Image.asset("assets/stackone.jpeg",)
                      ),
                    ),
                    Positioned(

                      top: 25,
                      //left: 30,
                      //right: 10,
                      height:20,
                      width: 50,
                      child: Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.5),


                            borderRadius: BorderRadius.all(

                              Radius.circular(20),
                              //topRight: Radius.circular(90),
                            ),

                          ),
                          // width: Get.width,
                          height:20,
                          width: 60,
                          child: Center(child:Text(_start.toString(),style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)),

                          //  child: Image.asset("assets/stackone.jpeg",)
                        ),
                      ),
                    ),

                  ],
                ),
              ),


            ],)
        ),
      ),
    );
  }

  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);

List<String> imageUrl=[];
List<String> postId=[];
List<List<String>> votersList=[];
int currentImage=0;
  @override
 void initState()   {
    FirebaseFirestore.instance
        .collection('posts').where("stack",isEqualTo: widget.stackType ).where("isDone",isEqualTo: false ).where("userid",isNotEqualTo: FirebaseAuth.instance.currentUser!.uid )
        .get().then((QuerySnapshot qs) {
      qs.docs.forEach((doc) {
        if( List.castFrom( doc["voter"]).contains(widget.uId) !=true){
          setState(() {
            imageUrl.add(doc["postImageUrl"]);
            postId.add(doc.id);
            print(doc["postImageUrl"]);
            votersList.add(List.castFrom( doc["voter"]));
            print(votersList);
            print(doc.id);
            isLoading=false;
          });
        }



      });
    }).then((value) => {
    setState(() {
    isLoading=false;
    }),

    });


    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(


backgroundColor: Colors.white,
      body:
isLoading?
Center(child:
CircularProgressIndicator(color: Colors.red,)):
          SingleChildScrollView(
            child: Column(children: [
  SizedBox(height: 70,),


              Container(
                margin: EdgeInsets.symmetric(horizontal: 20),
                child: Container(

                    color: Colors.white,
                    height: 40,
                width: Get.width,

                child:
                Row(children: [
                  SizedBox(width: 10,),
                   InkWell(
                     onTap: (){
                       Navigator.pop(context);

                     },
                     child:ImageIcon(
                       AssetImage("assets/backicon.png"),color: Colors.black,
                       size: 25,
                  ),
                   ),
                  SizedBox(width: 70,),
                   Text( widget.stackType,style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                  Spacer(),

                ],)
                ),
              ),
              imageUrl.length>=currentImage+1?    Column(children: [
                SizedBox(height: 10,),

                _renderContent(context),

                Center(child: Text("Stand  IV",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 14)),),
           cardStatus?
           Column(children: [
               Row(children: [
                 Spacer(),
                 InkWell(
                   onTap: (){
                     setState(() {
                       setState(() {
                         votersList[currentImage].add(widget.uId);
                         //  currentPostVoterList.add(FirebaseAuth.instance.currentUser!.uid);
                         FirebaseFirestore.instance
                             .collection('posts')
                             .doc(postId[currentImage])
                             .update({'voter': votersList[currentImage]}).catchError((e) {
                           print(e);
                         }).whenComplete(() => {
                           // ScaffoldMessenger.of(context).showSnackBar(
                           //   SnackBar(
                           //     backgroundColor: Colors.red,
                           //     content: Text("Thanks for voting"),
                           //
                           //   ),
                           //
                           // ),
                           // Navigator.push(
                           // context,
                           // MaterialPageRoute(
                           // builder: (context) => PhoneVerificationPage()))
                           FirebaseFirestore.instance
                               .collection('votes')
                               .add({'voterId':widget.uId,
                             'postId':postId[currentImage],
                             'voteType':'no'
                           }).whenComplete(() => {



                           }).catchError((e) {
                             print(e);
                           }).whenComplete(() => {
                         currentImage=currentImage+1,
                         _start=20,
                         }),

                         });

                       });

                       // currentImage=currentImage+1;
                       // _start=20;

                     });


                   },
                   child:new Container(

                       margin: EdgeInsets.only(top: 10),
                       width:Get.width*0.35,
                       height: 55,
                       decoration: new BoxDecoration(
                         borderRadius: new BorderRadius.circular(360.0),
                         gradient: LinearGradient(
                           begin: Alignment.centerLeft,
                           end: Alignment.centerRight,
                           colors: [

                             Color.fromRGBO(232, 50, 35, 1),
                             Color.fromRGBO(232, 50, 35, 1),
                           ],),
                         //   color: Colors.red,

                       ),
                       child:

                       Center(child: Text("No",style: TextStyle(color: Colors.white,
                           fontWeight: FontWeight.w500),))
                   ),
                 ),
                 Spacer(),
                 InkWell(

                   onTap: (){
                     setState(() {

                         votersList[currentImage].add(widget.uId);
                         //  currentPostVoterList.add(FirebaseAuth.instance.currentUser!.uid);
                         FirebaseFirestore.instance
                             .collection('posts')
                             .doc(postId[currentImage])
                             .update({'voter': votersList[currentImage]}).catchError((e) {
                           print(e+"asdds");
                         }).whenComplete(() => {
                           // ScaffoldMessenger.of(context).showSnackBar(
                           //   SnackBar(
                           //     backgroundColor: Colors.red,
                           //     content: Text("thanks for voting"),
                           //
                           //   ),
                           //
                           // ),
                           FirebaseFirestore.instance
                               .collection('votes')
                               .add({'voterId': widget.uId,
                             'postId':postId[currentImage],
                             'voteType':'yes'
                           }).catchError((e) {
                             print(e);
                           }).whenComplete(() => {
                         currentImage=currentImage+1,
                         _start=20,
                         }),
                           // Navigator.push(
                           // context,
                           // MaterialPageRoute(
                           // builder: (context) => PhoneVerificationPage()))


                         });


                       // currentImage=currentImage+1;
                       // _start=20;
                     });


                   },
                   child: new Container(

                       margin: EdgeInsets.only(top: 10),
                       width:Get.width*0.35,
                       height: 55,
                       decoration: new BoxDecoration(
                         borderRadius: new BorderRadius.circular(360.0),
                         gradient: LinearGradient(
                           begin: Alignment.centerLeft,
                           end: Alignment.centerRight,
                           colors: [

                             Color.fromRGBO(135, 209, 63, 1),
                             Color.fromRGBO(135, 209, 63, 1),

                           ],),
                         //   color: Colors.red,

                       ),
                       child:

                       Center(child: Text("Yes",style: TextStyle(color: Colors.white,
                           fontWeight: FontWeight.w500),))
                   ),
                 ),
                 Spacer(),


               ],),

               InkWell(
                 onTap: (){
                   setState(() async {
                     votersList[currentImage].add(widget.uId);
                     //  currentPostVoterList.add(FirebaseAuth.instance.currentUser!.uid);
               FirebaseFirestore.instance
                         .collection('posts')
                         .doc(postId[currentImage])
                         .update({'voter': votersList[currentImage]}).catchError((e) {
                       print(e);
                     }).whenComplete(() async => {
                       // ScaffoldMessenger.of(context).showSnackBar(
                       //   SnackBar(
                       //     backgroundColor: Colors.red,
                       //     content: Text("Your vote will be counted as Neutral"),
                       //
                       //   ),
                       //
                       // ),
                       print(postId.length.toString()+"this is current image"),
                       print(currentImage.toString()+"this is current image"),
                      FirebaseFirestore.instance
                           .collection('votes')
                           .add({'voterId': widget.uId,
                         'postId':postId[currentImage],
                         'voteType':'neutral'
                       }).catchError((e) {
                         print(e);
                       }).whenComplete(() => {
                   currentImage=currentImage+1,
                       _start=20,
                   }),
                       // Navigator.push(
                       // context,
                       // MaterialPageRoute(
                       // builder: (context) => PhoneVerificationPage()))


                     });


                   });


                 },
                 child: new Container(

                     margin: EdgeInsets.only(top: 10),
                     width:Get.width*0.70,
                     height: 55,
                     decoration: new BoxDecoration(
                       borderRadius: new BorderRadius.circular(360.0),
                       gradient: LinearGradient(
                         begin: Alignment.centerLeft,
                         end: Alignment.centerRight,
                         colors: [
                           Color.fromRGBO(140, 140, 140, 1),
                           Color.fromRGBO(140, 140, 140, 1),
                         ],),
                       //   color: Colors.red,

                     ),
                     child:

                     Center(child: Text("Neutral",style: TextStyle(color: Colors.white,
                         fontWeight: FontWeight.w500),))
                 ),
               ),


             ],):SizedBox()


              ],):




              Container(
                height: Get.height*0.80,
                child:
                Center(child: Text("No More Images To Load",style: TextStyle(fontSize: 16,color: Colors.grey),)),),



            ],),
          )



     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
