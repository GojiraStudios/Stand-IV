package com.standiv.standivnew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
