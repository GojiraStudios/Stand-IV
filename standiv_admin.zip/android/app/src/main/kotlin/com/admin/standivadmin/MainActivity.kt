package com.admin.standivadmin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
