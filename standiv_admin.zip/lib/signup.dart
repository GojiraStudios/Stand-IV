
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
//import 'package:shared_preferences/shared_preferences.dart';
import 'package:standivadmin/phoneverification.dart';
import 'package:standivadmin/signin.dart';
import 'package:standivadmin/uploadPicture.dart';

class SignUpPage extends StatefulWidget {
  bool loggedIn;
SignUpPage({super.key, required, required this.loggedIn });

  // This widget is the  page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".



  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
bool isPin=true;
bool showVerification=false;
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }

  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  void initState()  {

    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }



  // snackBar Widget
  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message!),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);

  final nameController = TextEditingController();
TextEditingController phoneController = TextEditingController();
  final pinController = TextEditingController();

  bool loading = false;

bool isLoading=false;

String? gender;
List<String>  genderList=['Male','Female', 'Others',];
  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
backgroundColor: Colors.white,
      body:

        showVerification==false?
        isLoading?
        SingleChildScrollView(
          child: Container(
            height: Get.height,
            child: Center(child:
            CircularProgressIndicator(color: Colors.red,strokeWidth: 5,)),
          ),
        )

            :  SingleChildScrollView(
            child: Container(

              child: Form(
                key: _formKey,
                child: Column(children: [
  SizedBox(height: 50,),


                  Container(
                    child: Container(
                      margin: EdgeInsets.only(bottom:100 ),
                          height:Get.height*0.80,
                          width: Get.width,
                        color: Colors.white,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Center(child:

                                Column(children: [
                                  SizedBox(height: 10,),
                                  Container(
                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                    child: Container(

                                        color: Colors.white,
                                        height: 40,
                                        width: Get.width,

                                        child:
                                        Row(children: [
                                          SizedBox(width: 10,),
                                          InkWell(
                                            onTap: (){
                                              Navigator.pop(context);

                                            },
                                            child:ImageIcon(
                                              AssetImage("assets/backicon.png"),color: Colors.black,
                                              size: 25,
                                            ),
                                          ),
                                          Spacer(),
                                          Text( "SignUp",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                                          Spacer(),
                                          Spacer(),

                                        ],)
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  SizedBox(height: 30,),
                                  Text("Let's get started",style:
                                  TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
                                  SizedBox(height: 15,),
                                  Text("Signup for an amazing experience",
                                    style: TextStyle(color:Colors.black54,fontSize: 19,fontWeight: FontWeight.w400,),),

                                  SizedBox(height: 15,),
                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your name";
                                        }

                                      },

                                      controller: nameController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.black45,fontSize: 18),
                                          hintText: "Name",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  ),

                                  SizedBox(height: 10,),
                                  SizedBox(height: 15,),

                                  Container(
                                 decoration:   BoxDecoration(
                                        color: Color.fromRGBO(243, 243, 245, 1),
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                  width: Get.width*0.75,
                                    height: 60,
                                    child: DropdownButton2(
                                      underline: SizedBox(),
                                      isExpanded: true,
                                      hint: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: const [

                                          SizedBox(
                                            width: 5,
                                          ),
                                          Center(
                                            child: Text(
                                              'Select Gender',
                                              style: TextStyle(
                                                fontSize: 18,
color: Colors.black45

                                              ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                      items: genderList
                                          .map((item) => DropdownMenuItem<String>(
                                        value: item,
                                        child: Center(
                                          child: Text(
                                            item,
                                            style: const TextStyle(
                                              fontSize: 18,

                                              color: Colors.black,
                                            ),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ))
                                          .toList(),
                                      value: gender,
                                      onChanged: (value) {
                                        setState(() {


                                          if(gender!=value){
                                            gender= gender = value as String;
                                          }




                                        });
                                      },
                                      icon: const Icon(
                                        Icons.arrow_drop_down_outlined,
                                      ),
                                      iconSize: 20,
                                      iconEnabledColor: Colors.black45,
                                      iconDisabledColor: Colors.grey,

                                      buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                                      buttonElevation: 2,
                                      itemHeight: 40,
                                      itemPadding: const EdgeInsets.only(left: 15, right: 15),
                                      dropdownMaxHeight: 200,
                                      dropdownWidth: 200,
                                      dropdownPadding: null,
                                      dropdownDecoration:  BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: new BorderRadius.circular(15.0),
                                          boxShadow: [
                                            BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                                spreadRadius: 0.4)
                                          ]),
                                      dropdownElevation: 8,
                                      scrollbarRadius: const Radius.circular(40),
                                      scrollbarThickness: 6,
                                      scrollbarAlwaysShow: true,
                                      offset: const Offset(-20, 0),
                                    ),
                                    padding: EdgeInsets.only(top: 10),
                                  ),
                                  SizedBox(height: 10,),
                        isPin?
                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child: TextFormField(
                                      validator: (value){
                                        if(value==""){

                                          return "Please enter your pin";
                                        }

                                      },
                                      controller: pinController,
                                      textAlign: TextAlign.center,
                                      decoration: InputDecoration(
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.black45,fontSize: 18),
                                          hintText: "Enter your Pincode",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                    ),
                                  )

                                :

                                  Container(
                                    margin: EdgeInsets.only(top: 15),
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: new BorderRadius.circular(360.0),
                                        boxShadow: [
                                          BoxShadow(color: Color.fromRGBO(243, 243, 245, 1), blurRadius: 4.0,
                                              spreadRadius: 0.4)
                                        ]),
                                    width: Get.width*0.75,
                                    child:    IntlPhoneField(
                                      decoration: InputDecoration(
                                          //labelText: 'Phone Number',
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          focusedErrorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          errorBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Colors.red),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(width: 2, color: Color.fromRGBO(243, 243, 245, 1)),
                                            borderRadius: BorderRadius.circular(360.0),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(color: Colors.black45,fontSize: 18),
                                          hintText: "Enter your Phone Number",
                                          fillColor: Color.fromRGBO(243, 243, 245, 1)),
                                      initialCountryCode: 'IN',
                                      onChanged: (phone) {
                                        setState(() {
                                          this.phoneNumber=phone.completeNumber.toString();
                                          phoneController = new TextEditingController(text: phone.completeNumber);

                                        });

                                        print(phone.completeNumber);
                                      },
                                    ),
                                  ),

                                  SizedBox(height: 10,),
                                  isPin?
                                  Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          RichText(
                                            text: TextSpan(
                                                text: 'Sign up with Phone instead of Pin Code',
                                                style: TextStyle(
                                                  color: Colors.black54,
                                                  fontSize: 16,
                                                ),
                                                children: <TextSpan>[

                                                ]),
                                          ),
                                        ],
                                      ),
                                      InkWell(
                                        onTap: (){
                                          setState(() {
                                            isPin=false;
                                          });


                                        },
                                        child: Center(
                                          child: Text(
                                            'Phone Signup',
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontSize: 16,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ):

Column(children: [
  Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    RichText(
      text: TextSpan(
          text: 'Sign up with Phone instead of pin',
          style: TextStyle(
            color: Colors.black54,
            fontSize: 16,
          ),
          children: <TextSpan>[

          ]),
    ),
  ],
),
  InkWell(
    onTap: (){
      setState(() {
        isPin=true;
      });


    },
    child: Center(
      child: Text(
        'Pin Code Signup',
        style: TextStyle(
          color: Colors.red,
          fontSize: 16,
        ),
      ),
    ),
  ),
],),

                                  SizedBox(height: 10,),
                                  InkWell(
                                    onTap: () async {

    // if (_formKey.currentState!.validate()) {
    //  if(gender==null){
    //    ScaffoldMessenger.of(context).showSnackBar(
    //      SnackBar( backgroundColor: Colors.red,
    //        content: Text("Please select gender"),
    //      ),
    //    );
    //  }
    //  else{
    //    setState(() {
    //      isLoading=true;
    //    });
    //    if(isPin){
    //
    //
    //
    //      final String rand1 = "${new Random().nextInt(1000)}";
    //      final String rand2 = "${new Random().nextInt(1000)}";
    //      final String rand3 = "${new Random().nextInt(100)}";
    //
    //      final String userId=rand3.toString()+nameController.text+rand2.toString()+rand1.toString();
    //      final prefs = await SharedPreferences.getInstance();
    //      await prefs.setString('userId', userId);
    //      await FirebaseFirestore.instance
    //          .collection("users").doc(userId).set({
    //
    //        "userid": userId,
    //        "userName": nameController.text,
    //        "phone":" phoneController.text",
    //        "pin": pinController.text,
    //        "gender" : gender,
    //        "coins" : 0,
    //        "profileImageUrl":""
    //      }).then((value) {
    //        print( prefs.getString('userId'));
    //        Navigator.push(
    //            context,
    //            MaterialPageRoute(
    //                builder: (context) => UploadPicturePage(uid:userId ,)));
    //
    //      });
    //
    //    }
    //    else{
    //      verifyPhoneNumber(context);
    //
    //    }
    //  }
    //
    //
    // }

                                    },
                                    child: new Container(
                                      margin: EdgeInsets.only(top: 10),
                                      width: 50,
                                      height: 50,
                                      decoration: new BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                          colors: [
                                            Color.fromRGBO(146, 31, 23, 1),
                                            Color.fromRGBO(188, 40, 28, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                            Color.fromRGBO(232, 50, 35, 1),
                                          ],),
                                     //   color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: new Icon(
                                        Icons.arrow_forward,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 10,),
                                  Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),),
                                  SizedBox(height: 10,),
                           widget.loggedIn?
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      RichText(
                                        text: TextSpan(
                                              text: 'Already have an account?',
                                            style: TextStyle(
                                              color: Colors.black54,
                                              fontSize: 16,
                                            ),
                                            children: <TextSpan>[
                                              TextSpan(
                                                text: ' SignIn',
                                                style: TextStyle(
                                                  color: Colors.red,
                                                  fontSize: 16,
                                                ),
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () async {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) => siginPage()));

                                                  },
                                              ),
                                            ]),
                                      ),
                                    ],
                                  ):SizedBox(),



                                ],),)

                              ],)
                      ),
                  ),


                ],),
              ),
            ),
          )
            : Material(

          child: SingleChildScrollView(
            child: Column(children: [
              SizedBox(height: 50,),

              Container(
                color: Colors.white,
                child: Container(
                    height:Get.height*0.40,
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(75),
                      ),
                      border: Border.all(
                        width: 0,

                        // style: BorderStyle.solid,
                      ),
                    ),
                    child: Center(
                      child: new Image.asset(
                        'assets/otp.png',

                        height: 180,

                        alignment: Alignment.center,
                      ),
                    )
                ),
              ),

              Container(
                child: Container(
                    margin: EdgeInsets.only(bottom:100 ),
                    height:Get.height*0.80,
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        width: 0,
                        color: Colors.white,

                      ),
                      borderRadius: BorderRadius.only(

                        topLeft: Radius.circular(75),
                        //topRight: Radius.circular(90),
                      ),

                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Center(child: Column(children: [
                          SizedBox(height: 30,),
                          Text("Verify Your Number",style:
                          TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
                          SizedBox(height: 15,),
                          Text("Please enter your verification code recieved",
                            style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),

                          SizedBox(height: 5,),
                          Text(" on your phone number",
                            style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),
                          SizedBox(height: 15,),
                          Form(
                            key: formKey,
                            child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 30),
                                child: PinCodeTextField(

                                  appContext: context,
                                  pastedTextStyle: TextStyle(
                                    color: Colors.green.shade600,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  length: 6,
                                  // obscureText: true,
                                  // obscuringCharacter: '*',
                                  // obscuringWidget: const FlutterLogo(
                                  //   size: 24,
                                  // ),
                                  // blinkWhenObscuring: true,
                                  animationType: AnimationType.fade,
                                  validator: (v) {
                                    if (v!.length < 6) {
                                      return "Please Enter Valid verification Code";
                                    } else {
                                      return null;
                                    }
                                  },
                                  pinTheme: PinTheme(
                                    inactiveColor: Colors.black,
                                    inactiveFillColor: Color.fromRGBO(243, 243, 245, 1).withOpacity(1),
                                    shape: PinCodeFieldShape.box,

                                    borderRadius: BorderRadius.circular(10),
                                    borderWidth: 1,
                                    fieldHeight: 50,
                                    fieldWidth: 50,
                                    activeFillColor: Colors.white,
                                  ),
                                  cursorColor: Colors.black,
                                  animationDuration: const Duration(milliseconds: 300),
                                  enableActiveFill: true,
                                  errorAnimationController: errorController,
                                  controller: textEditingController,
                                  keyboardType: TextInputType.number,
                                  boxShadows: const [
                                    BoxShadow(
                                      offset: Offset(0, 1),
                                      color: Colors.grey,
                                      blurRadius: 10,
                                    )
                                  ],
                                  onCompleted: (v) {
                                    debugPrint("Completed");
                                  },
                                  // onTap: () {
                                  //   print("Pressed");
                                  // },
                                  onChanged: (value) {
                                    debugPrint(value);
                                    setState(() {
                                      currentText = value;
                                    });
                                  },
                                  beforeTextPaste: (text) {
                                    debugPrint("Allowing to paste $text");
                                    //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                    //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                    return true;
                                  },
                                )),
                          ),

                          SizedBox(height: 10,),

                          SizedBox(height: 5,),
                          InkWell(
                            onTap: (){
                              signIn(textEditingController.text);


                            },
                            child:
                            new Container(
                              margin: EdgeInsets.only(top: 10),
                              width: 50,
                              height: 50,
                              decoration: new BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Color.fromRGBO(146, 31, 23, 1),
                                    Color.fromRGBO(188, 40, 28, 1),
                                    Color.fromRGBO(232, 50, 35, 1),
                                    Color.fromRGBO(232, 50, 35, 1),
                                    Color.fromRGBO(232, 50, 35, 1),
                                  ],),
                                //   color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                              child: new Icon(
                                Icons.arrow_forward,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          SizedBox(height: 10,),
                          Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),)
                        ],),)

                      ],)
                ),
              ),


            ],),
          ),
        )



     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
String? phoneNumber;
  String? verificationId;
  String? otp, authStatus = "";
  Future<void> verifyPhoneNumber(BuildContext context) async {

      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phoneController.text,
        timeout: const Duration(seconds: 15),
        verificationCompleted: (AuthCredential authCredential) {
          setState(() {
            print("Your account is successfully verified");
            authStatus = "Your account is successfully verified";
          });
        },
        verificationFailed: (FirebaseAuthException authException) {
          setState(() {
            isLoading=false;
          });

          print(authException);
          setState(() {
            authStatus = "Authentication failed";
          });
        },
        codeSent: (String verId,int?   forceCodeResent) async {
          verificationId = verId;
          setState(() {
            isLoading=false;
            authStatus = "OTP has been successfully send";
            showVerification=true;
          });

          print(verificationId.toString()+"yesss");


        },
        codeAutoRetrievalTimeout: (String verId) {
          verificationId = verId;
          if(nextScreen==false)  {
            setState(() {
            print("TIMEOUT");
            showVerification=false;
            isLoading=false;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                backgroundColor: Colors.red,
                content: Text("OTP timeout, please try again"),
              ),
            );
            authStatus = "TIMEOUT";
          });}
        },
      );


  }



  // otpDialogBox(BuildContext context) {
  //   return showDialog(
  //       context: context,
  //       barrierDismissible: false,
  //       builder: (BuildContext context) {
  //         return Material(
  //           child: SingleChildScrollView(
  //             child: Column(children: [
  //               SizedBox(height: 50,),
  //
  //               Container(
  //                 color: Colors.white,
  //                 child: Container(
  //                     height:Get.height*0.40,
  //                     width: Get.width,
  //                     decoration: BoxDecoration(
  //                       color: Colors.black,
  //                       borderRadius: BorderRadius.only(
  //                         bottomRight: Radius.circular(75),
  //                       ),
  //                       border: Border.all(
  //                         width: 0,
  //
  //                         // style: BorderStyle.solid,
  //                       ),
  //                     ),
  //                     child: Center(
  //                       child: new Image.asset(
  //                         'assets/otp.png',
  //
  //                         height: 180,
  //
  //                         alignment: Alignment.center,
  //                       ),
  //                     )
  //                 ),
  //               ),
  //
  //               Container(
  //                 child: Container(
  //                     margin: EdgeInsets.only(bottom:100 ),
  //                     height:Get.height*0.80,
  //                     width: Get.width,
  //                     decoration: BoxDecoration(
  //                       color: Colors.white,
  //                       border: Border.all(
  //                         width: 0,
  //                         color: Colors.white,
  //
  //                       ),
  //                       borderRadius: BorderRadius.only(
  //
  //                         topLeft: Radius.circular(75),
  //                         //topRight: Radius.circular(90),
  //                       ),
  //
  //                     ),
  //                     child: Column(
  //                       mainAxisAlignment: MainAxisAlignment.start,
  //                       children: [
  //                         Center(child: Column(children: [
  //                           SizedBox(height: 30,),
  //                           Text("Verify Your Number",style:
  //                           TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
  //                           SizedBox(height: 15,),
  //                           Text("Please enter your verification code recieved",
  //                             style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),
  //
  //                           SizedBox(height: 5,),
  //                           Text(" on your phone number",
  //                             style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),
  //                           SizedBox(height: 15,),
  //                           Form(
  //                             key: formKey,
  //                             child: Padding(
  //                                 padding: const EdgeInsets.symmetric(
  //                                     vertical: 8.0, horizontal: 30),
  //                                 child: PinCodeTextField(
  //
  //                                   appContext: context,
  //                                   pastedTextStyle: TextStyle(
  //                                     color: Colors.green.shade600,
  //                                     fontWeight: FontWeight.bold,
  //                                   ),
  //                                   length: 6,
  //                                   // obscureText: true,
  //                                   // obscuringCharacter: '*',
  //                                   // obscuringWidget: const FlutterLogo(
  //                                   //   size: 24,
  //                                   // ),
  //                                   // blinkWhenObscuring: true,
  //                                   animationType: AnimationType.fade,
  //                                   validator: (v) {
  //                                     if (v!.length < 6) {
  //                                       return "Please Enter Valid verification Code";
  //                                     } else {
  //                                       return null;
  //                                     }
  //                                   },
  //                                   pinTheme: PinTheme(
  //                                     inactiveColor: Colors.black,
  //                                     inactiveFillColor: Color.fromRGBO(243, 243, 245, 1).withOpacity(1),
  //                                     shape: PinCodeFieldShape.box,
  //
  //                                     borderRadius: BorderRadius.circular(10),
  //                                     borderWidth: 1,
  //                                     fieldHeight: 50,
  //                                     fieldWidth: 50,
  //                                     activeFillColor: Colors.white,
  //                                   ),
  //                                   cursorColor: Colors.black,
  //                                   animationDuration: const Duration(milliseconds: 300),
  //                                   enableActiveFill: true,
  //                                   errorAnimationController: errorController,
  //                                   controller: textEditingController,
  //                                   keyboardType: TextInputType.number,
  //                                   boxShadows: const [
  //                                     BoxShadow(
  //                                       offset: Offset(0, 1),
  //                                       color: Colors.grey,
  //                                       blurRadius: 10,
  //                                     )
  //                                   ],
  //                                   onCompleted: (v) {
  //                                     debugPrint("Completed");
  //                                   },
  //                                   // onTap: () {
  //                                   //   print("Pressed");
  //                                   // },
  //                                   onChanged: (value) {
  //                                     debugPrint(value);
  //                                     setState(() {
  //                                       currentText = value;
  //                                     });
  //                                   },
  //                                   beforeTextPaste: (text) {
  //                                     debugPrint("Allowing to paste $text");
  //                                     //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
  //                                     //but you can show anything you want here, like your pop up saying wrong paste format or etc
  //                                     return true;
  //                                   },
  //                                 )),
  //                           ),
  //
  //                           SizedBox(height: 10,),
  //
  //                           SizedBox(height: 5,),
  //                           InkWell(
  //                             onTap: (){
  //                              signIn(textEditingController.text);
  //
  //
  //                             },
  //                             child:
  //                             new Container(
  //                               margin: EdgeInsets.only(top: 10),
  //                               width: 50,
  //                               height: 50,
  //                               decoration: new BoxDecoration(
  //                                 gradient: LinearGradient(
  //                                   begin: Alignment.centerLeft,
  //                                   end: Alignment.centerRight,
  //                                   colors: [
  //                                     Color.fromRGBO(146, 31, 23, 1),
  //                                     Color.fromRGBO(188, 40, 28, 1),
  //                                     Color.fromRGBO(232, 50, 35, 1),
  //                                     Color.fromRGBO(232, 50, 35, 1),
  //                                     Color.fromRGBO(232, 50, 35, 1),
  //                                   ],),
  //                                 //   color: Colors.red,
  //                                 shape: BoxShape.circle,
  //                               ),
  //                               child: new Icon(
  //                                 Icons.arrow_forward,
  //                                 color: Colors.white,
  //                               ),
  //                             ),
  //                           ),
  //                           SizedBox(height: 10,),
  //                           Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),)
  //                         ],),)
  //
  //                       ],)
  //                 ),
  //               ),
  //
  //
  //             ],),
  //           ),
  //         );
  //       });
  // }
  /*
  otpDialogBox(BuildContext context) {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return new AlertDialog(
            title: Text('Enter your OTP'),
            content: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                decoration: InputDecoration(
                  border: new OutlineInputBorder(
                    borderRadius: const BorderRadius.all(
                      const Radius.circular(30),
                    ),
                  ),
                ),
                onChanged: (value) {
                  otp = value;
                },
              ),
            ),
            contentPadding: EdgeInsets.all(10.0),
            actions: <Widget>[
              ElevatedButton(
                onPressed: () {

                  Navigator.of(context).pop();
                  signIn(otp!);
                },
                child: Text(
                  'Submit',
                ),
              ),
            ],
          );
        });
  }
  */
  Future<void> signIn(String otp) async {
    String? userId;
    await FirebaseAuth.instance
        .signInWithCredential(PhoneAuthProvider.credential(
      verificationId: verificationId!,
      smsCode: otp,
    )).catchError((e){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Inavlid Code"),
        ),
      );
    }).then((value) async => {
       userId=value.user!.uid.toString(),

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: Text("Thank you for joining us",style: TextStyle(color: Colors.white),),
        ),
      ),

    await FirebaseFirestore.instance
        .collection("users").doc(userId).set({

    "userid": value.user!.uid.toString(),
    "userName": nameController.text,
    "phone": phoneController.text,
    "pin": pinController.text,
      "coins" : 0,
      "profileImageUrl":""
    }).then((value) async {
    //   final prefs = await SharedPreferences.getInstance();
    //   await prefs.setString('userId', userId!);
    //   print( prefs.getString('userId'));
    //   await FirebaseAuth.instance.signOut();
    //   setState(() {
    //     this.nextScreen=true;
    //   });
    // Navigator.push(
    // context,
    // MaterialPageRoute(
    // builder: (context) => UploadPicturePage(uid:userId! ,)));

    }),
    print(  value.user!.uid.toString())
    });
  }

bool nextScreen=false;

}
