
import 'dart:async';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:standivadmin/homepage.dart';
import 'package:standivadmin/root.dart';
import 'package:standivadmin/signin.dart';
import 'package:standivadmin/signup.dart';

class InstructionsScreen extends StatefulWidget {
  const InstructionsScreen({super.key, required,required this.uid });
final String uid;



@override
State<InstructionsScreen> createState() => _InstructionsScreenState();
}

class _InstructionsScreenState extends State<InstructionsScreen> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }



  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);


  void navigationPage() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => siginPage()));

  }

  @override
  void initState() {

    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
    return Scaffold(
        backgroundColor: Colors.black,
        body:
        Container(

          margin: EdgeInsets.only(

            top: MediaQuery.of(context).size.height*0.10,),
          height: MediaQuery.of(context).size.height,
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
             Align(alignment: Alignment.center,

                child: Text("  Instructions for \n   using StandIV ",style:  GoogleFonts.salsa(textStyle:
                TextStyle(color:Colors.white,fontSize: 40,fontWeight: FontWeight.bold)),),
              ),SizedBox(height: 5,),

SizedBox(height: 400,),
              InkWell(
                onTap: () async {
                  AwesomeDialog(
                    context: context,
                    dialogType: DialogType.success,
                    animType: AnimType.leftSlide,
                    headerAnimationLoop: false,
                    title: 'Congratulations',

                    desc:
                    'Congratulations and Welcome to StandIV\n We are awarding you hundred coins',
                    btnOkOnPress: () async {
                      await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).update({


                        "isFirstLoggedIn": false,

                      });
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HomePage(isNew: true,)));


                    },
                    btnOkText: "Continue",
                    btnOkIcon: Icons.check_circle,
                    btnOkColor: Colors.red,
                  ).show();


                },
                child:new Container(

                    margin: EdgeInsets.only(top: 80),
                    width:Get.width*0.70,
                    height: 55,
                    decoration: new BoxDecoration(
                      borderRadius: new BorderRadius.circular(360.0),
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Color.fromRGBO(146, 31, 23, 1),
                          Color.fromRGBO(188, 40, 28, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                        ],),
                      //   color: Colors.red,

                    ),
                    child:

                    Center(child: Text("Let's get started",style: GoogleFonts.salsa(textStyle:TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w500,fontSize: 20),)))
                ),
              ),

            ],),
        )



      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
