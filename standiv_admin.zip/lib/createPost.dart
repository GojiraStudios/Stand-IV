
import 'dart:async';
import 'dart:io';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:standivadmin/phoneverification.dart';
import 'package:standivadmin/votePage.dart';
import 'package:textfield_tags/textfield_tags.dart';
import 'package:wechat_assets_picker/wechat_assets_picker.dart';

import 'homepage.dart';

class CreatePostPage extends StatefulWidget {
  final String uId;
  final int coins;
  final int winningPosts;
 CreatePostPage({super.key, required,required this.uId,required this.coins,required this.winningPosts });





  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
bool isLoading=false;
  final GlobalKey _menuKey = GlobalKey();
  String? state;
  String? city;
  String? stack;
  bool isStateSelected=false;
  XFile? imageFile;
  _uploadImage(String level) async{

    final String rand1 = "${new Random().nextInt(10000)}";
    final String rand2 = "${new Random().nextInt(10000)}";
    final String rand3 = "${new Random().nextInt(10000)}";

    // selectedImage= await testCompressFile(selectedImage);
    Reference ref = FirebaseStorage.instance
        .ref()
        .child('${rand1}_${rand2}_${rand3}.jpg');
    UploadTask uploadTask = ref.putFile(File(imageFile!.path));
    String imageUrl = await (await uploadTask).ref.getDownloadURL();
    print(imageUrl);
    await FirebaseFirestore.instance
        .collection("posts").add({

    "userid": widget.uId,
    "postTags": _controller!.getTags,
    "state": state!,
    "city": city,
      "stack" :level,
    "postImageUrl":imageUrl,
      "voter" :[],
      "isDone":false,
      "timestamp" :DateTime.now()
    }).then((value) async {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => HomePage(isNew: false,)));





      // Navigator.push(
      //     context,
      //     MaterialPageRoute(
      //         builder: (context) => UploadPicturePage()));
     // Navigator.pop(context);

    });
  }

  _pickImage(String type) async {

    if(type=="video") {
      await ImagePicker()
          .pickVideo(source: ImageSource.gallery,)
          .then((selectedImage) async {
        if (selectedImage != null) {
          setState(() {
            this.imageFile = selectedImage;
          });
        }
      });
    }
    else{
      await ImagePicker()
          .pickImage(source: ImageSource.gallery,)
          .then((selectedImage) async {
        if (selectedImage != null) {
          setState(() {
            this.imageFile = selectedImage;
          });
        }
      });

    }

    // : await ImagePicker.pickImage(source: ImageSource.camera);
    //  return selectedImage;
  }
List<String>  postStack=['Bronze Level','Silver Level', 'Gold Level', 'BroadCasts'];
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R

  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }



  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);




  @override
  double ?_distanceToField;
  TextfieldTagsController ?_controller;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _distanceToField = MediaQuery.of(context).size.width;
  }
int userCoins=0;
  @override

  void initState() {
    setState(() {
      this.userCoins=widget.coins;
    });
    super.initState();
    //print(someMap["a"]![1]);
    _controller = TextfieldTagsController();
  }
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
      return Scaffold(


backgroundColor: Colors.white,
      body:

      isLoading?
      SingleChildScrollView(
        child: Container(
          height: Get.height,
          child: Center(child:
          CircularProgressIndicator(color: Colors.red,strokeWidth: 5,)),
        ),
      )

          :     Form(
        key: _formKey,
            child: SingleChildScrollView(
              child: Column(children: [
  SizedBox(height: 70,),


                Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  child: Container(

                      color: Colors.white,
                      height: 40,
                  width: Get.width,

                  child:
                  Row(children: [
                    SizedBox(width: 10,),
                    InkWell(
                      onTap: (){
                        Navigator.pop(context);
                      },
                      child: ImageIcon(
                        AssetImage("assets/backicon.png"),color: Colors.black,
                         size: 25,
                      ),
                    ),
                    SizedBox(width: 50,),
                     Text( "Create a New Post",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                    Spacer(),

                  ],)
                  ),
                ),
                SizedBox(height: 20,),
              Container(
                margin: EdgeInsets.symmetric(horizontal:20 ),
               // height:Get.height*0.80,
                width: Get.width,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(
                    width: 0,
                    color: Colors.white,

                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 6,
                      blurRadius: 7,
                      offset: Offset(0, 3), // changes position of shadow
                    ),
                  ],
                  borderRadius: BorderRadius.all(

                    Radius.circular(10),
                    //topRight: Radius.circular(90),
                  ),

                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                  Container(
                    decoration: BoxDecoration(
                      color: Colors.red[800],
                      border: Border.all(
                        width: 0,
                        color: Colors.white,

                      ),
                      borderRadius: BorderRadius.only(

                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                        //topRight: Radius.circular(90),
                      ),

                    ),
                  width: Get.width,
                    height: 40,
                  ),

                  Container(
                    margin: EdgeInsets.only(left: 30,right: 20,top: 35),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text("What do you want to talk about?",
                          style: TextStyle(color:Colors.black54, fontSize: 16,fontWeight: FontWeight.bold,
                              wordSpacing: 2,height: 1.3),),

                      SizedBox(height: 15,),
                        Text("Add Tags",
                          style: TextStyle(color:Colors.black54, fontSize: 16,fontWeight: FontWeight.bold,
                              wordSpacing: 2,height: 1.3),),
                      //tags
                      Container(
                      width: Get.width,

                        child: TextFieldTags(
                          textfieldTagsController: _controller,

                          textSeparators: const [' ', ','],
                          letterCase: LetterCase.normal,
                          validator: (String tag) {
                              if (_controller!.getTags!.contains(tag)) {
                              return 'you already entered that';
                            }
                            return null;
                          },
                          inputfieldBuilder:
                              (context, tec, fn, error, onChanged, onSubmitted) {
                            return ((context, sc, tags, onTagDelete) {
                              return Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextField(
                                  controller: tec,
                                  focusNode: fn,
                                  decoration: InputDecoration(
                                    isDense: true,
                                    enabledBorder:const UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.grey,
                                        width: 0.5,
                                      ),
                                    ) ,
                                    border:

                                    const UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.blue,
                                        width: 1.0,
                                      ),
                                    ),
                                    focusedBorder: const UnderlineInputBorder(
                                      borderSide: BorderSide(
                                        color: Colors.red,
                                        width: 1.0,
                                      ),
                                    ),


                                    helperStyle: const TextStyle(
                                      color: Colors.red,
                                    ),

                                    hintText:  "   Add tag...",
                                    hintStyle: TextStyle(fontSize: 14),
                                    errorText: error,
                                    prefixIconConstraints:
                                    BoxConstraints(maxWidth: _distanceToField! * 0.74),
                                    prefixIcon: tags.isNotEmpty
                                        ? SingleChildScrollView(
                                      controller: sc,
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                          children: tags.map((String tag) {
                                            return Container(
                                              height: 30,
                                              decoration: const BoxDecoration(
                                                  borderRadius: BorderRadius.all(
                                                    Radius.circular(5.0),
                                                  ),
                                                  color: Colors.blue
                                              ),
                                              margin: const EdgeInsets.symmetric(
                                                  horizontal: 5.0),
                                              padding: const EdgeInsets.symmetric(
                                                  horizontal: 10.0, vertical: 5.0),
                                              child: Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                                children: [
                                                  InkWell(
                                                    child: Text(
                                                      '#$tag',
                                                      style: const TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                    onTap: () {
                                                      print("$tag selected");
                                                    },
                                                  ),
                                                  const SizedBox(width: 4.0),
                                                  InkWell(
                                                    child: const Icon(
                                                      Icons.cancel,
                                                      size: 14.0,
                                                      color: Color.fromARGB(
                                                          255, 233, 233, 233),
                                                    ),
                                                    onTap: () {
                                                      onTagDelete(tag);
                                                    },
                                                  )
                                                ],
                                              ),
                                            );
                                          }).toList()),
                                    )
                                        : null,
                                  ),
                                  onChanged: onChanged,
                                  onSubmitted: onSubmitted,
                                ),
                              );
                            });
                          },
                        ),
                      ),
                        SizedBox(height: 25,),
                        Text("Select Post Level",
                          style: TextStyle(color:Colors.black54, fontSize: 16,fontWeight: FontWeight.bold,
                              wordSpacing: 2,height: 1.3),),
                        SizedBox(height: 15,),

                        Container(
                          width: Get.width,
                          child: DropdownButton2(
                            isExpanded: true,
                            hint: Row(
                              children: const [

                                SizedBox(
                                  width: 4,
                                ),
                                Expanded(
                                  child: Text(
                                    'Select Level',
                                    style: TextStyle(
                                      fontSize: 14,


                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            items: postStack
                                .map((item) => DropdownMenuItem<String>(
                              value: item,
                              child: Text(
                                item,
                                style: const TextStyle(
                                  fontSize: 14,

                                  color: Colors.black45,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ))
                                .toList(),
                            value: stack,
                            onChanged: (value) {
                              setState(() {


                                if(stack!=value){
                                  stack= stack = value as String;
                                  print(stack);
                                }




                              });
                            },
                            icon: const Icon(
                              Icons.arrow_drop_down_outlined,
                            ),
                            iconSize: 20,
                            iconEnabledColor: Colors.black45,
                            iconDisabledColor: Colors.grey,

                            buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                            buttonElevation: 2,
                            itemHeight: 40,
                            itemPadding: const EdgeInsets.only(left: 15, right: 15),
                            dropdownMaxHeight: 200,
                            dropdownWidth: 200,
                            dropdownPadding: null,
                            dropdownDecoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              color: Colors.white,
                            ),
                            dropdownElevation: 8,
                            scrollbarRadius: const Radius.circular(40),
                            scrollbarThickness: 6,
                            scrollbarAlwaysShow: true,
                            offset: const Offset(-20, 0),
                          ),
                        ),
                        SizedBox(height: 25,),
                        Text("Select State",
                          style: TextStyle(color:Colors.black54, fontSize: 16,fontWeight: FontWeight.bold,
                              wordSpacing: 2,height: 1.3),),
                        SizedBox(height: 15,),

                        Container(
                      width: Get.width,
                      child: DropdownButton2(
                        isExpanded: true,
                        hint: Row(
                          children: const [

                            SizedBox(
                              width: 4,
                            ),
                            Expanded(
                              child: Text(
                                'Select State',
                                style: TextStyle(
                                  fontSize: 14,


                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        items: states
                            .map((item) => DropdownMenuItem<String>(
                          value: item,
                          child: Text(
                            item,
                            style: const TextStyle(
                              fontSize: 14,

                              color: Colors.black45,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ))
                            .toList(),
                        value: state,
                        onChanged: (value) {
                          setState(() {


                             if(state!=value){
                               state= state = value as String;
                             }

                             isStateSelected=true;


                          });
                        },
                        icon: const Icon(
                          Icons.arrow_drop_down_outlined,
                        ),
                        iconSize: 20,
                        iconEnabledColor: Colors.black45,
                        iconDisabledColor: Colors.grey,

                        buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                        buttonElevation: 2,
                        itemHeight: 40,
                        itemPadding: const EdgeInsets.only(left: 15, right: 15),
                        dropdownMaxHeight: 200,
                        dropdownWidth: 200,
                        dropdownPadding: null,
                        dropdownDecoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: Colors.white,
                        ),
                        dropdownElevation: 8,
                        scrollbarRadius: const Radius.circular(40),
                        scrollbarThickness: 6,
                        scrollbarAlwaysShow: true,
                        offset: const Offset(-20, 0),
                      ),
                    ),

                        SizedBox(height: 15,),

                        //choose city
                        if (isStateSelected) Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,


                          children: [


                          Text("Select City",
                            style: TextStyle(color:Colors.black54, fontSize: 16,fontWeight: FontWeight.bold,
                                wordSpacing: 2,height: 1.3),),
                          SizedBox(height: 20,),
                            Container(
                              width: Get.width,
                              child: DropdownButton2(
                                isExpanded: true,
                                hint: Row(
                                  children: const [

                                    SizedBox(
                                      width: 4,
                                    ),
                                    Expanded(
                                      child: Text(
                                        'Select City',
                                        style: TextStyle(
                                          fontSize: 14,


                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                items:  (isStateSelected?
                                 cities[state]!: ["asdad","asdasd"])
                                              .map((item) => DropdownMenuItem<String>(
                                  value: item,
                                  child: Text(
                                    item,
                                    style: const TextStyle(
                                      fontSize: 14,

                                      color: Colors.black45,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ))
                                    .toList(),
                                value: city,
                                onChanged: (value) {
                                  setState(() {
                                    city=value!;
                                    //   isStateSelected=true;
                                  });
                                },
                                icon: const Icon(
                                  Icons.arrow_drop_down_outlined,
                                ),
                                iconSize: 20,
                                iconEnabledColor: Colors.black45,
                                iconDisabledColor: Colors.grey,

                                buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                                buttonElevation: 2,
                                itemHeight: 40,
                                itemPadding: const EdgeInsets.only(left: 15, right: 15),
                                dropdownMaxHeight: 200,
                                dropdownWidth: 200,
                                dropdownPadding: null,
                                dropdownDecoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: Colors.white,
                                ),
                                dropdownElevation: 8,
                                scrollbarRadius: const Radius.circular(40),
                                scrollbarThickness: 6,
                                scrollbarAlwaysShow: true,
                                offset: const Offset(-20, 0),
                              ),
                            ),


                        ],) else SizedBox(height: 1,)






                      ],

                    ),

                  ),
                    SizedBox(height: 30,),
                    Divider(color: Colors.red,thickness: 0.5,),
                    InkWell(
                      onTap: () {



                        _pickImage("image");
                        //_pickImage();
                      },

                      child: Container(

                        margin: EdgeInsets.only(left: 30,right: 20),
                        child: Column(
                          children: [
                            SizedBox(height: 20,),


                            Row(children: [
                              Container(
                                width: 35,
                                height: 35,

                                margin: EdgeInsets.only(top: 10),


                                child:  Image.asset("assets/uploadimg.png"),
                              ),

                              Container(



padding: EdgeInsets.symmetric(horizontal: 15),
                                child:


                                Text(


                                  "Upload Image/Video",style: TextStyle(color: Colors.orange,fontSize: 15,
                                  decoration: TextDecoration.underline,
                                ),

                                ),
                              ),


                            ],),

                            SizedBox(height: 10,),
                            imageFile!=null?
                          Container(height: 300,child:
                            Image.file(
                             File( imageFile!.path))
                            ):SizedBox(height: 1,),
SizedBox(height: 20,),


                          ],

                        ),

                      ),
                    ),

                  ],),
              ),



                InkWell(
                  onTap: (){
                    print(userCoins.toString()+"yes");
                    print(stack.toString()+"yes");

                    if (_controller!.getTags!.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar( backgroundColor: Colors.red,
                          content: Text("Please enter tags"),
                        ),
                      );

                    }
                    else if(stack==null){


                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar( backgroundColor: Colors.red,
                          content: Text("Please select level"),
                        ),
                      );


                    }

                    else if(state==null){
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar( backgroundColor: Colors.red,
                          content: Text("Please select state"),
                        ),
                      );
                    }
                    else if(city==null){


                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar( backgroundColor: Colors.red,
                            content: Text("Please select city"),
                          ),
                        );


                    }

                    else if(imageFile==null){
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar( backgroundColor: Colors.red,
                          content: Text("Please select image"),
                        ),
                      );
                    }
                    else if(userCoins>=2000 && stack== "BroadCasts"){
                      setState(() {
                        isLoading=true;
                      });
                    //  List<String>  postStack=['Bronze Stack','Silver Stack', 'Gold Stack', 'BroadCasts'];
                 //     List<String>  postStack=['Bronze Level','Silver Level', 'Silver Level', 'BroadCasts'];

                      _uploadImage(stack!);

                    }
             
                    else {
                      setState(() {
                        isLoading=true;
                      });
                      //  List<String>  postStack=['Bronze Stack','Silver Stack', 'Gold Stack', 'BroadCasts'];
                      String? level;
                      if(stack=='Bronze Level'){
level='Bronze Stack';
                      }

                      else  if(stack=='Silver Level'){
level='Silver Stack';
                      }
                      else if(stack=='Gold Level'){
level='Gold Stack';
                      }
                      else {
                        level=stack;
                      }
                      _uploadImage(level!);

                    }




                  },
                  child: new Container(

                    margin: EdgeInsets.only(top: 50),
                    width:Get.width*0.70,
                    height: 55,
                    decoration: new BoxDecoration(
                      borderRadius: new BorderRadius.circular(360.0),
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Color.fromRGBO(146, 31, 23, 1),
                          Color.fromRGBO(188, 40, 28, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                        ],),
                      //   color: Colors.red,

                    ),
                    child:

                    Center(child: Text("Post Now",style: TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w500),))
                  ),
                ),
                SizedBox(height: 20,),
                InkWell(
                    onTap: (){
                      Navigator.pop(context);
                    },
                    child: Text("Discard",style: TextStyle(color:Colors.black54,),)),

                SizedBox(height: 20,),


              ],),
            ),
          )



     // This trailing comma makes auto-formatting nicer for build methods.
    );


  }
 // final GlobalKey _menuKey = GlobalKey();
  Map<String, List<String>> cities = {
    "Telangana": ['Adilabad', 'Hyderabad', 'K.V Rangareddy', 'Karimnagar',
      'Mahabubnagar', 'Medak', 'Nalgonda', 'Nizamabad', 'Warangal'
    ],

    "Andhra Pradesh (AP)": ['Anantapur',
      'Chittoor',
      'Kakinada',
      'Guntur',
      'Karimnagar',
      'Khammam',
      'Krishna',
      'Kurnool',
      'Ongole',
      'Hyderabad',
      'Srikakulam',
      'Nellore',
      'Visakhapatnam',
      'Vizianagaram',
      'Eluru',
      'Kadapa',],
    "Arunachal Pradesh (AR)":['Anjaw',
      'Changlang',
      'East Siang',
      'Kurung Kumey',
      'Lohit',
      'Lower Dibang Valley',
      'Lower Subansiri',
      'Papum Pare',
      'Tawang',
      'Tirap',
      'Dibang Valley',
      'Upper Siang',
      'Upper Subansiri',
      'West Kameng',
      'West Siang',],
    "Assam (AS)":['Baksa',
      'Barpeta',
      'Bongaigaon',
      'Cachar',
      'Chirang',
      'Darrang',
      'Dhemaji',
      'Dima Hasao',
      'Dhubri',
      'Dibrugarh',
      'Goalpara',
      'Golaghat',
      'Hailakandi',
      'Jorhat',
      'Kamrup',
      'Kamrup Metropolitan',
      'Karbi Anglong',
      'Karimganj',
      'Kokrajhar',
      'Lakhimpur',
      'Marigaon',
      'Nagaon',
      'Nalbari',
      'Sibsagar',
      'Sonitpur',
      'Tinsukia',
      'Udalguri',],
    "Bihar (BR)":['Araria',
      'Arwal',
      'Aurangabad',
      'Banka',
      'Begusarai',
      'Bhagalpur',
      'Bhojpur',
      'Buxar',
      'Darbhanga',
      'East Champaran',
      'Gaya',
      'Gopalganj',
      'Jamui',
      'Jehanabad',
      'Kaimur',
      'Katihar',
      'Khagaria',
      'Kishanganj',
      'Lakhisarai',
      'Madhepura',
      'Madhubani',
      'Munger',
      'Muzaffarpur',
      'Nalanda',
      'Nawada',
      'Patna',
      'Purnia',
      'Rohtas',
      'Saharsa',
      'Samastipur',
      'Saran',
      'Sheikhpura',
      'Sheohar',
      'Sitamarhi',
      'Siwan',
      'Supaul',
      'Vaishali',
      'West Champaran',
      'Chandigarh',],
    "Chhattisgarh (CG)":[
      'Bastar',
      'Bijapur',
      'Bilaspur',
      'Dantewada',
      'Dhamtari',
      'Durg',
      'Jashpur',
      'Janjgir-Champa',
      'Korba',
      'Koriya',
      'Kanker',
      'Kabirdham (Kawardha)',
      'Mahasamund',
      'Narayanpur',
      'Raigarh',
      'Rajnandgaon',
      'Raipur',
      'Surguja',],
    "Dadra and Nagar Haveli (DN)":["Dadra and Nagar Haveli"],
    "Daman and Diu (DD)":['Daman',
      'Diu',],
    "Delhi (DL)":['Central Delhi',
      'East Delhi',
      'New Delhi',
      'North Delhi',
      'North East Delhi',
      'North West Delhi',
      'South Delhi',
      'South West Delhi',
      'West Delhi',],
    "Goa (GA)":['North Goa',
      'South Goa'],
    "Gujarat (GJ)":['Ahmedabad',
      'Amreli district',
      'Anand',
      'Banaskantha',
      'Bharuch',
      'Bhavnagar',
      'Dahod',
      'The Dangs',
      'Gandhinagar',
      'Jamnagar',
      'Junagadh',
      'Kutch',
      'Kheda',
      'Mehsana',
      'Narmada',
      'Navsari',
      'Patan',
      'Panchmahal',
      'Porbandar',
      'Rajkot',
      'Sabarkantha',
      'Surendranagar',
      'Surat',
      'Vyara',
      'Vadodara',
      'Valsad',],
    "Haryana (HR)":['Ambala',
      'Bhiwani',
      'Faridabad',
      'Fatehabad',
      'Gurgaon',
      'Hissar',
      'Jhajjar',
      'Jind',
      'Karnal',
      'Kaithal',
      'Kurukshetra',
      'Mahendragarh',
      'Mewat',
      'Palwal',
      'Panchkula',
      'Panipat',
      'Rewari',
      'Rohtak',
      'Sirsa',
      'Sonipat',
      'Yamuna Nagar',],
    "Himachal Pradesh (HP)":['Bilaspur',
      'Chamba',
      'Hamirpur',
      'Kangra',
      'Kinnaur',
      'Kullu',
      'Lahaul and Spiti',
      'Mandi',
      'Shimla',
      'Sirmaur',
      'Solan',
      'Una',],
    "Jammu and Kashmir (JK)":['Anantnag',
      'Badgam',
      'Bandipora',
      'Baramulla',
      'Doda',
      'Ganderbal',
      'Jammu',
      'Kargil',
      'Kathua',
      'Kishtwar',
      'Kupwara',
      'Kulgam',
      'Leh',
      'Poonch',
      'Pulwama',
      'Rajauri',
      'Ramban',
      'Reasi',
      'Samba',
      'Shopian',
      'Srinagar',
      'Udhampur',],
    "Jharkhand (JH)":['Bokaro',
      'Chatra',
      'Deoghar',
      'Dhanbad',
      'Dumka',
      'East Singhbhum',
      'Garhwa',
      'Giridih',
      'Godda',
      'Gumla',
      'Hazaribag',
      'Jamtara',
      'Khunti',
      'Koderma',
      'Latehar',
      'Lohardaga',
      'Pakur',
      'Palamu',
      'Ramgarh',
      'Ranchi',
      'Sahibganj',
      'Seraikela Kharsawan',
      'Simdega',
      'West Singhbhum',],
    "Karnataka (KA)":['Bagalkot',
      'Bangalore Rural',
      'Bangalore Urban',
      'Belgaum',
      'Bellary',
      'Bidar',
      'Bijapur',
      'Chamarajnagar',
      'Chikkamagaluru',
      'Chikkaballapur',
      'Chitradurga',
      'Davanagere',
      'Dharwad',
      'Dakshina Kannada',
      'Gadag',
      'Gulbarga',
      'Hassan',
      'Haveri district',
      'Kodagu',
      'Kolar',
      'Koppal',
      'Mandya',
      'Mysore',
      'Raichur',
      'Shimoga',
      'Tumkur',
      'Udupi',
      'Uttara Kannada',
      'Ramanagara',
      'Yadgir',],
    "Kerala (KL)":['Alappuzha',
      'Ernakulam',
      'Idukki',
      'Kannur',
      'Kasaragod',
      'Kollam',
      'Kottayam',
      'Kozhikode',
      'Malappuram',
      'Palakkad',
      'Pathanamthitta',
      'Thrissur',
      'Thiruvananthapuram',
      'Wayanad',],
    "Madhya Pradesh (MP)":['Alirajpur',
      'Anuppur',
      'Ashok Nagar',
      'Balaghat',
      'Barwani',
      'Betul',
      'Bhind',
      'Bhopal',
      'Burhanpur',
      'Chhatarpur',
      'Chhindwara',
      'Damoh',
      'Datia',
      'Dewas',
      'Dhar',
      'Dindori',
      'Guna',
      'Gwalior',
      'Harda',
      'Hoshangabad',
      'Indore',
      'Jabalpur',
      'Jhabua',
      'Katni',
      'Khandwa (East Nimar)',
      'Khargone (West Nimar)',
      'Mandla',
      'Mandsaur',
      'Morena',
      'Narsinghpur',
      'Neemuch',
      'Panna',
      'Rewa',
      'Rajgarh',
      'Ratlam',
      'Raisen',
      'Sagar',
      'Satna',
      'Sehore',
      'Seoni',
      'Shahdol',
      'Shajapur',
      'Sheopur',
      'Shivpuri',
      'Sidhi',
      'Singrauli',
      'Tikamgarh',
      'Ujjain',
      'Umaria',
      'Vidisha',],
    "Maharashtra (MH)":['Ahmednagar',
      'Akola',
      'Amravati',
      'Aurangabad',
      'Bhandara',
      'Beed',
      'Buldhana',
      'Chandrapur',
      'Dhule',
      'Gadchiroli',
      'Gondia',
      'Hingoli',
      'Jalgaon',
      'Jalna',
      'Kolhapur',
      'Latur',
      'Mumbai City',
      'Mumbai suburban',
      'Nandurbar',
      'Nanded',
      'Nagpur',
      'Nashik',
      'Osmanabad',
      'Parbhani',
      'Pune',
      'Raigad',
      'Ratnagiri',
      'Sindhudurg',
      'Sangli',
      'Solapur',
      'Satara',
      'Thane',
      'Wardha',
      'Washim',
      'Yavatmal',],
    "Manipur (MN)":['Bishnupur',
      'Churachandpur',
      'Chandel',
      'Imphal East',
      'Senapati',
      'Tamenglong',
      'Thoubal',
      'Ukhrul',
      'Imphal West',],
    'Meghalaya (ML)':[
      'East Garo Hills',
      'East Khasi Hills',
      'Jaintia Hills',
      'Ri Bhoi',
      'South Garo Hills',
      'West Garo Hills',
      'West Khasi Hills',
    ],
    'Mizoram (MZ)':[
      'Aizawl',
      'Champhai',
      'Kolasib',
      'Lawngtlai',
      'Lunglei',
      'Mamit',
      'Saiha',
      'Serchhip',
    ],

    'Nagaland (NL)':[
      'Dimapur',
      'Kohima',
      'Mokokchung',
      'Mon',
      'Phek',
      'Tuensang',
      'Wokha',
      'Zunheboto',
    ],
    'Orissa (OR)':[
      'Angul',
      'Boudh (Bauda)',
      'Bhadrak',
      'Balangir',
      'Bargarh (Baragarh)',
      'Balasore',
      'Cuttack',
      'Debagarh (Deogarh)',
      'Dhenkanal',
      'Ganjam',
      'Gajapati',
      'Jharsuguda',
      'Jajpur',
      'Jagatsinghpur',
      'Khordha',
      'Kendujhar (Keonjhar)',
      'Kalahandi',
      'Kandhamal',
      'Koraput',
      'Kendrapara',
      'Malkangiri',
      'Mayurbhanj',
      'Nabarangpur',
      'Nuapada',
      'Nayagarh',
      'Puri',
      'Rayagada',
      'Sambalpur',
      'Subarnapur (Sonepur)',
      'Sundergarh',
    ],
    'Pondicherry (Puducherry) (PY)':[
      'Karaikal',
      'Mahe',
      'Pondicherry',
      'Yanam',
    ],
    'Punjab (PB)':[
      'Amritsar',
      'Barnala',
      'Bathinda',
      'Firozpur',
      'Faridkot',
      'Fatehgarh Sahib',
      'Fazilka',
      'Gurdaspur',
      'Hoshiarpur',
      'Jalandhar',
      'Kapurthala',
      'Ludhiana',
      'Mansa',
      'Moga',
      'Sri Muktsar Sahib',
      'Pathankot',
      'Patiala',
      'Rupnagar',
      'Ajitgarh (Mohali)',
      'Sangrur',
      'Nawanshahr',
      'Tarn Taran',
    ],
    'Rajasthan (RJ)':[
      'Ajmer',
      'Alwar',
      'Bikaner',
      'Barmer',
      'Banswara',
      'Bharatpur',
      'Baran',
      'Bundi',
      'Bhilwara',
      'Churu',
      'Chittorgarh',
      'Dausa',
      'Dholpur',
      'Dungapur',
      'Ganganagar',
      'Hanumangarh',
      'Jhunjhunu',
      'Jalore',
      'Jodhpur',
      'Jaipur',
      'Jaisalmer',
      'Jhalawar',
      'Karauli',
      'Kota',
      'Nagaur',
      'Pali',
      'Pratapgarh',
      'Rajsamand',
      'Sikar',
      'Sawai Madhopur',
      'Sirohi',
      'Tonk',
      'Udaipur',
    ],

    'Sikkim (SK)':[
      'East Sikkim',
      'North Sikkim',
      'South Sikkim',
      'West Sikkim',
    ],
    'Tamil Nadu (TN)':[
      'Ariyalur',
      'Chennai',
      'Coimbatore',
      'Cuddalore',
      'Dharmapuri',
      'Dindigul',
      'Erode',
      'Kanchipuram',
      'Kanyakumari',
      'Karur',
      'Madurai',
      'Nagapattinam',
      'Nilgiris',
      'Namakkal',
      'Perambalur',
      'Pudukkottai',
      'Ramanathapuram',
      'Salem',
      'Sivaganga',
      'Tirupur',
      'Tiruchirappalli',
      'Theni',
      'Tirunelveli',
      'Thanjavur',
      'Thoothukudi',
      'Tiruvallur',
      'Tiruvarur',
      'Tiruvannamalai',
      'Vellore',
      'Viluppuram',
      'Virudhunagar',
    ],
    'Tripura (TR)':[
      'Dhalai',
      'North Tripura',
      'South Tripura',
      'Khowai',
      'West Tripura',
    ],
    'Uttar Pradesh (UP)':[
      'Agra',
      'Allahabad',
      'Aligarh',
      'Ambedkar Nagar',
      'Auraiya',
      'Azamgarh',
      'Barabanki',
      'Budaun',
      'Bagpat',
      'Bahraich',
      'Bijnor',
      'Ballia',
      'Banda',
      'Balrampur',
      'Bareilly',
      'Basti',
      'Bulandshahr',
      'Chandauli',
      'Chhatrapati Shahuji Maharaj Nagar',
      'Chitrakoot',
      'Deoria',
      'Etah',
      'Kanshi Ram Nagar',
      'Etawah',
      'Firozabad',
      'Farrukhabad',
      'Fatehpur',
      'Faizabad',
      'Gautam Buddh Nagar',
      'Gonda',
      'Ghazipur',
      'Gorakhpur',
      'Ghaziabad',
      'Hamirpur',
      'Hardoi',
      'Mahamaya Nagar',
      'Jhansi',
      'Jalaun',
      'Jyotiba Phule Nagar',
      'Jaunpur district',
      'Ramabai Nagar (Kanpur Dehat)',
      'Kannauj',
      'Kanpur',
      'Kaushambi',
      'Kushinagar',
      'Lalitpur',
      'Lakhimpur Kheri',
      'Lucknow',
      'Mau',
      'Meerut',
      'Maharajganj',
      'Mahoba',
      'Mirzapur',
      'Moradabad',
      'Mainpuri',
      'Mathura',
      'Muzaffarnagar',
      'Panchsheel Nagar district (Hapur)',
      'Pilibhit',
      'Shamli',
      'Pratapgarh',
      'Rampur',
      'Raebareli',
      'Saharanpur',
      'Sitapur',
      'Shahjahanpur',
      'Sant Kabir Nagar',
      'Siddharthnagar',
      'Sonbhadra',
      'Sant Ravidas Nagar',
      'Sultanpur',
      'Shravasti',
      'Unnao',
      'Varanasi',
    ],
    'Uttarakhand (UK)':[
      'Almora',
      'Bageshwar',
      'Chamoli',
      'Champawat',
      'Dehradun',
      'Haridwar',
      'Nainital',
      'Pauri Garhwal',
      'Pithoragarh',
      'Rudraprayag',
      'Tehri Garhwal',
      'Udham Singh Nagar',
      'Uttarkashi',
    ],
    'West Bengal (WB)':[
      'Birbhum',
      'Bankura',
      'Bardhaman',
      'Darjeeling',
      'Dakshin Dinajpur',
      'Hooghly',
      'Howrah',
      'Jalpaiguri',
      'Cooch Behar',
      'Kolkata',
      'Maldah',
      'Paschim Medinipur',
      'Purba Medinipur',
      'Murshidabad',
      'Nadia',
      'North 24 Parganas',
      'South 24 Parganas',
      'Purulia',
      'Uttar Dinajpur',
    ],


  };
  List<String> states=["Andhra Pradesh (AP)",
    "Arunachal Pradesh (AR)","Assam (AS)","Bihar (BR)",
    "Chhattisgarh (CG)","Dadra and Nagar Haveli (DN)","Daman and Diu (DD)","Delhi (DL)",
    "Goa (GA)","Gujarat (GJ)","Haryana (HR)",
    "Himachal Pradesh (HP)","Jammu and Kashmir (JK)","Jharkhand (JH)","Karnataka (KA)",
    "Kerala (KL)","Madhya Pradesh (MP)","Maharashtra (MH)",
    "Manipur (MN)","Meghalaya (ML)",
    "Mizoram (MZ)","Nagaland (NL)","Orissa (OR)","Pondicherry (Puducherry) (PY)",
    "Punjab (PB)","Rajasthan (RJ)","Sikkim (SK)",
    "Tamil Nadu (TN)", "Telangana","Tripura (TR)","Uttar Pradesh (UP)","Uttarakhand (UK)",
    "West Bengal (WB)"
  ];
//   Map<String, List<String>> cities = {
//     "Telangana": ['Adilabad', 'Hyderabad', 'K.V Rangareddy', 'Karimnagar',
//       'Mahabubnagar', 'Medak', 'Nalgonda', 'Nizamabad', 'Warangal'
//     ],
//     "Andhra Pradesh (AP)": ['Anantapur',
//       'Chittoor',
//       'Kakinada',
//       'Guntur',
//       'Karimnagar',
//       'Khammam',
//       'Krishna',
//       'Kurnool',
//       'Ongole',
//       'Hyderabad',
//       'Srikakulam',
//       'Nellore',
//       'Visakhapatnam',
//       'Vizianagaram',
//       'Eluru',
//       'Kadapa',],
//     "Arunachal Pradesh (AR)":['Anjaw',
//       'Changlang',
//       'East Siang',
//       'Kurung Kumey',
//       'Lohit',
//       'Lower Dibang Valley',
//       'Lower Subansiri',
//       'Papum Pare',
//       'Tawang',
//       'Tirap',
//       'Dibang Valley',
//       'Upper Siang',
//       'Upper Subansiri',
//       'West Kameng',
//       'West Siang',],
//     "Assam (AS)":['Baksa',
//       'Barpeta',
//       'Bongaigaon',
//       'Cachar',
//       'Chirang',
//       'Darrang',
//       'Dhemaji',
//       'Dima Hasao',
//       'Dhubri',
//       'Dibrugarh',
//       'Goalpara',
//       'Golaghat',
//       'Hailakandi',
//       'Jorhat',
//       'Kamrup',
//       'Kamrup Metropolitan',
//       'Karbi Anglong',
//       'Karimganj',
//       'Kokrajhar',
//       'Lakhimpur',
//       'Marigaon',
//       'Nagaon',
//       'Nalbari',
//       'Sibsagar',
//       'Sonitpur',
//       'Tinsukia',
//       'Udalguri',],
//     "Bihar (BR)":['Araria',
//       'Arwal',
//       'Aurangabad',
//       'Banka',
//       'Begusarai',
//       'Bhagalpur',
//       'Bhojpur',
//       'Buxar',
//       'Darbhanga',
//       'East Champaran',
//       'Gaya',
//       'Gopalganj',
//       'Jamui',
//       'Jehanabad',
//       'Kaimur',
//       'Katihar',
//       'Khagaria',
//       'Kishanganj',
//       'Lakhisarai',
//       'Madhepura',
//       'Madhubani',
//       'Munger',
//       'Muzaffarpur',
//       'Nalanda',
//       'Nawada',
//       'Patna',
//       'Purnia',
//       'Rohtas',
//       'Saharsa',
//       'Samastipur',
//       'Saran',
//       'Sheikhpura',
//       'Sheohar',
//       'Sitamarhi',
//       'Siwan',
//       'Supaul',
//       'Vaishali',
//       'West Champaran',
//       'Chandigarh',],
//     "Chhattisgarh (CG)":[
//       'Bastar',
//       'Bijapur',
//       'Bilaspur',
//       'Dantewada',
//       'Dhamtari',
//       'Durg',
//       'Jashpur',
//       'Janjgir-Champa',
//       'Korba',
//       'Koriya',
//       'Kanker',
//       'Kabirdham (Kawardha)',
//       'Mahasamund',
//       'Narayanpur',
//       'Raigarh',
//       'Rajnandgaon',
//       'Raipur',
//       'Surguja',],
//     "Dadra and Nagar Haveli (DN)":["Dadra and Nagar Haveli"],
//     "Daman and Diu (DD)":['Daman',
//       'Diu',],
//     "Delhi (DL)":['Central Delhi',
//       'East Delhi',
//       'New Delhi',
//       'North Delhi',
//       'North East Delhi',
//       'North West Delhi',
//       'South Delhi',
//       'South West Delhi',
//       'West Delhi',],
//     "Goa (GA)":['North Goa',
//       'South Goa'],
//     "Gujarat (GJ)":['Ahmedabad',
//       'Amreli district',
//       'Anand',
//       'Banaskantha',
//       'Bharuch',
//       'Bhavnagar',
//       'Dahod',
//       'The Dangs',
//       'Gandhinagar',
//       'Jamnagar',
//       'Junagadh',
//       'Kutch',
//       'Kheda',
//       'Mehsana',
//       'Narmada',
//       'Navsari',
//       'Patan',
//       'Panchmahal',
//       'Porbandar',
//       'Rajkot',
//       'Sabarkantha',
//       'Surendranagar',
//       'Surat',
//       'Vyara',
//       'Vadodara',
//       'Valsad',],
//     "Haryana (HR)":['Ambala',
//       'Bhiwani',
//       'Faridabad',
//       'Fatehabad',
//       'Gurgaon',
//       'Hissar',
//       'Jhajjar',
//       'Jind',
//       'Karnal',
//       'Kaithal',
//       'Kurukshetra',
//       'Mahendragarh',
//       'Mewat',
//       'Palwal',
//       'Panchkula',
//       'Panipat',
//       'Rewari',
//       'Rohtak',
//       'Sirsa',
//       'Sonipat',
//       'Yamuna Nagar',],
//     "Himachal Pradesh (HP)":['Bilaspur',
//       'Chamba',
//       'Hamirpur',
//       'Kangra',
//       'Kinnaur',
//       'Kullu',
//       'Lahaul and Spiti',
//       'Mandi',
//       'Shimla',
//       'Sirmaur',
//       'Solan',
//       'Una',],
//     "Jammu and Kashmir (JK)":['Anantnag',
//       'Badgam',
//       'Bandipora',
//       'Baramulla',
//       'Doda',
//       'Ganderbal',
//       'Jammu',
//       'Kargil',
//       'Kathua',
//       'Kishtwar',
//       'Kupwara',
//       'Kulgam',
//       'Leh',
//       'Poonch',
//       'Pulwama',
//       'Rajauri',
//       'Ramban',
//       'Reasi',
//       'Samba',
//       'Shopian',
//       'Srinagar',
//       'Udhampur',],
//     "Jharkhand (JH)":['Bokaro',
//       'Chatra',
//       'Deoghar',
//       'Dhanbad',
//       'Dumka',
//       'East Singhbhum',
//       'Garhwa',
//       'Giridih',
//       'Godda',
//       'Gumla',
//       'Hazaribag',
//       'Jamtara',
//       'Khunti',
//       'Koderma',
//       'Latehar',
//       'Lohardaga',
//       'Pakur',
//       'Palamu',
//       'Ramgarh',
//       'Ranchi',
//       'Sahibganj',
//       'Seraikela Kharsawan',
//       'Simdega',
//       'West Singhbhum',],
//     "Karnataka (KA)":['Bagalkot',
//       'Bangalore Rural',
//       'Bangalore Urban',
//       'Belgaum',
//       'Bellary',
//       'Bidar',
//       'Bijapur',
//       'Chamarajnagar',
//       'Chikkamagaluru',
//       'Chikkaballapur',
//       'Chitradurga',
//       'Davanagere',
//       'Dharwad',
//       'Dakshina Kannada',
//       'Gadag',
//       'Gulbarga',
//       'Hassan',
//       'Haveri district',
//       'Kodagu',
//       'Kolar',
//       'Koppal',
//       'Mandya',
//       'Mysore',
//       'Raichur',
//       'Shimoga',
//       'Tumkur',
//       'Udupi',
//       'Uttara Kannada',
//       'Ramanagara',
//       'Yadgir',],
//     "Kerala (KL)":['Alappuzha',
//       'Ernakulam',
//       'Idukki',
//       'Kannur',
//       'Kasaragod',
//       'Kollam',
//       'Kottayam',
//       'Kozhikode',
//       'Malappuram',
//       'Palakkad',
//       'Pathanamthitta',
//       'Thrissur',
//       'Thiruvananthapuram',
//       'Wayanad',],
//     "Madhya Pradesh (MP)":['Alirajpur',
//       'Anuppur',
//       'Ashok Nagar',
//       'Balaghat',
//       'Barwani',
//       'Betul',
//       'Bhind',
//       'Bhopal',
//       'Burhanpur',
//       'Chhatarpur',
//       'Chhindwara',
//       'Damoh',
//       'Datia',
//       'Dewas',
//       'Dhar',
//       'Dindori',
//       'Guna',
//       'Gwalior',
//       'Harda',
//       'Hoshangabad',
//       'Indore',
//       'Jabalpur',
//       'Jhabua',
//       'Katni',
//       'Khandwa (East Nimar)',
//       'Khargone (West Nimar)',
//       'Mandla',
//       'Mandsaur',
//       'Morena',
//       'Narsinghpur',
//       'Neemuch',
//       'Panna',
//       'Rewa',
//       'Rajgarh',
//       'Ratlam',
//       'Raisen',
//       'Sagar',
//       'Satna',
//       'Sehore',
//       'Seoni',
//       'Shahdol',
//       'Shajapur',
//       'Sheopur',
//       'Shivpuri',
//       'Sidhi',
//       'Singrauli',
//       'Tikamgarh',
//       'Ujjain',
//       'Umaria',
//       'Vidisha',],
//     "Maharashtra (MH)":['Ahmednagar',
//       'Akola',
//       'Amravati',
//       'Aurangabad',
//       'Bhandara',
//       'Beed',
//       'Buldhana',
//       'Chandrapur',
//       'Dhule',
//       'Gadchiroli',
//       'Gondia',
//       'Hingoli',
//       'Jalgaon',
//       'Jalna',
//       'Kolhapur',
//       'Latur',
//       'Mumbai City',
//       'Mumbai suburban',
//       'Nandurbar',
//       'Nanded',
//       'Nagpur',
//       'Nashik',
//       'Osmanabad',
//       'Parbhani',
//       'Pune',
//       'Raigad',
//       'Ratnagiri',
//       'Sindhudurg',
//       'Sangli',
//       'Solapur',
//       'Satara',
//       'Thane',
//       'Wardha',
//       'Washim',
//       'Yavatmal',],
//     "Manipur (MN)":['Bishnupur',
//     'Churachandpur',
//       'Chandel',
//       'Imphal East',
//       'Senapati',
//       'Tamenglong',
//       'Thoubal',
//       'Ukhrul',
//       'Imphal West',],
//   'Meghalaya (ML)':[
//   'East Garo Hills',
//   'East Khasi Hills',
//   'Jaintia Hills',
//   'Ri Bhoi',
//   'South Garo Hills',
//   'West Garo Hills',
//   'West Khasi Hills',
//   ],
//   'Mizoram (MZ)':[
//   'Aizawl',
//   'Champhai',
//   'Kolasib',
//   'Lawngtlai',
//   'Lunglei',
//   'Mamit',
//   'Saiha',
//   'Serchhip',
//   ],
//
//   'Nagaland (NL)':[
//   'Dimapur',
//   'Kohima',
//   'Mokokchung',
//   'Mon',
//   'Phek',
//   'Tuensang',
//   'Wokha',
//   'Zunheboto',
//   ],
//   'Orissa (OR)':[
//   'Angul',
//   'Boudh (Bauda)',
//   'Bhadrak',
//   'Balangir',
//   'Bargarh (Baragarh)',
//   'Balasore',
//   'Cuttack',
//   'Debagarh (Deogarh)',
//   'Dhenkanal',
//   'Ganjam',
//   'Gajapati',
//   'Jharsuguda',
//   'Jajpur',
//   'Jagatsinghpur',
//   'Khordha',
//   'Kendujhar (Keonjhar)',
//   'Kalahandi',
//   'Kandhamal',
//   'Koraput',
//   'Kendrapara',
//   'Malkangiri',
//   'Mayurbhanj',
//   'Nabarangpur',
//   'Nuapada',
//   'Nayagarh',
//   'Puri',
//   'Rayagada',
//   'Sambalpur',
//   'Subarnapur (Sonepur)',
//   'Sundergarh',
//   ],
//   'Pondicherry (Puducherry) (PY)':[
//   'Karaikal',
//   'Mahe',
//   'Pondicherry',
//   'Yanam',
//   ],
//   'Punjab (PB)':[
//   'Amritsar',
//   'Barnala',
//   'Bathinda',
//   'Firozpur',
//   'Faridkot',
//   'Fatehgarh Sahib',
//   'Fazilka',
//   'Gurdaspur',
//   'Hoshiarpur',
//   'Jalandhar',
//   'Kapurthala',
//   'Ludhiana',
//   'Mansa',
//   'Moga',
//   'Sri Muktsar Sahib',
//   'Pathankot',
//   'Patiala',
//   'Rupnagar',
//   'Ajitgarh (Mohali)',
//   'Sangrur',
//   'Nawanshahr',
//   'Tarn Taran',
//   ],
//   'Rajasthan (RJ)':[
//   'Ajmer',
//   'Alwar',
//   'Bikaner',
//   'Barmer',
//   'Banswara',
//   'Bharatpur',
//   'Baran',
//   'Bundi',
//   'Bhilwara',
//   'Churu',
//   'Chittorgarh',
//   'Dausa',
//   'Dholpur',
//   'Dungapur',
//   'Ganganagar',
//   'Hanumangarh',
//   'Jhunjhunu',
//   'Jalore',
//   'Jodhpur',
//   'Jaipur',
//   'Jaisalmer',
//   'Jhalawar',
//   'Karauli',
//   'Kota',
//   'Nagaur',
//   'Pali',
//   'Pratapgarh',
//   'Rajsamand',
//   'Sikar',
//   'Sawai Madhopur',
//   'Sirohi',
//   'Tonk',
//   'Udaipur',
//   ],
//
//   'Sikkim (SK)':[
//   'East Sikkim',
//   'North Sikkim',
//   'South Sikkim',
//   'West Sikkim',
//   ],
//   'Tamil Nadu (TN)':[
//   'Ariyalur',
//   'Chennai',
//   'Coimbatore',
//   'Cuddalore',
//   'Dharmapuri',
//   'Dindigul',
//   'Erode',
//   'Kanchipuram',
//   'Kanyakumari',
//   'Karur',
//   'Madurai',
//   'Nagapattinam',
//   'Nilgiris',
//   'Namakkal',
//   'Perambalur',
//   'Pudukkottai',
//   'Ramanathapuram',
//   'Salem',
//   'Sivaganga',
//   'Tirupur',
//   'Tiruchirappalli',
//   'Theni',
//   'Tirunelveli',
//   'Thanjavur',
//   'Thoothukudi',
//   'Tiruvallur',
//   'Tiruvarur',
//   'Tiruvannamalai',
//   'Vellore',
//   'Viluppuram',
//   'Virudhunagar',
//   ],
//   'Tripura (TR)':[
//   'Dhalai',
//   'North Tripura',
//   'South Tripura',
//   'Khowai',
//   'West Tripura',
//   ],
//   'Uttar Pradesh (UP)':[
//   'Agra',
//   'Allahabad',
//   'Aligarh',
//   'Ambedkar Nagar',
//   'Auraiya',
//   'Azamgarh',
//   'Barabanki',
//   'Budaun',
//   'Bagpat',
//   'Bahraich',
//   'Bijnor',
//   'Ballia',
//   'Banda',
//   'Balrampur',
//   'Bareilly',
//   'Basti',
//   'Bulandshahr',
//   'Chandauli',
//   'Chhatrapati Shahuji Maharaj Nagar',
//   'Chitrakoot',
//   'Deoria',
//   'Etah',
//   'Kanshi Ram Nagar',
//   'Etawah',
//   'Firozabad',
//   'Farrukhabad',
//   'Fatehpur',
//   'Faizabad',
//   'Gautam Buddh Nagar',
//   'Gonda',
//   'Ghazipur',
//   'Gorakhpur',
//   'Ghaziabad',
//   'Hamirpur',
//   'Hardoi',
//   'Mahamaya Nagar',
//   'Jhansi',
//   'Jalaun',
//   'Jyotiba Phule Nagar',
//   'Jaunpur district',
//   'Ramabai Nagar (Kanpur Dehat)',
//   'Kannauj',
//   'Kanpur',
//   'Kaushambi',
//   'Kushinagar',
//   'Lalitpur',
//   'Lakhimpur Kheri',
//   'Lucknow',
//   'Mau',
//   'Meerut',
//   'Maharajganj',
//   'Mahoba',
//   'Mirzapur',
//   'Moradabad',
//   'Mainpuri',
//   'Mathura',
//   'Muzaffarnagar',
//   'Panchsheel Nagar district (Hapur)',
//   'Pilibhit',
//   'Shamli',
//   'Pratapgarh',
//   'Rampur',
//   'Raebareli',
//   'Saharanpur',
//   'Sitapur',
//   'Shahjahanpur',
//   'Sant Kabir Nagar',
//   'Siddharthnagar',
//   'Sonbhadra',
//   'Sant Ravidas Nagar',
//   'Sultanpur',
//   'Shravasti',
//   'Unnao',
//   'Varanasi',
//   ],
//   'Uttarakhand (UK)':[
//   'Almora',
//   'Bageshwar',
//   'Chamoli',
//   'Champawat',
//   'Dehradun',
//   'Haridwar',
//   'Nainital',
//   'Pauri Garhwal',
//   'Pithoragarh',
//   'Rudraprayag',
//   'Tehri Garhwal',
//   'Udham Singh Nagar',
//   'Uttarkashi',
//   ],
//   'West Bengal (WB)':[
//   'Birbhum',
//   'Bankura',
//   'Bardhaman',
//   'Darjeeling',
//   'Dakshin Dinajpur',
//   'Hooghly',
//   'Howrah',
//   'Jalpaiguri',
//   'Cooch Behar',
//   'Kolkata',
//   'Maldah',
//   'Paschim Medinipur',
//   'Purba Medinipur',
//   'Murshidabad',
//   'Nadia',
//   'North 24 Parganas',
//   'South 24 Parganas',
//   'Purulia',
//   'Uttar Dinajpur',
//   ],
//
//
// };
//   List<String> states=["Andhra Pradesh (AP)",
//    "Arunachal Pradesh (AR)","Assam (AS)","Bihar (BR)",
//     "Chhattisgarh (CG)","Dadra and Nagar Haveli (DN)","Daman and Diu (DD)","Delhi (DL)",
//         "Goa (GA)","Gujarat (GJ)","Haryana (HR)",
//     "Himachal Pradesh (HP)","Jammu and Kashmir (JK)","Jharkhand (JH)","Karnataka (KA)",
//       "Kerala (KL)","Madhya Pradesh (MP)","Maharashtra (MH)",
//     "Manipur (MN)","Meghalaya (ML)",
//     "Mizoram (MZ)","Nagaland (NL)","Orissa (OR)","Pondicherry (Puducherry) (PY)",
//     "Punjab (PB)","Rajasthan (RJ)","Sikkim (SK)",
//     "Tamil Nadu (TN)", "Telangana","Tripura (TR)","Uttar Pradesh (UP)","Uttarakhand (UK)",
//     "West Bengal (WB)"
//   ];
}








