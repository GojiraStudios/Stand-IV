
import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:convert' as convert;

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
//import 'package:shared_preferences/shared_preferences.dart';
import 'package:standivadmin/root.dart';
import 'package:standivadmin/signin.dart';
import 'package:standivadmin/signup.dart';

import 'homepage.dart';
import 'multi.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key, required });

  // This widget is the sigin page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".



  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
  late FirebaseMessaging messaging;
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }
  void showNotification(RemoteNotification remoteNotification) async {
    AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
      Platform.isAndroid ? 'com.standiv.standivnew' : 'com.standiv.standivnew',
      'StandIV',
      playSound: true,
      enableVibration: true,
      importance: Importance.max,
      priority: Priority.high,
    );
    IOSNotificationDetails iOSPlatformChannelSpecifics = IOSNotificationDetails();
    NotificationDetails platformChannelSpecifics =
    NotificationDetails(android: androidPlatformChannelSpecifics, iOS: iOSPlatformChannelSpecifics);

    print(remoteNotification);

    await flutterLocalNotificationsPlugin.show(
      0,
      remoteNotification.title,
      remoteNotification.body,
      platformChannelSpecifics,
      payload: null,
    );
  }


  void registerNotification() {
    firebaseMessaging.requestPermission();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('onMessage: $message');
      if (message.notification != null) {
        showNotification(message.notification!);
      }
      return;
    });

    // firebaseMessaging.getToken().then((token) {
    //   print('push token: $token');
    //   if (token != null) {
    //     homeProvider.updateDataFirestore(FirestoreConstants.pathUserCollection, currentUserId, {'pushToken': token});
    //   }
    // }).catchError((err) {
    //   Fluttertoast.showToast(msg: err.message.toString());
    // });
  }

  void configLocalNotification() {
    AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('ic_launcher');
    IOSInitializationSettings initializationSettingsIOS = IOSInitializationSettings();
    InitializationSettings initializationSettings =
    InitializationSettings(android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  final FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();


  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);

  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  void navigationPage() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => siginPage()));

    }
  List<String> yesVotes=[];
  List<String> noVotes=[];
  List<String> nuetralVotes=[];
  int totalVotes=0;
  late AudioPlayer player = AudioPlayer();
  @override
  void initState() {

    setState(() {
      player.stop();
      player.pause();
    });


    super.initState();
    final Timestamp oldPosts = Timestamp.fromDate(
      DateTime.now().subtract(const Duration(minutes: 15)),);
    final Timestamp broadCastoldPosts = Timestamp.fromDate(
      DateTime.now().subtract(const Duration(minutes: 10)),);

    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("timestamp",isLessThan: oldPosts)
        .get().then((QuerySnapshot qs) {
      // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        if(doc['stack']!="Gold Stack" && doc['stack']!="BroadCasts"){
          setState(() {

            //now getting all votes for that post
            FirebaseFirestore.instance
                .collection('votes').where("postId",isEqualTo: doc.id )

                .get().then((QuerySnapshot qsvote) async {
              // print(qs.docs.length.toString());
              nuetralVotes.clear();
              yesVotes.clear();
              nuetralVotes.clear();
              totalVotes= qsvote.docs.length;
              qsvote.docs.forEach((votes) {
                setState(() {
                  //now adding all votes to lists e.g yes,no or neutral
                  if(votes['voteType']=='neutral'){
                    nuetralVotes.add(votes['voterId']);
                  }
                  if(votes['voteType']=='yes'){
                    yesVotes.add(votes['voterId']);
                  }
                  else {
                    noVotes.add(votes['voterId']);
                  }

                });

              } );
              print("nasd");
              print(nuetralVotes.length.toString()+"neutral votes");
              print(yesVotes.length.toString()+"yes votes");
              print(noVotes.length.toString()+"no votes");
              // now we calculate function to see winner
              List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
              int winner=votesCheck.indexOf(votesCheck.reduce(max));
              //now we check which vote type has most votes and then we add coins to each user
              print(winner.toString()+"winner");
              double percentage=0;


              //now we add coins for winner
              //we get each users coin value and then add 20 coins for winner
              if(winner==0){
                percentage= (nuetralVotes.length/totalVotes)*100;
                for(int i=0;i<nuetralVotes.length;i++){

                  await    FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    if(percentage<60){
                      int coins=qs.docs[0]["coins"]+15;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<70){
                      int coins=qs.docs[0]["coins"]+16;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<80){
                      int coins=qs.docs[0]["coins"]+17;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<90){
                      int coins=qs.docs[0]["coins"]+18;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<100){
                      int coins=qs.docs[0]["coins"]+19;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage==100){
                      int coins=qs.docs[0]["coins"]+20;
                      FirebaseFirestore.instance
                          .collection("users").doc(nuetralVotes[i]).update({


                        "coins": coins,

                      });
                    }

                    print(qs.docs[0].id);

                  });
                }
                FirebaseFirestore.instance
                    .collection("posts").doc(doc.id).update({


                  "isDone": true,

                });
              }
              else if(winner==1){
                percentage= (yesVotes.length/totalVotes)*100;
                print(percentage);
                for(int i=0;i<yesVotes.length;i++){
                  print(yesVotes[i]);
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    if(percentage<60){
                      int coins=qs.docs[0]["coins"]+15;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<70){
                      int coins=qs.docs[0]["coins"]+16;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<80){
                      int coins=qs.docs[0]["coins"]+17;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<90){
                      int coins=qs.docs[0]["coins"]+18;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<100){
                      int coins=qs.docs[0]["coins"]+19;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage==100){
                      int coins=qs.docs[0]["coins"]+20;
                      FirebaseFirestore.instance
                          .collection("users").doc(yesVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    print(qs.docs[0].id);

                  });

                }

                if(percentage<60){
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+50;
                    //  int winningPosts
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,
                    });
                    print(qs.docs[0].id);

                  });
                }

                else if(percentage<70){
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+55;
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,
                    });
                    print(qs.docs[0].id);

                  });
                }
                else if(percentage<80){
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+60;
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,
                    });
                    print(qs.docs[0].id);

                  });
                }
                else if(percentage<90){
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+65;
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,

                    });
                    print(qs.docs[0].id);

                  });
                }
                else if(percentage<100){
                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+70;
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,

                    });
                    print(qs.docs[0].id);

                  });
                }
                else if(percentage==100){
                  print( "iam here");

                  await      FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    int coins=qs.docs[0]["coins"]+75;
                    int winningPost=qs.docs[0]["winningPost"]+1;
                    FirebaseFirestore.instance
                        .collection("users").doc(doc['userid']).update({


                      "coins": coins,
                      "winningPost": winningPost,

                    });
                    print(qs.docs[0].id);

                  });
                };

                FirebaseFirestore.instance
                    .collection("posts").doc(doc.id).update({


                  "isDone": true,

                });
              }
              else{
                percentage= (noVotes.length/totalVotes)*100;
                for(int i=0;i<noVotes.length;i++){
                  print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

                  await   FirebaseFirestore.instance
                      .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                      .get().then((QuerySnapshot qs) {
                    if(percentage<60){
                      int coins=qs.docs[0]["coins"]+15;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<70){
                      int coins=qs.docs[0]["coins"]+16;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<80){
                      int coins=qs.docs[0]["coins"]+17;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<90){
                      int coins=qs.docs[0]["coins"]+18;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage<100){
                      int coins=qs.docs[0]["coins"]+19;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                    else if(percentage==100){
                      int coins=qs.docs[0]["coins"]+20;
                      FirebaseFirestore.instance
                          .collection("users").doc(noVotes[i]).update({


                        "coins": coins,

                      });
                    }
                  });

                }
                FirebaseFirestore.instance
                    .collection("posts").doc(doc.id).update({


                  "isDone": true,

                });

              }

            });
            //  print(doc.id);
            //  userDocument=qs.docs[0];
            //  userName=qs.docs[0]['userName'].toString();
            //  totalCoins=qs.docs[0]['coins'].toString();
          });
        }


      } );


    });


    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("stack",isEqualTo: "Gold Stack")
        .where("timestamp",isLessThan: oldPosts)
        .get().then((QuerySnapshot qs) {
      // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        setState(() {

          //now getting all votes for that post
          FirebaseFirestore.instance
              .collection('votes').where("postId",isEqualTo: doc.id )

              .get().then((QuerySnapshot qsvote) async {
            // print(qs.docs.length.toString());
            nuetralVotes.clear();
            yesVotes.clear();
            nuetralVotes.clear();
            totalVotes= qsvote.docs.length;
            qsvote.docs.forEach((votes) {
              setState(() {
                //now adding all votes to lists e.g yes,no or neutral
                if(votes['voteType']=='neutral'){
                  nuetralVotes.add(votes['voterId']);
                }
                if(votes['voteType']=='yes'){
                  yesVotes.add(votes['voterId']);
                }
                else {
                  noVotes.add(votes['voterId']);
                }

              });

            } );
            print("nasd");
            print(nuetralVotes.length.toString()+"neutral votes");
            print(yesVotes.length.toString()+"yes votes");
            print(noVotes.length.toString()+"no votes");
            // now we calculate function to see winner
            List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
            int winner=votesCheck.indexOf(votesCheck.reduce(max));
            //now we check which vote type has most votes and then we add coins to each user
            print(winner.toString()+"winner");
            double percentage=0;


            //now we add coins for winner
            //we get each users coin value and then add 20 coins for winner
            if(winner==0){
              percentage= (nuetralVotes.length/totalVotes)*100;
              for(int i=0;i<nuetralVotes.length;i++){

                await    FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(nuetralVotes[i]).update({


                      "coins": coins,

                    });
                  }

                  print(qs.docs[0].id);

                });
              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else if(winner==1){
              percentage= (yesVotes.length/totalVotes)*100;
              for(int i=0;i<yesVotes.length;i++){
                print(yesVotes[i]);
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(yesVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  print(qs.docs[0].id);

                });

              }
              if(percentage<60){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+100;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<70){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+110;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<80){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+120;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<90){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+130;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage<100){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+140;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              }
              else if(percentage==100){
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+150;
                  int winningPost=qs.docs[0]["winningPost"]+1;
                  FirebaseFirestore.instance
                      .collection("users").doc(doc['userid']).update({


                    "coins": coins,
                    "winningPost": winningPost,

                  });
                  print(qs.docs[0].id);

                });
              };

              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else{
              percentage= (noVotes.length/totalVotes)*100;
              for(int i=0;i<noVotes.length;i++){
                print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

                await   FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  if(percentage<60){
                    int coins=qs.docs[0]["coins"]+15;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<70){
                    int coins=qs.docs[0]["coins"]+16;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<80){
                    int coins=qs.docs[0]["coins"]+17;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<90){
                    int coins=qs.docs[0]["coins"]+18;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage<100){
                    int coins=qs.docs[0]["coins"]+19;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                  else if(percentage==100){
                    int coins=qs.docs[0]["coins"]+20;
                    FirebaseFirestore.instance
                        .collection("users").doc(noVotes[i]).update({


                      "coins": coins,

                    });
                  }
                });

              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });

            }

          });
          //  print(doc.id);
          //  userDocument=qs.docs[0];
          //  userName=qs.docs[0]['userName'].toString();
          //  totalCoins=qs.docs[0]['coins'].toString();
        });

      } );


    });
    FirebaseFirestore.instance
        .collection('posts').where("isDone",isEqualTo: false ).where("stack",isEqualTo: "BroadCasts")
        .where("timestamp",isLessThan: broadCastoldPosts)
        .get().then((QuerySnapshot qs) {
      // print(qs.docs.length.toString());
      qs.docs.forEach((doc) {
        setState(() {

          //now getting all votes for that post
          FirebaseFirestore.instance
              .collection('votes').where("postId",isEqualTo: doc.id )

              .get().then((QuerySnapshot qsvote) async {
            // print(qs.docs.length.toString());
            nuetralVotes.clear();
            yesVotes.clear();
            nuetralVotes.clear();
            totalVotes= qsvote.docs.length;
            qsvote.docs.forEach((votes) {
              setState(() {
                //now adding all votes to lists e.g yes,no or neutral
                if(votes['voteType']=='neutral'){
                  nuetralVotes.add(votes['voterId']);
                }
                if(votes['voteType']=='yes'){
                  yesVotes.add(votes['voterId']);
                }
                else {
                  noVotes.add(votes['voterId']);
                }

              });

            } );
            print("nasd");
            print(nuetralVotes.length.toString()+"neutral votes");
            print(yesVotes.length.toString()+"yes votes");
            print(noVotes.length.toString()+"no votes");
            // now we calculate function to see winner
            List<int> votesCheck=[nuetralVotes.length,yesVotes.length,noVotes.length,];
            int winner=votesCheck.indexOf(votesCheck.reduce(max));
            //now we check which vote type has most votes and then we add coins to each user
            print(winner.toString()+"winner");
            double percentage=0;


         //   now we add coins for winner
           // we get each users coin value and then add 20 coins for winner
            if(winner==0){
              percentage= (nuetralVotes.length/totalVotes)*100;
              for(int i=0;i<nuetralVotes.length;i++){

                await    FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: nuetralVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+2;
                  FirebaseFirestore.instance
                      .collection("users").doc(nuetralVotes[i]).update({


                    "coins": coins,

                  });


                  print(qs.docs[0].id);

                });
              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else if(winner==1){
              percentage= (yesVotes.length/totalVotes)*100;
              for(int i=0;i<yesVotes.length;i++){
                print(yesVotes[i]);
                await      FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: yesVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {

                  int coins=qs.docs[0]["coins"]+2;
                  FirebaseFirestore.instance
                      .collection("users").doc(yesVotes[i]).update({


                    "coins": coins,

                  });


                  print(qs.docs[0].id);

                });

              }

              await      FirebaseFirestore.instance
                  .collection('users').where("userid",isEqualTo: doc['userid'] ).limit(1)
                  .get().then((QuerySnapshot qs) {
                int coins=qs.docs[0]["coins"]+2000+(yesVotes.length*2);
                int winningPost=qs.docs[0]["winningPost"]+1;
                FirebaseFirestore.instance
                    .collection("users").doc(doc['userid']).update({


                  "coins": coins,
                  "winningPost": winningPost,

                });
                print(qs.docs[0].id);

              });



              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });
            }
            else{
              percentage= (noVotes.length/totalVotes)*100;
              for(int i=0;i<noVotes.length;i++){
                print(noVotes[i]+"noVotes"+i.toString()+noVotes.length.toString());

                await   FirebaseFirestore.instance
                    .collection('users').where("userid",isEqualTo: noVotes[i] ).limit(1)
                    .get().then((QuerySnapshot qs) {
                  int coins=qs.docs[0]["coins"]+2;
                  FirebaseFirestore.instance
                      .collection("users").doc(noVotes[i]).update({


                    "coins": coins,

                  });
                });

              }
              FirebaseFirestore.instance
                  .collection("posts").doc(doc.id).update({


                "isDone": true,

              });

            }

          });
          //  print(doc.id);
          //  userDocument=qs.docs[0];
          //  userName=qs.docs[0]['userName'].toString();
          //  totalCoins=qs.docs[0]['coins'].toString();
        });

      } );


    });
    registerNotification();
    configLocalNotification();
  //   messaging = FirebaseMessaging.instance;
  //   _firebaseMessaging.getToken().then((token){
  //     print(token.toString()+"1st");
  //   });
  //   _firebaseMessaging.getToken().then((value){
  //     print(value.toString()+"asdads");
  //   });
  //   FirebaseMessaging.onMessage.listen((RemoteMessage event) {
  //     print("message recieved");
  //     print(event.notification!.body);
  //   });
  //   FirebaseMessaging.onMessageOpenedApp.listen((message) {
  //     print('Message clicked!');
  //   });
  //   FirebaseMessaging.onMessage.listen((RemoteMessage event) {
  //     print("message recieved");
  //     print(event.notification!.body);
  //     showDialog(
  //         context: context,
  //         builder: (BuildContext context) {
  //           return AlertDialog(
  //             title: Text("New post in broadcast"),
  //             content: Text(event.notification!.body!),
  //             actions: [
  //               TextButton(
  //                 child: Text("Ok"),
  //                 onPressed: () {
  //                  // Navigator.of(context).pop();
  //                 },
  //               )
  //             ],
  //           );
  //         });
  //   });
   }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
      return Scaffold(
backgroundColor: Colors.black,
      body:
          SingleChildScrollView(
            child: Container(

              margin: EdgeInsets.only(

                  top: MediaQuery.of(context).size.height*0.10,),
             // height: MediaQuery.of(context).size.height,
            child: Column(
              //mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
              Align(alignment: Alignment.center,
                child: Container(
                  height: 300,
                  child: new Image.asset(
                    'assets/logo.png',
                    fit: BoxFit.cover,

                    alignment: Alignment.center,
                  ),
                ),
              ),
              SizedBox(height: 30,),
              Align(alignment: Alignment.center,

                child: Text("Welcome!",style:  GoogleFonts.salsa(textStyle:
                TextStyle(color:Colors.white,fontSize: 40,fontWeight: FontWeight.bold)),),
              ),SizedBox(height: 5,),
// Container(height: Get.height*3,
// child: SingleAssetPage(),),

              InkWell(
                onTap: () async {
               //   await FirebaseAuth.instance.signOut();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => RootScreen(newUser: false,)));

                  // if(FirebaseAuth.instance.currentUser ==null){
                  //   Navigator.push(
                  //       context,
                  //       MaterialPageRoute(
                  //           builder: (context) => siginPage( )));
                  //
                  // }
                  // else{
                  //   Navigator.push(
                  //       context,
                  //       MaterialPageRoute(
                  //           builder: (context) => HomePage( )));
                  //
                  //
                  //
                  //
                  // }

                },
                child:new Container(

                    margin: EdgeInsets.only(top: 80),
                    width:Get.width*0.70,
                    height: 55,
                    decoration: new BoxDecoration(
                      borderRadius: new BorderRadius.circular(360.0),
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Color.fromRGBO(146, 31, 23, 1),
                          Color.fromRGBO(188, 40, 28, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                          Color.fromRGBO(232, 50, 35, 1),
                        ],),
                      //   color: Colors.red,

                    ),
                    child:

                    Center(child: Text("Get Started",style: GoogleFonts.salsa(textStyle:TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w500,fontSize: 20),)))
                ),
              ),

            ],),
            ),
          )



     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
