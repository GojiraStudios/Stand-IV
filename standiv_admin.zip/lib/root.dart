
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:standivadmin/instrcutionsScreen.dart';
import 'package:standivadmin/signin.dart';

import 'homepage.dart';
class RootScreen extends StatefulWidget {
  bool newUser;
  RootScreen({required this.newUser});
  
  @override
  State<StatefulWidget> createState() => new _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
//   void navigationPage() {
//
//     // if(FirebaseAuth.instance.currentUser !=null){
//     //   Navigator.push(
//     //       context,
//     //       MaterialPageRoute(
//     //           builder: (context) => HomePage(uid:FirebaseAuth.instance.currentUser!.uid )));
//     //
//     //
//     // }
//     // else{
//       Navigator.push(
//           context,
//           MaterialPageRoute(
//               builder: (context) => siginPage( )));
//
//
//     // }
//
//   }
//   startTime() async {
//     var _duration = new Duration(seconds: 1);
//     return new Timer(_duration, navigationPage);
//   }
//
//   void initState() {
//
// startTime();
//     super.initState();
//
//   }
  @override
  Widget build(BuildContext context) {

     return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.userChanges(),
      initialData: FirebaseAuth.instance.currentUser,
      builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
        // Check if user is logged in
        final String? uid = snapshot.data?.uid ?? null;

        if (uid != null)
          return StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('users').where("userid",isEqualTo: FirebaseAuth.instance.currentUser!.uid ).limit(1)
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshots) {
                // String data = snapshot.data.toString();
                if (!snapshot.hasData)
                  return SizedBox();
              return snapshots.data?.docs[0]["isFirstLoggedIn"]==true?
              InstructionsScreen(uid:FirebaseAuth.instance.currentUser!.uid):
              HomePage(isNew: true,);
            }
          );

        return siginPage();
      },
    );;
  }
}
