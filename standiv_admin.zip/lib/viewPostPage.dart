
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:firebase_auth/firebase_auth.dart';
import 'package:flip_card/flip_card.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:standivadmin/homepage.dart';
import 'package:standivadmin/phoneverification.dart';

class ViewPosts extends StatefulWidget {

  final String uId;
  ViewPosts({super.key, required,required this.uId });


@override
State<ViewPosts> createState() => _ViewPostsState();
}

class _ViewPostsState extends State<ViewPosts> {


  bool isLoading=true;
  List<String>  postStack=['Bronze Level','Silver Level', 'Gold Level', 'BroadCasts'];

  String? level;

  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);
  String? stack;

  @override
  void initState()   {



    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return

      DefaultTabController(
        length: 2,

        child:
        Scaffold(

          appBar: PreferredSize(
            preferredSize: Size.fromHeight(145), // Set this height
            child: Container(
              //margin: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  SizedBox(height: 60,),
                  Container(
                      margin: EdgeInsets.symmetric(horizontal: 20),
                      color: Colors.white,
                      height: 40,
                      width: Get.width,

                      child:
                      Row(children: [
                        SizedBox(width: 10,),
                        InkWell(
                          onTap: (){
                            Navigator.pop(context);

                          },
                          child:ImageIcon(
                            AssetImage("assets/backicon.png"),color: Colors.black,
                            size: 25,
                          ),
                        ),
                        SizedBox(width: 70,),
                        Text( "Your Posts",style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold),),
                        Spacer(),

                      ],)
                  ),
                  Divider(color: Colors.black,thickness: 2,),
                  TabBar(

                    padding: EdgeInsets.symmetric(horizontal: 20),
                    indicator: BoxDecoration(
                        borderRadius: BorderRadius.circular(10), // Creates border
                        color: Colors.red),

//indicatorColor: Colors.black,
                    tabs: [
                      Tab( child: Text("Your Posts",style: TextStyle(color: Colors.black),),),
                      Tab(child: Text("Posts You Vote On",style: TextStyle(color: Colors.black),))
                    ],
                  ),
                ],
              ),
            ),


          ),
          backgroundColor: Colors.white,
          body:
          TabBarView(
            children: [
              // tab one view
              SingleChildScrollView(
                // height: Get.height*3,
                child: Column(children: [
                  Container(
                    margin: EdgeInsets.only(left: 20,right: 20,top: 10,bottom: 10),
                    width: Get.width,
                    child: DropdownButton2(
                      isExpanded: true,
                      hint: Row(
                        children: const [

                          SizedBox(
                            width: 4,
                          ),
                          Expanded(
                            child: Text(
                              'Select Level',
                              style: TextStyle(
                                fontSize: 14,


                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      items: postStack
                          .map((item) => DropdownMenuItem<String>(
                        value: item,
                        child: Text(
                          item,
                          style: const TextStyle(
                            fontSize: 14,

                            color: Colors.black45,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ))
                          .toList(),
                      value: stack,
                      onChanged: (value) {
                        setState(() {


                          if(stack!=value){
                            stack= stack = value as String;
                            print(stack);
                          }
                          if(stack=='Bronze Level'){
                            level='Bronze Stack';
                          }

                          else  if(stack=='Silver Level'){
                            level='Silver Stack';
                          }
                          else if(stack=='Gold Level'){
                            level='Gold Stack';
                          }
                          else {
                            level=stack!;
                          }







                        });
                      },
                      icon: const Icon(
                        Icons.arrow_drop_down_outlined,
                      ),
                      iconSize: 20,
                      iconEnabledColor: Colors.black45,
                      iconDisabledColor: Colors.grey,

                      buttonPadding: const EdgeInsets.only(left: 15, right: 15),

                      buttonElevation: 2,
                      itemHeight: 40,
                      itemPadding: const EdgeInsets.only(left: 15, right: 15),
                      dropdownMaxHeight: 200,
                      dropdownWidth: 200,
                      dropdownPadding: null,
                      dropdownDecoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.white,
                      ),
                      dropdownElevation: 8,
                      scrollbarRadius: const Radius.circular(40),
                      scrollbarThickness: 6,
                      scrollbarAlwaysShow: true,
                      offset: const Offset(-20, 0),
                    ),
                  ),
                  stack==null?SizedBox(): StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('posts')
                        //  .where("userid",isEqualTo: widget.uId)

                          .where("stack",isEqualTo: level)
                          .snapshots(),
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        // String data = snapshot.data.toString();
                        if (!snapshot.hasData)
                          return Center(
                              child: new CircularProgressIndicator(
                                color: Colors.red,
                              ));
                        return  new Column(
                          children: snapshot.data!.docs.map((postDocument) {
                            //  List<String> imageUrls =List.from(userDocument['picUrl']);

                            return
                              Stack(

                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.symmetric(vertical: 10),
                                        // padding: EdgeInsets.symmetric(horizontal: 10),
                                        width: Get.width*0.80,
                                        height:Get.height*0.60,
                                        decoration: BoxDecoration(
                                          color: Colors.green[300],
                                          border: Border.all(
                                            width: 0,
                                            color: Colors.white,

                                          ),

                                          borderRadius: BorderRadius.all(

                                            Radius.circular(20),
                                            //topRight: Radius.circular(90),
                                          ),

                                        ),

                                        child:
                                        ClipRRect(
                                            borderRadius: BorderRadius.circular(20),
                                            child:
                                            Image(
                                              fit: BoxFit.fill,
                                              image:

                                              NetworkImage(
                                                postDocument["postImageUrl"],),
                                            )
                                        ),
                                        //  child: Image.asset("assets/stacktwo.jpeg",fit: BoxFit.fill,)
                                      ),

                                    ],
                                  ),
                                  Positioned(

                                    top: 20,

                                    right: 10,

                                    child:

                                    Container(

                                      width:60,
                                      height:60,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                            colors: <Color>[
                                              Color.fromRGBO(104, 121, 137, 1),
                                              Color.fromRGBO(104, 121, 137, 1),
                                              Color.fromRGBO(104, 121, 137, 1),
                                              Color.fromRGBO(104, 121, 137, 1),
                                              Color.fromRGBO(84, 96, 108, 1),
                                              Color.fromRGBO(84, 96, 108, 1),
                                              Color.fromRGBO(84, 96, 108, 1),





                                            ]),
                                        //   color: Color.fromRGBO(104, 121, 137, 1),
                                        borderRadius: BorderRadius.all(Radius.circular(360)),
                                      ),
                                      child: Center(

                                        child: IconButton(

                                          onPressed: (


                                              ) {
                                            FirebaseFirestore.instance
                                                .collection('posts')
                                                .doc(postDocument.id).delete();

                                          },

                                          icon: const ImageIcon(
                                            AssetImage("assets/dustbin.png",) ,


                                            size: 35,
                                            color: Colors.white,

                                          ),

                                        ),
                                        //   alignment:Alignment.center
                                      ),
                                    ),


                                  )

                                ],

                              )
                            ;
                            //if search is less then 3 characters
                          }).toList(),
                        );
                      }),
                  SizedBox(height: 50,),





                ],),
              ),

              //tab 2 view
              SingleChildScrollView(
                child: Column(children: [
                  StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('posts')
                          .where("voter", arrayContains: widget.uId)
                          .snapshots(),
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        // String data = snapshot.data.toString();
                        if (!snapshot.hasData)
                          return Center(
                              child: new CircularProgressIndicator(
                                color: Colors.red,
                              ));
                        return new Column(
                          children: snapshot.data!.docs.map((postDocument) {
                            //  List<String> imageUrls =List.from(userDocument['picUrl']);

                            return
                              Stack(

                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        margin: EdgeInsets.symmetric(vertical: 10),
                                        // padding: EdgeInsets.symmetric(horizontal: 10),
                                        width: Get.width*0.80,
                                        height:Get.height*0.60,
                                        decoration: BoxDecoration(
                                          color: Colors.green[300],
                                          border: Border.all(
                                            width: 0,
                                            color: Colors.white,

                                          ),

                                          borderRadius: BorderRadius.all(

                                            Radius.circular(20),
                                            //topRight: Radius.circular(90),
                                          ),

                                        ),

                                        child:
                                        ClipRRect(
                                            borderRadius: BorderRadius.circular(20),
                                            child:
                                            Image(
                                              fit: BoxFit.fill,
                                              image:

                                              NetworkImage(
                                                postDocument["postImageUrl"],),
                                            )
                                        ),
                                        //  child: Image.asset("assets/stacktwo.jpeg",fit: BoxFit.fill,)
                                      ),

                                    ],
                                  ),


                                ],

                              )
                            ;
                            //if search is less then 3 characters
                          }).toList(),
                        );
                      })





                ],),
              ),

            ],
          ),




        ),





        // This trailing comma makes auto-formatting nicer for build methods.
      );
  }
}
//
// class CircleTabIndicator extends Decoration {
//   final BoxPainter _painter;
//   CircleTabIndicator({required Color color, required double radius}) :_painter = _CirclePainter(color, radius) ;
//   @override
//   BoxPainter createBoxPainter([VoidCallback? onChanged]) => _painter;
// }
//
// class _CirclePainter extends BoxPainter {
//   final Paint _paint;
//   final double radius;
//
//   _CirclePainter(Color color, this.radius) : _paint = Paint()
//     ..color = color
//     ..isAntiAlias = true;
//
//   @override
//   void paint(Canvas canvas, Offset offset, ImageConfiguration cfg) {
//     final Offset circleOffset = offset + Offset(cfg.size!.width / 2, cfg.size!.height - radius - 5);
//     canvas.drawCircle(circleOffset, radius, _paint);
//   }
// }