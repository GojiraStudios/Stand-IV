
import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'dart:core';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:get/get_core/src/get_main.dart';
import 'package:get/route_manager.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:standivadmin/createPost.dart';
import 'package:standivadmin/homepage.dart';
import 'package:standivadmin/uploadPicture.dart';

class PhoneVerificationPage extends StatefulWidget {
final String type;
  final String verificationCode;
   PhoneVerificationPage({super.key, required ,required this.verificationCode,required this.type});




  @override
  State<PhoneVerificationPage> createState() => _PhoneVerificationPageState();
}

class _PhoneVerificationPageState extends State<PhoneVerificationPage> {
//deployment id
//AKfycbxt9h_SGKeCzJvCX3rJ6b0sU97fsKjlIEbe7QMNw3OdbT7qUlHusCcaZtjgfol5IM9R
  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";

  // ignore: close_sinks
  StreamController<ErrorAnimationType>? errorController;

  bool hasError = false;
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController!.close();

    super.dispose();
  }

  // snackBar Widget
  snackBar(String? message) {
    return ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message!),
        duration: const Duration(seconds: 2),
      ),
    );
  }
  DateTime _convertDateFromString(String date) {
    return DateTime.parse(date);
  }



  Color kDarkColor= Color.fromRGBO(14, 10, 36, 1);







  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
backgroundColor: Colors.black,
      body:

          SingleChildScrollView(
            child: Column(children: [
  SizedBox(height: 50,),

              Container(
                color: Colors.white,
                child: Container(
                    height:Get.height*0.40,
                    width: Get.width,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(75),
                      ),
                      border: Border.all(
                        width: 0,

                       // style: BorderStyle.solid,
                      ),
                    ),
                    child: Center(
                     child: new Image.asset(
                        'assets/otp.png',

                        height: 180,

                        alignment: Alignment.center,
                      ),
                    )
                ),
              ),

              Container(
                child: Container(
                  margin: EdgeInsets.only(bottom:100 ),
                      height:Get.height*0.80,
                      width: Get.width,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                          width: 0,
                          color: Colors.white,

                        ),
                        borderRadius: BorderRadius.only(

                          topLeft: Radius.circular(75),
                          //topRight: Radius.circular(90),
                        ),

                      ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Center(child: Column(children: [
                              SizedBox(height: 30,),
                              Text("Verify Your Number",style:
                              TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
                              SizedBox(height: 15,),
                              Text("Please enter your verification code recieved",
                                style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),

                              SizedBox(height: 5,),
                              Text(" on your phone number",
                                style: TextStyle(color:Color.fromRGBO(116, 115,130, 1),fontSize: 18,fontWeight: FontWeight.w400,),),
                              SizedBox(height: 15,),
                              Form(
                                key: formKey,
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 30),
                                    child: PinCodeTextField(

                                      appContext: context,
                                      pastedTextStyle: TextStyle(
                                        color: Colors.green.shade600,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      length: 6,
                                      // obscureText: true,
                                      // obscuringCharacter: '*',
                                      // obscuringWidget: const FlutterLogo(
                                      //   size: 24,
                                      // ),
                                      // blinkWhenObscuring: true,
                                      animationType: AnimationType.fade,
                                      validator: (v) {
                                        if (v!.length < 6) {
                                          return "Please Enter Valid verification Code";
                                        } else {
                                          return null;
                                        }
                                      },
                                      pinTheme: PinTheme(
                                        inactiveColor: Colors.black,
                                        inactiveFillColor: Color.fromRGBO(243, 243, 245, 1).withOpacity(1),
                                        shape: PinCodeFieldShape.box,

                                        borderRadius: BorderRadius.circular(10),
                                        borderWidth: 1,
                                        fieldHeight: 50,
                                        fieldWidth: 50,
                                        activeFillColor: Colors.white,
                                      ),
                                      cursorColor: Colors.black,
                                      animationDuration: const Duration(milliseconds: 300),
                                      enableActiveFill: true,
                                      errorAnimationController: errorController,
                                      controller: textEditingController,
                                      keyboardType: TextInputType.number,
                                      boxShadows: const [
                                        BoxShadow(
                                          offset: Offset(0, 1),
                                          color: Colors.grey,
                                          blurRadius: 10,
                                        )
                                      ],
                                      onCompleted: (v) {
                                        debugPrint("Completed");
                                      },
                                      // onTap: () {
                                      //   print("Pressed");
                                      // },
                                      onChanged: (value) {
                                        debugPrint(value);
                                        setState(() {
                                          currentText = value;
                                        });
                                      },
                                      beforeTextPaste: (text) {
                                        debugPrint("Allowing to paste $text");
                                        //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                        //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                        return true;
                                      },
                                    )),
                              ),

                              SizedBox(height: 10,),

                              SizedBox(height: 5,),
                  InkWell(
                      onTap: (){
signIn();


                      },
                      child:
                                 new Container(
                                  margin: EdgeInsets.only(top: 10),
                                  width: 50,
                                  height: 50,
                                  decoration: new BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                      colors: [
                                        Color.fromRGBO(146, 31, 23, 1),
                                        Color.fromRGBO(188, 40, 28, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                        Color.fromRGBO(232, 50, 35, 1),
                                      ],),
                                 //   color: Colors.red,
                                    shape: BoxShape.circle,
                                  ),
                                  child: new Icon(
                                    Icons.arrow_forward,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(height: 10,),
                              Text("Procced",style: TextStyle(color:Colors.black54,fontSize: 16),)
                            ],),)

                          ],)
                  ),
              ),


            ],),
          )



     // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
  Widget _otpTextField(int digit) {
    return new Container(
     // margin: EdgeInsets.only(left: 15),
      width: 50.0,
      height: 50.0,
      alignment: Alignment.center,
      child: new Text(
        digit != null ? digit.toString() : "",
        style: new TextStyle(
          fontSize: 30.0,
          color: Colors.black,
        ),
      ),
      decoration: BoxDecoration(
        borderRadius: new BorderRadius.circular(10.0),
        color: Color.fromRGBO(243, 243, 245, 1),
          border: Border.all(
    width: 1.0,
    color: Colors.black,
               ),
    ));
  }
  Widget _otpEmptyTextField() {
    return new Container(
    //  color: Color.fromRGBO(243, 243, 245, 1),
      // margin: EdgeInsets.only(left: 15),
        width: 50.0,
        height: 50.0,
        alignment: Alignment.center,
        child: new Text(
            "",
          style: new TextStyle(
            fontSize: 30.0,
            color: Colors.black,
          ),
        ),
        decoration: BoxDecoration(
          color: Color.fromRGBO(243, 243, 245, 1),
          borderRadius: new BorderRadius.circular(10.0),
//            color: Colors.grey.withOpacity(0.4),
          border: Border.all(
            width: 1.0,
            color: Color.fromRGBO(243, 243, 245, 1)
          ),
        ));
  }
  Future<void> signIn() async {
    await FirebaseAuth.instance
        .signInWithCredential(PhoneAuthProvider.credential(
      verificationId: widget.verificationCode,
      smsCode: textEditingController.text,
    )).then((value) => {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(value.user!.uid.toString()),
        ),
      ),
    if(  widget.type=="signup"){
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => UploadPicturePage(uid:value.user!.uid.toString()))),
      print(value.user!.uid.toString())
    }
    else{
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => HomePage(isNew: true,))),
      print(value.user!.uid.toString())
    }
    });

  }
}
